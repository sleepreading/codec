/**********************************************\
**	���ļ��ĳ�ʼ������������Ч�ʵ��µ�:
**	����ǰ��֪����Ҫ���Ŷ��ٸ���Ƶ�������
**	ǿ�е���Ϊ��ʼ����(128��)
\**********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avcodec.h"  //++from dec
#include "MySuperLib.h"
#include "time.h"

#define MAX_CONTAINERCOUNT 128

typedef struct _H264Container
{
	char    nInUseFlag;		// C �в���ʹ��C++�е���������bool
	AVCodec *codec;			  // Codec
    AVCodecContext *c;		  // Codec Context
    AVFrame *picture;		  // Frame	
	DECODER_CALLBACK lpCBH264Player ;	//�˴��ǲ��ǲ���Ҫ���ڸýṹ����,��Ϊ����һ����
}H264Container;


// ʹ��ָ��������Է����ж��ǲ���==NULL,��ʵ��ʹ��Ҳ�ǿ��Ե�
static H264Container	*s_Containers[MAX_CONTAINERCOUNT] = {NULL} ;

// StartupVideoDecoder���˼�����Ҫ������:
// 1, �򿪽�����
// 2, �������������
// 3, ���ڶ�����������Ļص������ĵ�ַ���浽 s_Containers[i]
// 4, ����ʹ�ñ�ʶΪ1(����ʹ��)
int StartupVideoDecoder_original(int nIndex,DECODER_CALLBACK lpCBFunc)
{
	if(nIndex<0 || nIndex >= MAX_CONTAINERCOUNT)
		return 0;
	if(s_Containers[nIndex] == NULL)
		s_Containers[nIndex] = (H264Container *)calloc(1,sizeof(H264Container));
	
	if(!s_Containers[nIndex]->nInUseFlag)
	{
		s_Containers[nIndex]->nInUseFlag= 1 ;
//		s_Containers[nIndex]->pCodecCnt = avcdOpen(0);
//		s_Containers[nIndex]->pFrame    = (avcdYUVbuffer_s*)calloc(1,sizeof(avcdYUVbuffer_s));
		
		avcodec_init(); 
		avcodec_register_all(); 
		s_Containers[nIndex]->codec = avcodec_find_decoder(CODEC_ID_H264);
		if (!s_Containers[nIndex]->codec)  {
			return 0; 
		} 
		//allocate codec context
		s_Containers[nIndex]->c = avcodec_alloc_context(); 		
		if(!s_Containers[nIndex]->c){
			return 0;
		}
		//open codec
		if (avcodec_open(s_Containers[nIndex]->c, s_Containers[nIndex]->codec) < 0) {
			return 0; 
		} 
		
		//allocate frame buffer
		s_Containers[nIndex]->picture   = avcodec_alloc_frame();
		if(!s_Containers[nIndex]->picture){
			return 0;
		}
		
		s_Containers[nIndex]->lpCBH264Player = lpCBFunc ;
	}
	
	return 1 ;
}

int CleanupVideoDecoder_original()
{
	int nIndex;
	for (nIndex=0; nIndex<MAX_CONTAINERCOUNT;nIndex++)
	{
		if (s_Containers[nIndex] && s_Containers[nIndex]->nInUseFlag)
		{
//			avcdClose(s_Containers[nIndex]->pCodecCnt);
//			free(s_Containers[nIndex]->pFrame);
			if(	s_Containers[nIndex]->c) {
				avcodec_close(s_Containers[nIndex]->c); 
				av_free(s_Containers[nIndex]->c);
				s_Containers[nIndex]->c = NULL;
			} 
			if(s_Containers[nIndex]->picture) {
				av_free(s_Containers[nIndex]->picture);
				s_Containers[nIndex]->picture = NULL;
			}
		}
		free(s_Containers[nIndex]);	
	}

	return 0;
}

// test the decode time
clock_t g_intervalOld;
clock_t g_interval;
char	g_szInterval[1024] = {0};
FILE*	g_fp = NULL;
char	g_FirstTime = 0;
int		len = 0;
int RunVideoDecode_original(char *pszH264Buf,int nBufSize,int nIndex)
{
	int consumed_bytes = 0;
	int got_picture = 0;
	int ret = -1;	// AVCD_ERROR
	
	int      esiBytes = 0;
	unsigned int  b1b2b3b4 = 0x1000000;
	unsigned int  get4Byte = 0;

	if (nIndex<0 || nIndex>=MAX_CONTAINERCOUNT)
		return -1;

	if (pszH264Buf[4] == 0x06) //++shmily_liu: discard NALU = ESI
	{
		esiBytes = 4;
		while (esiBytes < nBufSize)
		{
			get4Byte = (pszH264Buf[esiBytes] | (pszH264Buf[esiBytes+1]<<8) | (pszH264Buf[esiBytes+2]<<16) | (pszH264Buf[esiBytes+3]<<24));
			if (get4Byte == b1b2b3b4)
				break;
			esiBytes += 1;
		}
	}

/*
	if (pszH264Buf[4] == 0x06)  //++shmily_liu: discard ESI
		return 0;  //++�޽������
*/
/*****************************************************************************
	���뺯��ʹ�÷���
int avcdDecodeOneFrame(avcdDecoder_t *dec, void *nalBitsPtr,
					int nalBitsLen, avcdYUVbuffer_s *outBuf);
	���ź������÷���
typedef void (*DECODER_CALLBACK)(unsigned char *,unsigned char *,unsigned char *,
				int nIndex,int nLineSize,int nXSize,int nYSize);
******************************************************************************/
//	memset(s_Containers[nIndex]->pFrame,0,sizeof(avcdYUVbuffer_s));

//	ret = avcdDecodeOneFrame(s_Containers[nIndex]->pCodecCnt, pszH264Buf, nBufSize, s_Containers[nIndex]->pFrame);
	consumed_bytes = avcdDecodeOneFrame(s_Containers[nIndex]->c, s_Containers[nIndex]->picture, &got_picture, pszH264Buf, nBufSize);

	if(consumed_bytes > 0)
	{
		s_Containers[nIndex]->lpCBH264Player(\
			(unsigned char *)s_Containers[nIndex]->picture->data[0],
			(unsigned char *)s_Containers[nIndex]->picture->data[1],
			(unsigned char *)s_Containers[nIndex]->picture->data[2],
			nIndex,
			s_Containers[nIndex]->picture->linesize[0], //++�����в���
			s_Containers[nIndex]->picture->linesize[1], //++ɫ���в���
			s_Containers[nIndex]->c->width,   //++ͼ��ʵ�ʿ���
			s_Containers[nIndex]->c->height); //++ͼ��ʵ�ʸ߶�
	}
//////////////////////////////////////////////////////////////////////////

	return consumed_bytes;
}


int GetDecoderVersion_original()
{
	return 0x20110517 ;
}

char *GetDecoderBuildTime_original()
{
	static char szBuildTime[256] = {0} ;
	sprintf(szBuildTime,"%s %s",__DATE__,__TIME__) ;
	return szBuildTime ;
}


