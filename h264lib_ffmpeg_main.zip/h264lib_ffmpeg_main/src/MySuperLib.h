
#ifndef __MY_SUPERLIB_H__ 
#define __MY_SUPERLIB_H__ 

typedef void (*DECODER_CALLBACK)(unsigned char *,unsigned char *,unsigned char *,int nIndex,int nLineSize0,int nLineSize1,int nXSize,int nYSize);

// nIndex: 0 -- 127
int		StartupVideoDecoder_original(int nIndex,DECODER_CALLBACK lpCBFunc) ;
int		CleanupVideoDecoder_original();
int		RunVideoDecode_original(char *pszH264Buf,int nBufSize,int nIndex) ;

int		GetDecoderVersion_original() ;
char*	GetDecoderBuildTime_original() ;


#endif