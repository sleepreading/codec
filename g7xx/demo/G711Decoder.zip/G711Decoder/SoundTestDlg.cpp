// SoundTestDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SoundTest.h"
#include "SoundTestDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();


// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSoundTestDlg dialog

CSoundTestDlg::CSoundTestDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSoundTestDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSoundTestDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_bOpen = FALSE;
	m_bEnd = FALSE;
}

void CSoundTestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSoundTestDlg)
	DDX_Control(pDX, IDC_ULAW, m_btUlaw);
	DDX_Control(pDX, IDC_ALAW, m_btAlaw);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSoundTestDlg, CDialog)
	//{{AFX_MSG_MAP(CSoundTestDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_ALAW, OnAlaw)
	ON_BN_CLICKED(IDC_ULAW, OnUlaw)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSoundTestDlg message handlers

BOOL CSoundTestDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
    m_strm_ado.Open(GetSafeHwnd(), this) ; 
    m_btAlaw.SetCheck(TRUE);
	m_btUlaw.SetCheck(FALSE);
	m_bAlaw = TRUE;
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSoundTestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSoundTestDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSoundTestDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

int CSoundTestDlg::AddData(unsigned char *pData)
{
	m_listData.push_back(pData);

	return 0;
}
BOOL CSoundTestDlg::ReleaseFileData()
{

	for(list<unsigned char*>::iterator itr = m_listData.begin();
	itr != m_listData.end();
	itr++)
	{
		unsigned char *pData = (*itr);
		if(pData != NULL)
		{
			delete[] pData;
		}

	}
	m_listData.clear();

	return TRUE;
}

#define BUFFER_MAX 2000
BOOL CSoundTestDlg::GetFileData()
{

	if(m_file == NULL)
	{
		return FALSE;
	}

	if(!m_bAlaw)
	{
		m_ccr = ulaw2linear;
	}
	else
	{
		m_ccr = alaw2linear;
	}


	unsigned char *pReadData = new unsigned char[BUFFER_MAX];
	short *pshTemp = new short[BUFFER_MAX];
//	FILE *file = fopen("E:\\dec.G711", "wb");
	int iRead = 0;
	do 
	{
	
		iRead = m_file.Read(pReadData, BUFFER_MAX);

		for (int i = 0; i < BUFFER_MAX; i++)
		{
			*(pshTemp + i) = (*m_ccr)(*(pReadData + i));
 		}

		unsigned char *pData = new unsigned char[BUFFER_MAX * 2];	
		memcpy(pData, pshTemp, BUFFER_MAX * 2);

		AddData((unsigned char *)pData);
		
	} while(iRead == BUFFER_MAX);


//  for(list<unsigned char*>::iterator itr = m_listData.begin();
//	itr != m_listData.end();
//	itr++)
//	{
//		unsigned char *pData = (*itr);
//		fwrite(pData, 1, 2000, file);
//
// 	}

	delete[] pReadData;
	delete[] pshTemp;
//	fclose(file);
	TRACE("m_listData.size=%d\n", m_listData.size());
	return TRUE;
}


void CSoundTestDlg::OnStart() 
{
	// TODO: Add your control notification handler code here
	if(m_bOpen)
	{
		AfxMessageBox("You have started!");
		return;
	}

	
	CString strPath;
	static char BASED_CODE szFilter[]=" TXT files (*.G711) |*.G711| All files (*.*)|*.*||";
	CFileDialog fileDlg(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, szFilter);
	if (fileDlg.DoModal() == IDOK)
	{
		strPath = fileDlg.GetPathName();

		if(m_file.Open(strPath, CFile::modeRead))
		{
			m_strm_ado.CtrlStream(TRUE);
			m_bOpen = TRUE;
			m_bEnd = FALSE;
			GetFileData();


		}
	}	


}

void CSoundTestDlg::OnStop() 
{
	// TODO: Add your control notification handler code here
	if(!m_bOpen)
	{

		return;
	}

	m_bEnd = TRUE;
	m_bOpen = FALSE;
	m_strm_ado.CtrlStream(FALSE) ;
	m_file.Close(); 
	ReleaseFileData();
}

void CSoundTestDlg::OnDestroy() 
{
    m_strm_ado.Close(); 
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	
}





void CSoundTestDlg::AdoStreamData(unsigned char *pBuffer, int nBufferLen)
{


//#define PCMDATA


#ifdef PCMDATA

 	m_file.Read(pBuffer, nBufferLen);
#else
	if(m_bEnd)
	{
		return;
	}
	if(m_listData.size() == 0)
	{
		return;
	}
	
	unsigned char *pData = m_listData.front();

	if(pData == NULL)
	{
		return;
	}
 	memcpy(pBuffer, pData, nBufferLen);
	
	m_listData.pop_front();

#endif
	TRACE("m_listData.size=%d,%d\n", m_listData.size(), nBufferLen);

}

void CSoundTestDlg::OnAlaw() 
{
	// TODO: Add your control notification handler code here
    m_btAlaw.SetCheck(TRUE);
	m_btUlaw.SetCheck(FALSE);
	m_bAlaw = TRUE;
}

void CSoundTestDlg::OnUlaw() 
{
	// TODO: Add your control notification handler code here
    m_btAlaw.SetCheck(FALSE);
	m_btUlaw.SetCheck(TRUE);	
	m_bAlaw = FALSE;
}
