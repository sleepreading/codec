// SoundTestDlg.h : header file
//

#if !defined(AFX_SOUNDTESTDLG_H__536D5F62_D87B_44DA_B85C_119BDC09CE34__INCLUDED_)
#define AFX_SOUNDTESTDLG_H__536D5F62_D87B_44DA_B85C_119BDC09CE34__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSoundTestDlg dialog
#include "StreamAudio.h"
#include "G711Decoder.h"
#include <list>
using namespace std;
class CSoundTestDlg : public CDialog, public CAudioStreamHandler 
{
// Construction
public:
	CSoundTestDlg(CWnd* pParent = NULL);	// standard constructor
	void AdoStreamData(unsigned char *pBuffer, int nBufferLen); 
    CStreamAudio m_strm_ado ;

	BOOL m_bAlaw;
	BOOL m_bEnd;
    char_short_routine m_ccr;
	list<unsigned char*> m_listData;
	int AddData(unsigned char *pData);
    BOOL GetFileData();
	BOOL ReleaseFileData();

	CFile m_file;
	BOOL m_bOpen;
// Dialog Data
	//{{AFX_DATA(CSoundTestDlg)
	enum { IDD = IDD_SOUNDTEST_DIALOG };
	CButton	m_btUlaw;
	CButton	m_btAlaw;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSoundTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSoundTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnStart();
	afx_msg void OnStop();
	afx_msg void OnDestroy();
	afx_msg void OnAlaw();
	afx_msg void OnUlaw();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SOUNDTESTDLG_H__536D5F62_D87B_44DA_B85C_119BDC09CE34__INCLUDED_)
