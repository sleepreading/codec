// SoundTest.h : main header file for the SOUNDTEST application
//

#if !defined(AFX_SOUNDTEST_H__DDDF72F9_9C08_4D75_9060_9565C99D4737__INCLUDED_)
#define AFX_SOUNDTEST_H__DDDF72F9_9C08_4D75_9060_9565C99D4737__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSoundTestApp:
// See SoundTest.cpp for the implementation of this class
//

class CSoundTestApp : public CWinApp
{
public:
	CSoundTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSoundTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSoundTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SOUNDTEST_H__DDDF72F9_9C08_4D75_9060_9565C99D4737__INCLUDED_)
