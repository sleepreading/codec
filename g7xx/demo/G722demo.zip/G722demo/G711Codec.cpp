// G711Codec.cpp: implementation of the CG711Codec class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "G711Codec.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CG711Codec::CG711Codec()
{

}

CG711Codec::~CG711Codec()
{

}

int CG711Codec::AEncode(char * pInData, int nInLen, char * pOutData, int & nOutLen)
{
	if ( pInData == NULL || nInLen%2 != 0 || nInLen <= 0 || pOutData == NULL )
	{
		return -1 ;
	}

	short *		pRawData	=	(short*) pInData ;
	int			nRawLen		=	nInLen/2 ;

	for ( int i = 0 ; i < nRawLen ; i++ )
	{
		pOutData [i] = linear2alaw ( pRawData [i] ) ;		
	}

	nOutLen = nRawLen ;

	return nRawLen ;
}

int CG711Codec::ADecode(char * pInData, int nInLen, char * pOutData, int & nOutLen)
{
	if ( pInData == NULL || nInLen <= 0 || pOutData == NULL )
	{
		return -1 ;
	}

	short *		pDecodeData = (short*) pOutData ;

	for ( int i = 0 ; i < nInLen ; i++ )
	{
		pDecodeData [i]	= alaw2linear ( pInData [i] ) ;
	}

	nOutLen = 2 * nInLen ;

	return nOutLen ;
}

int CG711Codec::UEncode(char * pInData, int nInLen, char * pOutData, int & nOutLen)
{
	if ( pInData == NULL || nInLen%2 != 0 || nInLen <= 0 || pOutData == NULL )
	{
		return -1 ;
	}

	short *		pRawData	=	(short*) pInData ;
	int			nRawLen		=	nInLen/2 ;

	for ( int i = 0 ; i < nRawLen ; i++ )
	{
		pOutData [i] = linear2ulaw ( pRawData [i] ) ;		
	}

	nOutLen = nRawLen ;

	return nRawLen ;

	return 0 ;
}

int CG711Codec::UDecode(char * pInData, int nInLen, char * pOutData, int & nOutLen)
{
	if ( pInData == NULL || nInLen <= 0 || pOutData == NULL )
	{
		return -1 ;
	}

	short *		pDecodeData = (short*) pOutData ;

	for ( int i = 0 ; i < nInLen ; i++ )
	{
		pDecodeData [i]	= ulaw2linear ( pInData [i] ) ;
	}

	nOutLen = 2 * nInLen ;

	return nOutLen ;	
}