// MyWaveIn.h: interface for the CMyWaveIn class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYWAVEIN_H__D6D88534_ED10_4ADA_8340_03302FE5E649__INCLUDED_)
#define AFX_MYWAVEIN_H__D6D88534_ED10_4ADA_8340_03302FE5E649__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "WaveIn.h"

#include <afxmt.h>

class CTestG722Dlg ;

class CMyWaveIn : public CWaveIn
{
public:
	void EnableSend(BOOL bSend);
	CMyWaveIn();
	virtual ~CMyWaveIn();
	virtual void GetData(char *pBuffer,int iLen);

public:
	CTestG722Dlg *	pDlg ;
};

#endif // !defined(AFX_MYWAVEIN_H__D6D88534_ED10_4ADA_8340_03302FE5E649__INCLUDED_)
