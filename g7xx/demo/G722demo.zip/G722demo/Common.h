#ifndef _COMMON_H
#define	_COMMON_H

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define	SAMPLE_RATE		8000
#define	BITS			16


#endif