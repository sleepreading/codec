// MyWaveIn.cpp: implementation of the CMyWaveIn class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyWaveIn.h"
#include "TestG722Dlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMyWaveIn::CMyWaveIn()
{

}

CMyWaveIn::~CMyWaveIn()
{
}

void CMyWaveIn::GetData(char *pBuffer,int iLen)
{
	pDlg ->RecvAudioData ( pBuffer, iLen ) ;
	CWaveIn::GetData (pBuffer,iLen);
}

