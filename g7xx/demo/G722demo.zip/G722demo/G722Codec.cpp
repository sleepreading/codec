// G722Codec.cpp: implementation of the CG722Codec class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "TestG722.h"
#include "G722Codec.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CG722Codec::CG722Codec()
{
	m_bIsEncodeInit		=	false ;
	m_bIsDecodeInit		=	false ;
}

CG722Codec::~CG722Codec()
{

}

bool CG722Codec::InitEncodeCodec(int nBitsRate, int nSampleRate)
{
	// 8K MHZ
	if ( nSampleRate == 8000 )
	{
		g722_encode_init( &enc_state, nBitsRate, G722_PACKED | G722_SAMPLE_RATE_8000 ) ;
	}
	else
	{
		g722_encode_init ( &enc_state, nBitsRate, G722_PACKED ) ;
	}

	m_bIsEncodeInit = true ;

	return true ;
}

bool CG722Codec::InitDecodeCodec(int nBitsRate, int nSampleRate)
{
	if ( nSampleRate == 8000 )
	{
		g722_decode_init( &dec_state, nBitsRate, G722_PACKED | G722_SAMPLE_RATE_8000 ) ;
	}
	else
	{
		g722_decode_init ( &dec_state, nBitsRate, G722_PACKED ) ;
	}

	m_bIsDecodeInit = true ;

	return true ;
}

bool CG722Codec::UnInitEncodeCodec()
{
	if ( m_bIsEncodeInit )
	{
		g722_encode_release ( &enc_state ) ;
	}

	m_bIsEncodeInit = false ;

	return true ;
}

bool CG722Codec::UnInitDecodeCodec()
{
	if ( m_bIsDecodeInit )
	{
		g722_decode_release ( &dec_state ) ;
	}

	m_bIsDecodeInit = false ;

	return true ;
}

int CG722Codec::Encode(char * pInData, int nInLen, char * pOutData, int & nOutLen)
{
	nOutLen	 =	-1 ;

	if ( pInData == NULL || nInLen <= 0 || pOutData == NULL )
	{
		return nOutLen ;
	}

	if ( m_bIsEncodeInit )
	{
		nOutLen = g722_encode ( &enc_state, (uint8_t*)pOutData, (const int16_t*)pInData, nInLen/sizeof(int16_t) ) ;		
	}
	
	return nOutLen ;
}

int CG722Codec::Decode(char * pInData, int nInLen, char * pOutData, int & nOutLen)
{
	nOutLen	 =	-1 ;

	if ( pInData == NULL || nInLen <= 0 || pOutData == NULL )
	{
		return nOutLen ;
	}

	if ( m_bIsDecodeInit )
	{
		nOutLen = 2 * g722_decode ( &dec_state, (int16_t*)pOutData, (uint8_t*)pInData, nInLen ) ;		
	}
	
	return nOutLen ;
}
