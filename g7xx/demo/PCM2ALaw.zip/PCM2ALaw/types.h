#ifndef _TYPES_H_
#define _TYPES_H_

#define	U8	unsigned char
#define U16 unsigned short
#define U32 unsigned int
#define U64 unsigned long

	 
#endif