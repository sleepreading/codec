#include <stdio.h>
#include <stdlib.h>
#include "typedef.h"
#include "basic_op.h"
 
Flag Overflow =0;
Flag Carry =0;

Word16 sature(Word32 L_var1)
  {
   Word16 var_out;

   if (L_var1 > 0X00007fffL)
     {
      Overflow = 1;
      var_out = MAX_16;
     }
   else if (L_var1 < (Word32)0xffff8000L)
     {
      Overflow = 1;
      var_out = MIN_16;
     }
   else
     {
      Overflow = 0;
      var_out = extract_l(L_var1);
     }

   return(var_out);
  }

Word16 add(Word16 var1,Word16 var2)
  {
   Word16 var_out;
   Word32 L_somme;

   L_somme = (Word32) var1 + var2;
   var_out = sature(L_somme);
   return(var_out);

Word16 sub(Word16 var1,Word16 var2)
  {
   Word16 var_out;
   Word32 L_diff;

   L_diff = (Word32) var1 - var2;
   var_out = sature(L_diff);
   return(var_out);
  }

Word16 abs_s(Word16 var1)
  {
   Word16 var_out;

   if (var1 == (Word16)0X8000 )
     {
      var_out = MAX_16;
     }
   else
     {
      if (var1 < 0)
        {
         var_out = -var1;
        }
      else
        {
         var_out = var1;
        }
      }
    return(var_out);
  }

Word16 shl(Word16 var1,Word16 var2)
  {
   Word16 var_out;
   Word32 resultat;

   if (var2 < 0)
     {
      var_out = shr(var1,-var2);
     }
   else
     {
      resultat = (Word32) var1 * ((Word32) 1 << var2);
     if ((var2 > 15 && var1 != 0) || (resultat != (Word32)((Word16) resultat)))
        {
         Overflow = 1;
         var_out = (var1 > 0) ? MAX_16 : MIN_16;
        }
      else
        {
         var_out = extract_l(resultat);
        }
     }
   return(var_out);
  }

Word16 shr(Word16 var1,Word16 var2)
  {
   Word16 var_out;

   if (var2 < 0)
     {
      var_out = shl(var1,-var2);
     }
   else
     {
      if (var2 >= 15)
        {
         var_out = (var1 < 0) ? (Word16)(-1) : (Word16)0;
        }
      else
        {
         if (var1 < 0)
           {
     var_out = ~(( ~var1) >> var2 );
           }
         else
           {
            var_out = var1 >> var2;
           }
        }
     }

   return(var_out);
  }


Word16 mult(Word16 var1, Word16 var2)
  {
   Word16 var_out;
   Word32 L_produit;

   L_produit = (Word32)var1 * (Word32)var2;

   L_produit = (L_produit & (Word32) 0xffff8000L) >> 15;

   if (L_produit & (Word32) 0x00010000L)
     L_produit = L_produit | (Word32) 0xffff0000L;

   var_out = sature(L_produit);
   return(var_out);
  }

Word32 L_mult(Word16 var1,Word16 var2)
  {
   Word32 L_var_out;

   L_var_out = (Word32)var1 * (Word32)var2;
   if (L_var_out != (Word32)0x40000000L)
     {
      L_var_out *= 2;
     }
   else
     {
      Overflow = 1;
      L_var_out = MAX_32;
     }

   return(L_var_out);
  }

Word16 negate(Word16 var1)
  {
   Word16 var_out;

   var_out = (var1 == MIN_16) ? MAX_16 : -var1;
   return(var_out);
  }



Word16 extract_h(Word32 L_var1)
  {
   Word16 var_out;

   var_out = (Word16) (L_var1 >> 16);
   return(var_out);
  }

Word16 extract_l(Word32 L_var1)
  {
   Word16 var_out;

   var_out = (Word16) L_var1;
   return(var_out);
  }


Word16 round(Word32 L_var1)
  {
   Word16 var_out;
   Word32 L_arrondi;

   L_arrondi = L_add(L_var1, (Word32)0x00008000);
   var_out = extract_h(L_arrondi);
   return(var_out);
  }


Word32 L_mac(Word32 L_var3, Word16 var1, Word16 var2)
  {
   Word32 L_var_out;
   Word32 L_produit;

   L_produit = L_mult(var1,var2);
   L_var_out = L_add(L_var3,L_produit);
   return(L_var_out);
  }

Word32 L_msu(Word32 L_var3, Word16 var1, Word16 var2)
  {
   Word32 L_var_out;
   Word32 L_produit;

   L_produit = L_mult(var1,var2);
   L_var_out = L_sub(L_var3,L_produit);
   return(L_var_out);
  }

Word32 L_macNs(Word32 L_var3, Word16 var1, Word16 var2)
  {
   Word32 L_var_out;

   L_var_out = L_mult(var1,var2);
   L_var_out = L_add_c(L_var3,L_var_out);
   return(L_var_out);
  }


Word32 L_msuNs(Word32 L_var3, Word16 var1, Word16 var2)
  {
   Word32 L_var_out;

   L_var_out = L_mult(var1,var2);
   L_var_out = L_sub_c(L_var3,L_var_out);
   return(L_var_out);
  }



Word32 L_add(Word32 L_var1, Word32 L_var2)
  {
   Word32 L_var_out;

   L_var_out = L_var1 + L_var2;

   if (((L_var1 ^ L_var2) & MIN_32) == 0)
     {
      if ((L_var_out ^ L_var1) & MIN_32)
        {
         L_var_out = (L_var1 < 0) ? MIN_32 : MAX_32;
         Overflow = 1;
        }
     }
   return(L_var_out);
  }


Word32 L_sub(Word32 L_var1, Word32 L_var2)
  {
   Word32 L_var_out;

   L_var_out = L_var1 - L_var2;

   if (((L_var1 ^ L_var2) & MIN_32) != 0)
     {
      if ((L_var_out ^ L_var1) & MIN_32)
        {
         L_var_out = (L_var1 < 0L) ? MIN_32 : MAX_32;
         Overflow = 1;
        }
     }
   return(L_var_out);
  }

Word32 L_add_c(Word32 L_var1, Word32 L_var2)
  {
   Word32 L_var_out;
   Word32 L_test;
   Flag carry_int = 0;

   L_var_out = L_var1 + L_var2 + Carry;

   L_test = L_var1 + L_var2;

   if ((L_var1>0) && (L_var2 >0) && (L_test < 0))
     {
      Overflow = 1;
      carry_int = 0;
     }
   else
     {
      if ((L_var1<0) && (L_var2 <0) && (L_test >0))
        {
         Overflow = 1;
         carry_int = 1;
        }
      else
        {
         if (((L_var1 ^ L_var2) < 0) && (L_test > 0))
           {
            Overflow = 0;
            carry_int = 1;
           }
         else
           {
            Overflow = 0;
            carry_int = 0;
           }
        }
     }

   if (Carry)
     {
      if (L_test == MAX_32)
        {
         Overflow = 1;
         Carry = carry_int;
        }
      else
        {
         if (L_test == (Word32) 0xFFFFFFFFL)
           {
            Carry = 1;
           }
         else
           {
            Carry = carry_int;
           }
        }
     }
   else
     {
      Carry = carry_int;
     }

   return(L_var_out);
  }


Word32 L_sub_c(Word32 L_var1, Word32 L_var2)
  {
   Word32 L_var_out;
   Word32 L_test;
   Flag carry_int = 0;

   if (Carry)
     {
      Carry = 0;
      if (L_var2 != MIN_32)
        {
         L_var_out = L_add_c(L_var1,-L_var2);
        }
      else
        {
         L_var_out = L_var1 - L_var2;
         if (L_var1 > 0L)
           {
            Overflow = 1;
            Carry = 0;
           }
        }
     }
   else
     {
      L_var_out = L_var1 - L_var2 - (Word32)0X00000001;
      L_test = L_var1 - L_var2;

      if ((L_test < 0) && (L_var1 > 0) && (L_var2 < 0))
        {
         Overflow = 1;
         carry_int = 0;
        }
      else if ((L_test > 0) && (L_var1 < 0) && (L_var2 > 0))
        {
         Overflow = 1;
         carry_int = 1;
        }
      else if ((L_test > 0) && ((L_var1 ^ L_var2) > 0))
        {
         Overflow = 0;
         carry_int = 1;
        }


      if (L_test == MIN_32)
        {
         Overflow = 1;
         Carry = carry_int;
        }
      else
        {
         Carry = carry_int;
        }
     }

   return(L_var_out);
  }

Word32 L_negate(Word32 L_var1)
  {
   Word32 L_var_out;

   L_var_out = (L_var1 == MIN_32) ? MAX_32 : -L_var1;
   return(L_var_out);
  }


Word16 mult_r(Word16 var1, Word16 var2)
  {
   Word16 var_out;
   Word32 L_produit_arr;

   L_produit_arr = (Word32)var1 * (Word32)var2; /* product */
   L_produit_arr += (Word32) 0x00004000;        /* round */
   L_produit_arr &= (Word32) 0xffff8000L;
   L_produit_arr >>= 15;                        /* shift */

   if (L_produit_arr & (Word32) 0x00010000L)   /* sign extend when necessary */
     {
      L_produit_arr |= (Word32) 0xffff0000L;
     }

   var_out = sature(L_produit_arr);
   return(var_out);
  }


Word32 L_shl(Word32 L_var1, Word16 var2)
{
   Word32 L_var_out;

   /* initialization used only to suppress Microsoft Visual C++ warnings */
   L_var_out = 0L;

   if (var2 <= 0)
     {
      L_var_out = L_shr(L_var1,-var2);
     }
   else
     {
      for(;var2>0;var2--)
        {
         if (L_var1 > (Word32) 0X3fffffffL)
           {
            Overflow = 1;
            L_var_out = MAX_32;
            break;
           }
         else
           {
            if (L_var1 < (Word32) 0xc0000000L)
              {
               Overflow = 1;
               L_var_out = MIN_32;
               break;
              }
           }
         L_var1 *= 2;
         L_var_out = L_var1;
        }
     }
   return(L_var_out);
  }



Word32 L_shr(Word32 L_var1, Word16 var2)
  {
   Word32 L_var_out;

   if (var2 < 0)
     {
      L_var_out = L_shl(L_var1,-var2);
     }
   else
     {
      if (var2 >= 31)
        {
         L_var_out = (L_var1 < 0L) ? -1 : 0;
        }
      else
        {
         if (L_var1<0)
           {
            L_var_out = ~((~L_var1) >> var2);
           }
        else
          {
           L_var_out = L_var1 >> var2;
          }
        }
     }
   return(L_var_out);
  }

Word16 shr_r(Word16 var1, Word16 var2)
  {
   Word16 var_out;

   if (var2>15)
     {
      var_out = 0;
     }
   else
     {
      var_out = shr(var1,var2);

      if (var2 > 0)
        {
         if ((var1 & ((Word16)1 << (var2-1))) != 0)
           {
            var_out++;
           }
        }
     }
   return(var_out);
  }


Word16 mac_r(Word32 L_var3, Word16 var1, Word16 var2)
  {
   Word16 var_out;

   L_var3 = L_mac(L_var3,var1,var2);
   L_var3 = L_add(L_var3, (Word32) 0x00008000);
   var_out = extract_h(L_var3);
   return(var_out);
  }

Word16 msu_r(Word32 L_var3, Word16 var1, Word16 var2)
  {
   Word16 var_out;

   L_var3 = L_msu(L_var3,var1,var2);
   L_var3 = L_add(L_var3, (Word32) 0x00008000);
   var_out = extract_h(L_var3);
   return(var_out);
  }

Word32 L_deposit_h(Word16 var1)
  {
   Word32 L_var_out;

   L_var_out = (Word32) var1 << 16;
   return(L_var_out);
  }

Word32 L_deposit_l(Word16 var1)
  {
   Word32 L_var_out;

   L_var_out = (Word32) var1;
   return(L_var_out);
  }

Word32 L_shr_r(Word32 L_var1,Word16 var2)
  {
   Word32 L_var_out;

   if (var2 > 31)
     {
      L_var_out = 0;
     }
   else
     {
      L_var_out = L_shr(L_var1,var2);
      if (var2 > 0)
        {
         if ( (L_var1 & ( (Word32)1 << (var2-1) )) != 0)
           {
            L_var_out++;
           }
        }
     }
   return(L_var_out);
  }


Word32 L_abs(Word32 L_var1)
  {
   Word32 L_var_out;

   if (L_var1 == MIN_32)
     {
      L_var_out = MAX_32;
     }
   else
     {
      if (L_var1 < 0)
        {
         L_var_out = -L_var1;
        }
      else
        {
         L_var_out = L_var1;
        }
     }

   return(L_var_out);
  }

Word32 L_sat (Word32 L_var1)
  {
   Word32 L_var_out;


   L_var_out = L_var1;

   if (Overflow)
     {

      if (Carry)
        {
         L_var_out = MIN_32;
        }
      else
        {
         L_var_out = MAX_32;
        }

      Carry = 0;
      Overflow = 0;
     }

   return(L_var_out);
  }

Word16 norm_s(Word16 var1)
  {
   Word16 var_out;

   if (var1 == 0)
     {
      var_out = 0;
     }
   else
     {
      if (var1 == (Word16) 0xffff)
        {
         var_out = 15;
        }
      else
        {
         if (var1 < 0)
           {
            var1 = ~var1;
           }

         for(var_out = 0; var1 < 0x4000; var_out++)
           {
            var1 <<= 1;
           }
        }
     }

   return(var_out);
  }


Word16 div_s(Word16 var1, Word16 var2)
  {
   Word16 var_out = 0;
   Word16 iteration;
   Word32 L_num;
   Word32 L_denom;

   if ((var1 > var2) || (var1 < 0) || (var2 < 0))
     {
      printf("Division Error var1=%d  var2=%d\n",var1,var2);
      exit(0);
     }

   if (var2 == 0)
     {
      printf("Division by 0, Fatal error \n");
      exit(0);
     }

   if (var1 == 0)
     {
      var_out = 0;
     }
   else
     {
      if (var1 == var2)
        {
         var_out = MAX_16;
        }
      else
        {
         L_num = L_deposit_l(var1);
         L_denom = L_deposit_l(var2);

         for(iteration=0;iteration<15;iteration++)
           {
            var_out <<=1;
            L_num <<= 1;

            if (L_num >= L_denom)
              {
               L_num = L_sub(L_num,L_denom);
               var_out = add(var_out,1);
              }
           }
        }
     }

   return(var_out);
  }

Word16 norm_l(Word32 L_var1)
  {
   Word16 var_out;

   if (L_var1 == 0)
     {
      var_out = 0;
     }
   else
     {
      if (L_var1 == (Word32)0xffffffffL)
        {
         var_out = 31;
        }
      else
        {
         if (L_var1 < 0)
           {
            L_var1 = ~L_var1;
           }

         for(var_out = 0;L_var1 < (Word32)0x40000000L;var_out++)
           {
            L_var1 <<= 1;
           }
        }
     }

   return(var_out);
  }

