/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#include	 "globals.h"


/*
 * Chrominance QP mapping table.
 * Chroma QP = qpChroma[Luma QP]
 */
#ifndef __SYMBIAN32__
const  u_int8  qpChroma[ 52 ] =  								//< >											    
			   { 0,   1,   2,	3,	 4,   5,   6,	7,	 8,   9,   10,	11,  12,  13,  14,	15,  16,  17,  18,  
				 19,  20,  21,	22,  23,  24,  25,	26,  27,  28,  29,	29,  30,  31,  32,	32,  33,  34,  34,  
				 35,  35,  36,	36,  37,  37,  37,	38,  38,  38,  39,	39,  39,  39 };
#endif
