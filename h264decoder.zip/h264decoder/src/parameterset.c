/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#include	 <string.h>
#include	 "nccglob.h"
#include	 "globals.h"
#include	 "debug.h"
#include	 "vld.h"
#include	 "parameterset.h"


#define  	MIN_CHROMA_QP_INDEX  	  -12
#define  	MAX_CHROMA_QP_INDEX  	  12

#define  	NUM_LEVELS				  15
#define  	MAX_PIC_SIZE_IN_MBS  	  36864
#define  	MAX_PIC_WIDTH_IN_MBS	  543						//< Sqrt( MAX_PIC_SIZE_IN_MBS * 8 ) >			    
#define  	MAX_PIC_HEIGHT_IN_MBS	  543						//< Sqrt( MAX_PIC_SIZE_IN_MBS * 8 ) >			    


static	const  int	levels[ NUM_LEVELS ] =						//< >											    
					{ 10,  11,	12,  13,  20,  21,	22,  30,  31,  32,	40,  41,  42,  50,	51 };


/*
 * AVC syntax functions as specified in specification
 */

/* Return fixed length code */
static	int  u_n( bitbuffer_s * bitbuf, int len, unsigned int * val )
{
	*val = vldGetFLC( bitbuf, len );

	if( bibGetStatus( bitbuf ) < 0 )
		return PS_ERROR;

	return PS_OK;
}

/* Return unsigned UVLC code */
static	int  ue_v( bitbuffer_s * bitbuf, unsigned int * val, 
				   unsigned int maxVal )
{
	*val = vldGetUVLC( bitbuf );

	if( bibGetStatus( bitbuf ) < 0 )
		return PS_ERROR;

	if( *val > maxVal )
		return PS_ERR_ILLEGAL_VALUE;

	return PS_OK;
}

/* Return long unsigned UVLC code */
static	int  ue_v_long( bitbuffer_s * bitbuf, u_int32 * val, 
						u_int32 maxVal )
{
	*val = vldGetUVLClong( bitbuf );

	if( bibGetStatus( bitbuf ) < 0 )
		return PS_ERROR;

	if( *val > maxVal )
		return PS_ERR_ILLEGAL_VALUE;

	return PS_OK;
}

/* Return signed UVLC code */
static	int  se_v( bitbuffer_s * bitbuf, int * val, int minVal, 
				   int maxVal )
{
	*val = vldGetSignedUVLC( bitbuf );

	if( bibGetStatus( bitbuf ) < 0 )
		return PS_ERROR;

	if( *val < minVal || *val > maxVal )
		return PS_ERR_ILLEGAL_VALUE;

	return PS_OK;
}

/* Return long signed UVLC code */
static	int  se_v_long( bitbuffer_s * bitbuf, int32 * val )
{
	*val = vldGetSignedUVLClong( bitbuf );

	if( bibGetStatus( bitbuf ) < 0 )
		return PS_ERROR;

	return PS_OK;
}


/*
 *
 * psClosePPS:
 *
 * Parameters:
 *		pps  				  the picture parameter set to be freed
 *
 * Function:
 *		free the picture parameter set
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  psClosePPS( pic_parameter_set_s * pps )
{
	if( pps == 0 )
		return;

	if( pps->slice_group_id )
		nccFree( pps->slice_group_id );

	nccFree( pps );
}


/*
 *
 * psCloseSPS:
 *
 * Parameters:
 *		sps  				  the sequence parameter set to be freed
 *
 * Fucntion:
 *		free the sequence parameter set
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  psCloseSPS( seq_parameter_set_s * sps )
{
	if( sps == 0 )
		return;

	nccFree( sps );
}


/*
 *
 * psCloseParametersSets:
 *
 * Parameters:
 *		spsList  			  The sequence parameter set list
 *		ppsList  			  The picture parameter set list
 *
 * Fucntion:
 *		Free all parameter sets
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  psCloseParametersSets( seq_parameter_set_s ** spsList, 
							 pic_parameter_set_s ** ppsList )
{
	int  i;

	for( i = 0;  i < PS_MAX_NUM_OF_SPS;  i++ )
	{
		psCloseSPS( spsList[ i ] );
		spsList[ i ] = 0;
	}

	for( i = 0;  i < PS_MAX_NUM_OF_PPS;  i++ )
	{
		psClosePPS( ppsList[ i ] );
		ppsList[ i ] = 0;
	}
}


/*
 *
 * getHrdParameters:
 *
 * Parameters:
 *		bitbuf				  The bitbuffer object
 *		hrd  				  the pointer for returning HRD parameters
 *
 * Function:
 *		decode the HRD Parameters
 *
 * Returns:
 *		PS_OK:				  Hrd parameters decoded succesfully
 *		<0:  				  Fail*  	 *		*	   *	  *  	 *		*	   *	  *  	 *		*	   *    
 */
static	int  getHrdParameters( bitbuffer_s * bitbuf, 
							   hrd_parameters_s * hrd )
{
	unsigned  int  i;
			  int  retCode;

	if( ( retCode = ue_v( bitbuf, &hrd->cpb_cnt_minus1, 31 ) )
		< 0 )
		return retCode;

	if( ( retCode = u_n( bitbuf, 4, &hrd->bit_rate_scale ) )
		< 0 )
		return retCode;

	if( ( retCode = u_n( bitbuf, 4, &hrd->cpb_size_scale ) )
		< 0 )
		return retCode;

	for( i = 0;  i <= hrd->cpb_cnt_minus1;	i++ )
	{															//	bit_rate_value_minus1 must be in range of 0     
																//		to 2^32-2								    
		if( ( retCode
			  = ue_v_long( bitbuf, 
				  &hrd->bit_rate_value_minus1[ i ], 
				  4294967294 )
			)
			< 0
		  )
			return retCode;

		/* cpb_size_value_minus1 must be in range of 0 to 2^32-2 */
		if( ( retCode
			  = ue_v_long( bitbuf, 
				  &hrd->cpb_size_value_minus1[ i ], 
				  4294967294 )
			)
			< 0
		  )
			return retCode;

		if( ( retCode = u_n( bitbuf, 1, &hrd->cbr_flag[ i ] ) )
			< 0 )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 5, 
			  &hrd->initial_cpb_removal_delay_length_minus1 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 5, 
				 &hrd->cpb_removal_delay_length_minus1 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 5, 
				 &hrd->dpb_output_delay_length_minus1 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 5, &hrd->time_offset_length ) )
		< 0 )
		return retCode;

	return PS_OK;
}

/*
 *
 * getVUI:
 *
 * Parameters:
 *		bitbuf				  The bitbuffer object
 *		vui  				  the pointer for returning VUI parameters
 *
 * Function:
 *		decode the VUI Parameters
 *
 * Returns:
 *		PS_OK:				  VUI parameters decoded succesfully
 *		<0:  				  Fail*  	 *		*	   *	  *  	 *		*	   *	  *  	 *		*	   *    
 */
static	int  getVUI( bitbuffer_s * bitbuf, vui_parameters_s * vui )
{
	unsigned	   tempWordHi, tempWordLo;
			  int  retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, 
				 &vui->aspect_ratio_info_present_flag )
		)
		< 0
	  )
		return retCode;

	if( vui->aspect_ratio_info_present_flag )
	{
		if( ( retCode
			  = u_n( bitbuf, 8, &vui->aspect_ratio_idc ) )
			< 0 )
			return retCode;
		if( vui->aspect_ratio_idc == PS_EXTENDED_SAR )
		{
			if( ( retCode
				  = u_n( bitbuf, 16, &vui->sar_width ) )
				< 0 )
				return retCode;
			if( ( retCode
				  = u_n( bitbuf, 16, &vui->sar_height ) )
				< 0 )
				return retCode;
		}
	}

	if( ( retCode
		  = u_n( bitbuf, 1, &vui->overscan_info_present_flag ) )
		< 0 )
		return retCode;

	if( vui->overscan_info_present_flag )
	{
		if( ( retCode
			  = u_n( bitbuf, 1, 
					 &vui->overscan_appropriate_flag )
			)
			< 0
		  )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, 
				 &vui->video_signal_type_present_flag )
		)
		< 0
	  )
		return retCode;

	if( vui->video_signal_type_present_flag )
	{
		if( ( retCode = u_n( bitbuf, 3, &vui->video_format ) )
			< 0 )
			return retCode;
		if( ( retCode
			  = u_n( bitbuf, 1, &vui->video_full_range_flag ) )
			< 0 )
			return retCode;
		if( ( retCode
			  = u_n( bitbuf, 1, 
				  &vui->colour_description_present_flag )
			)
			< 0
		  )
			return retCode;
		if( vui->colour_description_present_flag )
		{
			if( ( retCode
				  = u_n( bitbuf, 8, &vui->colour_primaries ) )
				< 0 )
				return retCode;
			if( ( retCode
				  = u_n( bitbuf, 8, 
						 &vui->transfer_characteristics )
				)
				< 0
			  )
				return retCode;
			if( ( retCode
				  = u_n( bitbuf, 8, &vui->matrix_coefficients ) )
				< 0 )
				return retCode;
		}
	}

	if( ( retCode
		  = u_n( bitbuf, 1, 
				 &vui->chroma_loc_info_present_flag )
		)
		< 0
	  )
		return retCode;

	if( vui->chroma_loc_info_present_flag )
	{
		if( ( retCode
			  = ue_v( bitbuf, 
				  &vui->chroma_sample_loc_type_top_field, 
				  5 )
			)
			< 0
		  )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, 
				  &vui->chroma_sample_loc_type_bottom_field, 
				  5 )
			)
			< 0
		  )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, &vui->timing_info_present_flag ) )
		< 0 )
		return retCode;

	if( vui->timing_info_present_flag )
	{
		if( ( retCode = u_n( bitbuf, 16, &tempWordHi ) ) < 0 )
			return retCode;
		if( ( retCode = u_n( bitbuf, 16, &tempWordLo ) ) < 0 )
			return retCode;
		vui->num_units_in_tick
		= ( ( ( u_int32 ) tempWordHi ) << 16 ) | ( ( u_int32 ) tempWordLo );

		if( ( retCode = u_n( bitbuf, 16, &tempWordHi ) ) < 0 )
			return retCode;
		if( ( retCode = u_n( bitbuf, 16, &tempWordLo ) ) < 0 )
			return retCode;
		vui->time_scale = ( ( ( u_int32 ) tempWordHi ) << 16 ) | ( ( u_int32 ) tempWordLo );

		if( ( retCode
			  = u_n( bitbuf, 1, &vui->fixed_frame_rate_flag ) )
			< 0 )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, 
				 &vui->nal_hrd_parameters_present_flag )
		)
		< 0
	  )
		return retCode;

	if( vui->nal_hrd_parameters_present_flag )
	{
		if( ( retCode
			  = getHrdParameters( bitbuf, 
				  &vui->nal_hrd_parameters )
			)
			< 0
		  )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, 
				 &vui->vcl_hrd_parameters_present_flag )
		)
		< 0
	  )
		return retCode;

	if( vui->vcl_hrd_parameters_present_flag )
	{
		if( ( retCode
			  = getHrdParameters( bitbuf, 
				  &vui->vcl_hrd_parameters )
			)
			< 0
		  )
			return retCode;
	}

	if( vui->nal_hrd_parameters_present_flag
		|| vui->vcl_hrd_parameters_present_flag )
	{
		if( ( retCode
			  = u_n( bitbuf, 1, &vui->low_delay_hrd_flag ) )
			< 0 )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, &vui->pic_struct_present_flag ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, &vui->bitstream_restriction_flag ) )
		< 0 )
		return retCode;

	if( vui->bitstream_restriction_flag )
	{
		if( ( retCode
			  = u_n( bitbuf, 1, 
				  &vui->motion_vectors_over_pic_boundaries_flag )
			)
			< 0
		  )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, &vui->max_bytes_per_pic_denom, 
					  16 )
			)
			< 0
		  )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, &vui->max_bits_per_mb_denom, 16 ) )
			< 0 )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, 
				  &vui->log2_max_mv_length_horizontal, 
				  16 )
			)
			< 0
		  )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, 
				  &vui->log2_max_mv_length_vertical, 16 )
			)
			< 0
		  )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, &vui->num_reorder_frames, 16 ) )
			< 0 )
			return retCode;
		if( ( retCode
			  = ue_v( bitbuf, &vui->max_dec_frame_buffering, 
					  16 )
			)
			< 0
		  )
			return retCode;
	}

	return PS_OK;
}

/*
 *
 * psDecodeSPS:
 *	    
 * Parameters:
 *		bitbuf				  Bitbuffer object
 *		spsList  			  The list for SPS's, the newly decoded SPS will be stored into the list
 *
 * Function:
 *		Decode the SPS, and store it into the SPS list
 *
 * Returns:
 *		PS_OK:				  SPS decoded succesfully
 *		<0:  				  Fail*  	 *		*	   *	  *  	 *		*	   *	  *  	 *		*	   *    
 */
int  psDecodeSPS( bitbuffer_s * bitbuf, seq_parameter_set_s ** spsList )
{
	seq_parameter_set_s  * sps;
	unsigned  int		   i;
			  int		   retCode;

	unsigned			   profile_idc;  						//	< u(8) >									    
	Boolean  			   constraint_set0_flag;				//	< u(1) >									    
	Boolean  			   constraint_set1_flag;				//	< u(1) >									    
	Boolean  			   constraint_set2_flag;				//	< u(1) >									    
	Boolean  			   reserved_zero_5bits;  				//	< u(5) >									    
	unsigned			   level_idc;							//	< u(8) >									    
	unsigned			   seq_parameter_set_id;				//	< ue(v) >
	//++s
	Boolean                constraint_set3_flag;         
//	Boolean                seq_scaling_matrix_present_flag;
   // unsigned	           chroma_format_idc;
	//++e


  /*
   * Parse sequence parameter set syntax until sps id
   */

	if( ( retCode = u_n( bitbuf, 8, &profile_idc ) ) < 0 )
		return retCode;

	/* If constraint_set0_flag == 1, stream is Baseline Profile compliant */
	if( ( retCode = u_n( bitbuf, 1, &constraint_set0_flag ) )
		< 0 )
		return retCode;

	/* If constraint_set1_flag == 1, stream is Main Profile compliant */
	if( ( retCode = u_n( bitbuf, 1, &constraint_set1_flag ) )
		< 0 )
		return retCode;

	/* If constraint_set2_flag == 1, stream is Extended Profile compliant */
	if( ( retCode = u_n( bitbuf, 1, &constraint_set2_flag ) )
		< 0 )
		return retCode;
//++s
/* If constraint_set3_flag == 1, stream is FREXT??(guess)  Profile compliant */
	if( ( retCode = u_n( bitbuf, 1, &constraint_set3_flag ) )
		< 0 )
		return retCode;
//++e

	/* We support only baseline compliant streams */
	if( profile_idc != PS_BASELINE_PROFILE_IDC
		&& constraint_set0_flag == 0 )
		return PS_ERR_UNSUPPORTED_PROFILE;

	/* We don't care what is in these bits */
	if( ( retCode = u_n( bitbuf, 4, &reserved_zero_5bits ) )//modified from 5 to 4
		< 0 )
		return retCode;

	/* Fetch level */
	if( ( retCode = u_n( bitbuf, 8, &level_idc ) ) < 0 )
		return retCode;

	/* Find level in the list of legal levels */
	for( i = 0;  i < NUM_LEVELS;  i++ )
	{
		if( ( int ) level_idc == levels[ i ] )
			break;
	}

	/* If level was not found in the list, return with error */
	if( i == NUM_LEVELS )
		return PS_ERR_ILLEGAL_VALUE;

	/* Get sequence parameter set id */
	if( ( retCode
		  = ue_v( bitbuf, &seq_parameter_set_id, 
				  PS_MAX_NUM_OF_SPS - 1 )
		)
		< 0
	  )
		return retCode;


  /*
   * Allocate memory for SPS
   */

	/* Pointer to sequence parameter set structure */
	sps = spsList[ seq_parameter_set_id ];

	/* allocate mem for SPS, if it has not been allocated already */
	if( !sps )
	{
		sps = ( seq_parameter_set_s * ) nccMalloc( sizeof( seq_parameter_set_s ) );
		if( sps == 0 )
		{
			deb0f( stderr, "Error while allocating memory for SPS.\n" );
			return PS_ERR_MEM_ALLOC;
		}
		memset( sps, 0, sizeof( seq_parameter_set_s ) );
		spsList[ seq_parameter_set_id ] = sps;
	}


	/* Copy temporary variables to sequence parameter set structure */
	sps->profile_idc		  = profile_idc;
	sps->constraint_set0_flag = constraint_set0_flag;
	sps->constraint_set1_flag = constraint_set1_flag;
	sps->constraint_set2_flag = constraint_set2_flag;
	sps->reserved_zero_5bits  = reserved_zero_5bits;
	sps->level_idc			  = level_idc;
	sps->seq_parameter_set_id = seq_parameter_set_id;


  /*
   * Parse rest of the sequence parameter set syntax
   */

	/* This defines how many bits there are in frame_num syntax element */
	if( ( retCode
		  = ue_v( bitbuf, &sps->log2_max_frame_num_minus4, 12 ) )
		< 0 )
		return retCode;

	/* Fetch POC type */
	if( ( retCode
		  = ue_v( bitbuf, &sps->pic_order_cnt_type, 2 ) )
		< 0 )
		return retCode;

	if( sps->pic_order_cnt_type == 0 )
	{
		if( ( retCode
			  = ue_v( bitbuf, 
				  &sps->log2_max_pic_order_cnt_lsb_minus4, 
				  12 )
			)
			< 0
		  )
			return retCode;
	}
	else
		if( sps->pic_order_cnt_type == 1 )
		{
			if( ( retCode
				  = u_n( bitbuf, 1, 
					  &sps->delta_pic_order_always_zero_flag )
				)
				< 0
			  )
				return retCode;

			if( ( retCode
				  = se_v_long( bitbuf, 
					  &sps->offset_for_non_ref_pic )
				)
				< 0
			  )
				return retCode;

			if( ( retCode
				  = se_v_long( bitbuf, 
					  &sps->offset_for_top_to_bottom_field )
				)
				< 0
			  )
				return retCode;

			if( ( retCode
				  = ue_v( bitbuf, 
					  &sps
					   ->num_ref_frames_in_pic_order_cnt_cycle, 
					  255 )
				)
				< 0
			  )
				return retCode;

			for( i = 0;  
				 i
				 < sps->num_ref_frames_in_pic_order_cnt_cycle;  
				 i++ )
			{
				if( ( retCode
					  = se_v_long( bitbuf, 
						  &sps->offset_for_ref_frame[ i ] )
					)
					< 0
				  )
					return retCode;
			}
		}

	if( ( retCode = ue_v( bitbuf, &sps->num_ref_frames, 16 ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, 
			  &sps->gaps_in_frame_num_value_allowed_flag )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = ue_v( bitbuf, &sps->pic_width_in_mbs_minus1, 
				  MAX_PIC_WIDTH_IN_MBS - 1 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = ue_v( bitbuf, 
				  &sps->pic_height_in_map_units_minus1, 
				  MAX_PIC_WIDTH_IN_MBS - 1 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, &sps->frame_mbs_only_flag ) )
		< 0 )
		return retCode;

	if( !sps->frame_mbs_only_flag )
	{															//	u_n(bitbuf, 1,								    
																//		&sps->mb_adaptive_frame_field_flag);	    
		return PS_ERR_UNSUPPORTED_FEATURE;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, &sps->direct_8x8_inference_flag ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, &sps->frame_cropping_flag ) )
		< 0 )
		return retCode;

	/* Fetch cropping window */
	if( sps->frame_cropping_flag )
	{
		if( ( retCode
			  = ue_v( bitbuf, &sps->frame_crop_left_offset, 
				  8 * ( sps->pic_width_in_mbs_minus1 + 1 )
				  - 1 )
			)
			< 0
		  )
			return retCode;

		if( ( retCode
			  = ue_v( bitbuf, &sps->frame_crop_right_offset, 
				  8 * ( sps->pic_width_in_mbs_minus1 + 1 )
				  - sps->frame_crop_left_offset - 1 )
			)
			< 0
		  )
			return retCode;

		if( ( retCode
			  = ue_v( bitbuf, &sps->frame_crop_top_offset, 
				  8
				  * ( sps->pic_height_in_map_units_minus1 + 1 )
				  - 1 )
			)
			< 0
		  )
			return retCode;

		if( ( retCode
			  = ue_v( bitbuf, &sps->frame_crop_bottom_offset, 
				  8
				  * ( sps->pic_height_in_map_units_minus1 + 1 )
				  - sps->frame_crop_top_offset - 1 )
			)
			< 0
		  )
			return retCode;
	}

	if( ( retCode
		  = u_n( bitbuf, 1, &sps->vui_parameters_present_flag ) )
		< 0 )
		return retCode;

	if( sps->vui_parameters_present_flag )
	{
		if( ( retCode
			  = getVUI( bitbuf, &sps->vui_parameters ) )
			< 0 )
			return retCode;
	}

	if( bibSkipTrailingBits( bitbuf ) < 0 )
		return PS_ERROR;

	return PS_OK;
}


/*
 *
 * psDecodePPS:
 *	    
 * Parameters:
 *		bitbuf				  Bitbuffer object
 *		ppsList  			  The list for PPS's, the newly decoded PPS will be stored into the list
 *
 * Function:
 *		Decode the PPS, and store it into the PPS list
 *
 * Returns:
 *		PS_OK:				  PPS decoded succesfully
 *		<0:  				  Fail*  	 *		*	   *	  *  	 *		*	   *	  *  	 *		*	   *    
 */
int  psDecodePPS( bitbuffer_s * bitbuf, pic_parameter_set_s ** ppsList )
{
	unsigned  int		   i, tmp;
			  int		   len;
	pic_parameter_set_s  * pps;
	unsigned			   pic_parameter_set_id;
			  int		   retCode;
	unsigned			   pic_size_in_map_units_minus1;


	/* Parse pps id */
	if( ( retCode
		  = ue_v( bitbuf, &pic_parameter_set_id, 
				  PS_MAX_NUM_OF_PPS - 1 )
		)
		< 0
	  )
		return retCode;

  /*
   * Allocate memory for pps if not already allocated
   */

	pps = ppsList[ pic_parameter_set_id ];

	if( !pps )
	{
		pps = ( pic_parameter_set_s * ) nccMalloc( sizeof( pic_parameter_set_s ) );
		if( pps == 0 )
		{
			deb0f( stderr, "Error while allocating memory for PPS.\n" );
			return PS_ERR_MEM_ALLOC;
		}
		memset( pps, 0, sizeof( pic_parameter_set_s ) );
		ppsList[ pic_parameter_set_id ] = pps;
	}


  /*
   * Parse rest of the picture parameter set syntax
   */

	if( ( retCode
		  = ue_v( bitbuf, &pps->seq_parameter_set_id, 
				  PS_MAX_NUM_OF_SPS - 1 )
		)
		< 0
	  )
		return retCode;

	/* Fetch entropy coding mode. Mode is 0 for CAVLC and 1 for CABAC */
	if( ( retCode
		  = u_n( bitbuf, 1, &pps->entropy_coding_mode_flag ) )
		< 0 )
		return retCode;

	/* If this flag is 1, POC related syntax elements are present in slice header */
	if( ( retCode
		  = u_n( bitbuf, 1, &pps->pic_order_present_flag ) )
		< 0 )
		return retCode;

	/* Fetch the number of slice groups minus 1 */
	if( ( retCode
		  = ue_v( bitbuf, &pps->num_slice_groups_minus1, 
				  PS_MAX_NUM_SLICE_GROUPS - 1 )
		)
		< 0
	  )
		return retCode;

	if( pps->num_slice_groups_minus1 > 0 )
	{

		if( ( retCode
			  = ue_v( bitbuf, &pps->slice_group_map_type, 6 ) )
			< 0 )
			return retCode;

		switch( pps->slice_group_map_type )
		{

			case PS_SLICE_GROUP_MAP_TYPE_INTERLEAVED:
				for( i = 0;  
					 i <= pps->num_slice_groups_minus1;  i++ )
				{
					if( ( retCode
						  = ue_v( bitbuf, 
							  &pps->run_length_minus1[ i ], 
							  MAX_PIC_SIZE_IN_MBS - 1 )
						)
						< 0
					  )
						return retCode;
				}
				break;

			case PS_SLICE_GROUP_MAP_TYPE_DISPERSED:
				break;

			case PS_SLICE_GROUP_MAP_TYPE_FOREGROUND:
				for( i = 0;  i < pps->num_slice_groups_minus1;  
					 i++ )
				{												//		  Fetch MB address of the top-left corner   
					if( ( retCode
						  = ue_v( bitbuf, &pps->top_left[ i ], 
							  MAX_PIC_SIZE_IN_MBS - 1 )
						)
						< 0
					  )
						return retCode;  						//			  Fetch MB address of the			    
																//				  bottom-right corner (top-left     
																//				  address must be smaller than or   
																//				  equal to bottom-right address)    
					if( ( retCode
						  = ue_v( bitbuf, 
							  &pps->bottom_right[ i ], 
							  MAX_PIC_SIZE_IN_MBS - 1 )
						)
						< 0
					  )
						return retCode;

					if( pps->top_left[ i ]
						> pps->bottom_right[ i ] )
						return PS_ERR_ILLEGAL_VALUE;
				}
				break;

			case PS_SLICE_GROUP_MAP_TYPE_CHANGING_3:
			case PS_SLICE_GROUP_MAP_TYPE_CHANGING_4:
			case PS_SLICE_GROUP_MAP_TYPE_CHANGING_5:
				if( ( retCode
					  = u_n( bitbuf, 1, 
						  &pps
						   ->slice_group_change_direction_flag )
					)
					< 0
				  )
					return retCode;
				if( ( retCode
					  = ue_v( bitbuf, 
						  &pps->slice_group_change_rate_minus1, 
						  MAX_PIC_SIZE_IN_MBS - 1 )
					)
					< 0
				  )
					return retCode;
				break;

			case PS_SLICE_GROUP_MAP_TYPE_EXPLICIT:

				if( ( retCode
					  = ue_v( bitbuf, 
						  &pic_size_in_map_units_minus1, 
						  MAX_PIC_SIZE_IN_MBS - 1 )
					)
					< 0
				  )
					return retCode;

				/* Allocate array for slice group ids if not already allocated */
				if( pic_size_in_map_units_minus1
					!= pps->pic_size_in_map_units_minus1 )
				{
					nccFree( pps->slice_group_id );
					pps->slice_group_id
					= ( unsigned int * ) 
						nccMalloc( ( pic_size_in_map_units_minus1 + 1 ) * sizeof( int ) );
					pps->pic_size_in_map_units_minus1 = pic_size_in_map_units_minus1;
				}

				// Calculate len = ceil( Log2( num_slice_groups_minus1 + 1 ) )
				tmp = pps->num_slice_groups_minus1 + 1;
				tmp = tmp >> 1;
				for( len = 0;  len < 16 && tmp != 0;  len++ )
					tmp >>= 1;
				if( ( ( ( unsigned ) 1 ) << len )
					< ( pps->num_slice_groups_minus1 + 1 ) )
					len++;

				for( i = 0;  
					 i <= pps->pic_size_in_map_units_minus1;  
					 i++ )
				{
					if( ( retCode
						  = u_n( bitbuf, len, 
							  &pps->slice_group_id[ i ] )
						)
						< 0
					  )
						return retCode;
				}

				break;

			default :											//		Cannnot happen							    
				break;
		}
	}

	if( ( retCode
		  = ue_v( bitbuf, &pps->num_ref_idx_l0_active_minus1, 
				  31 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = ue_v( bitbuf, &pps->num_ref_idx_l1_active_minus1, 
				  31 )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, &pps->weighted_pred_flag ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 2, &pps->weighted_bipred_idc ) )
		< 0 )
		return retCode;

	if( pps->weighted_bipred_idc > 2 )
		return PS_ERR_ILLEGAL_VALUE;

	if( ( retCode
		  = se_v( bitbuf, &pps->pic_init_qp_minus26, -26, 25 ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = se_v( bitbuf, &pps->pic_init_qs_minus26, -26, 25 ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = se_v( bitbuf, &pps->chroma_qp_index_offset, -12, 
				  12 )
		)
		< 0
	  )
		return retCode;

	pps->chroma_qp_index_offset
	= clip( MIN_CHROMA_QP_INDEX, MAX_CHROMA_QP_INDEX, pps->chroma_qp_index_offset );

	if( ( retCode
		  = u_n( bitbuf, 1, 
			  &pps->deblocking_filter_parameters_present_flag )
		)
		< 0
	  )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, &pps->constrained_intra_pred_flag ) )
		< 0 )
		return retCode;

	if( ( retCode
		  = u_n( bitbuf, 1, 
				 &pps->redundant_pic_cnt_present_flag )
		)
		< 0
	  )
		return retCode;

	if( bibSkipTrailingBits( bitbuf ) < 0 )
		return PS_ERROR;

	return PS_OK;
}
