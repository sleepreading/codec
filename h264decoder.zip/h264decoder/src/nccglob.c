/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/


#include	 "nccglob.h"
#ifndef NCC_ALLOC_NO_NULL_CHECK
#include	 <stdlib.h>
#include	 "debug.h"
#endif


/*
 * Wrappers for memory allocation functions
 * See the header file for description.
 */

#ifndef NCC_ALLOC_NO_NULL_CHECK
void  * nccMalloc( size_t size )
{
	void  * p = malloc( size );

	if( p == NULL )
	{
		deb1f( stderr, "nccMalloc: ERROR. Can't allocate %u bytes.\n", size );
		nccExit( 1 );
	}

	return p;
}

void  * nccCalloc( size_t num, size_t size )
{
	void  * p = calloc( num, size );

	if( p == NULL )
	{
		deb2f( stderr, "nccCalloc: ERROR. Can't allocate %u objects of size %u.\n", num, 
			   size );
		nccExit( 1 );
	}

	return p;
}

void  * nccRealloc( void * memblock, size_t size )
{
	void  * p = realloc( memblock, size );

	if( p == NULL )
	{
		deb1f( stderr, "nccRealloc: ERROR. Can't reallocate %u bytes.\n", size );
		nccExit( 1 );
	}

	return p;
}
#endif


/*
 * Wrapper for exit
 * See the header file for description.
 */

#ifdef WIN32DLL
void nccExitWin32DLL(int status)
{
   static const int *p = 0;

   /* Cause an exception. */
   *p = 111;
}
#endif
