/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/



#include	 <stdio.h>
#include	 <stdlib.h>
#include	 <string.h>
#include	 <math.h>
#include	 <time.h>

#include	 "avcdecoder.h"


#define  	MAX_FILENAME_LEN		200

#define  	SEPARATE_YUV_FILES		0
#define  	COMBINED_YUV_FILE		1

#define  	NALBUF_INITIAL_SIZE  	4096
#define  	NALBUF_BLOCK_SIZE		512

#define  	READ_FRAME_BITS  		1

#define  	BYTE_STREAM  			0
#define  	RTP_STREAM				1


typedef struct _videoFile_s
{
	int  	enabled;
	int  	format;
	FILE  * y;
	FILE  * u;
	FILE  * v;
	FILE  * yuv;
}	 videoFile_s;


typedef struct _userParam_s
{
	char  * inFile;
	char  * recoFile;
	int  	recoFormat;
	char  * cumuFile;
	int  	cropFlag;
	int  	ecAlg;
}	 userParam_s;


typedef struct _byteStream_s
{
	FILE				  * fn;  								//	< Bitstream file pointer >					    

			  long			bytesRead;							//	< The number of bytes read from the file >	    
	unsigned		char  * bitbuf;  							//	< Buffer for stream bits >					    
					int  	bitbufLen;							//	< Size of the bit buffer in bytes >  		    
					int  	bitbufDataPos;
					int  	bitbufDataLen;						//	< Length of all the data in the bit buffer in   
																//		bytes >  								    

	unsigned		char  * bitbufNalunit;						//	< Pointer to first NAL unit in the bitbuffer    
																//		>										    
					int  	bitbufNalunitLen;
								/* Length of the first NAL unit in the bit buffer in bytes,
								   including variable size start code, nal head byte and the
								   RBSP payload. It will help to find the RBSP length. */
}	 byteStream_s;


typedef struct _statOverall_s
{
	long  numBitsI;
	long  numBitsP;
	long  numIframes;
	long  numPframes;
}	 statOverall_s;



/*
 *
 * usage:
 *
 * Parameters:
 *		-
 *
 * Function:
 *		Print decoder usage information.
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
/* by 
static	void  usage( void )
{//added by 
	//fprintf( stderr, "Decoder process started:\n" );

	fprintf( stderr, "Decoder parameters:\n" );
	fprintf( stderr, " -i <bitstream filename>                  [(mandatory)]\n" );
	fprintf( stderr, " [-reco <reconstruction filename>]        [default none]\n" );
	fprintf( stderr, " [-recoyuv <reconstruction filename>]     [default none]\n" );
	fprintf( stderr, " [-cumul file] Per total statistics       [default none]\n" );
	fprintf( stderr, " [-crop]                                  [default no cropping]\n" );

#ifdef ERROR_CONCEALMENT
	// by 
  fprintf(stderr," [-ecAlg] Error Concealment Algorithm     [default TCON]\n");
  fprintf(stderr,"          0: Previous Frame Copy\n");
  fprintf(stderr,"          1: TCON\n");

#endif
}
  */

/*
 *
 * parseArg:
 *
 * Parameters:
 *		argc				  Number of parameters
 *		argv				  Parameter strings
 *		param				  Structure where parameters will be stored
 *
 * Function:
 *		Parse decoder parameters
 *
 * Returns:
 *		0 error
 *		1 ok
 *
 */
static	int  parseArg( int argc, char ** argv, userParam_s * param )
{
	int  i;

	param->inFile	= NULL;
	param->recoFile = NULL;
	param->cumuFile = NULL;
	param->cropFlag = 0;

	for( i = 1;  i < argc;	i++ )
	{

		if( strcmp( argv[ i ], "-i" ) == 0 )
		{
			if( ++i == argc )
			{
				return 0;
			}
			param->inFile = argv[ i ];
		}
		else
			if( strcmp( argv[ i ], "-oyuv" ) == 0 )
			{
				if( ++i == argc )
				{
					return 0;
				}
				param->recoFormat = SEPARATE_YUV_FILES;
				param->recoFile   = argv[ i ];
			}
			else
				if( strcmp( argv[ i ], "-o" ) == 0 )
				{
					if( ++i == argc )
					{
						return 0;
					}
					param->recoFormat = COMBINED_YUV_FILE;
					param->recoFile   = argv[ i ];
				}
				else
					if( strcmp( argv[ i ], "-cumul" ) == 0 )
					{
						if( ++i == argc )
						{
							return 0;
						}
						param->cumuFile = argv[ i ];
					}
					else
						if( strcmp( argv[ i ], "-crop" )
							== 0 )
						{
							param->cropFlag = 1;
						}
						else
							if( strcmp( argv[ i ], "-ecAlg" )
								== 0 )
							{
								if( ++i == argc )
								{
									return 0;
								}
								param->ecAlg = atoi( argv[ i ] );
							}
							else
							{
								return 0;
							}

	}

	if( param->inFile == NULL )
	{
		fprintf( stderr, "Source file required\n\n" );
		return 0;
	}

	return 1;
}


/*
 *
 * printSeqStat:
 *
 * Parameters:
 *		seqStat  			  Statistics object
 *		qpIntra  			  Intra quantization parameter
 *		qpInter  			  Inter quantization parameter
 *		fp					  Destination stream
 *
 * Function:
 *		Print sequence statistics
 *
 * Returns:
 *		-
 *
 */
static	void  printSeqStat( statOverall_s * seqStat, int qpIntra, 
							int qpInter, FILE * fp )
{
	long  nFrames;

	nFrames = seqStat->numIframes + seqStat->numPframes;

	if( nFrames == 0 )
		return;
 //modified by 
	fprintf( fp, "%3ld %2d %2d %2.2f %2.2f %2.2f %5ld ""%2.2f %2.2f %2.2f %5ld ""%2.2f %2.2f %2.2f %5ld %.3f\n", 
	  nFrames, qpInter, qpIntra, 0.0, 0.0, 0.0, 
	  seqStat->numIframes != 0 ? seqStat->numBitsI / seqStat->numIframes : 0, 0.0, 0.0, 0.0, 
	  seqStat->numPframes != 0 ? seqStat->numBitsP / seqStat->numPframes : 0, 0.0, 0.0, 0.0, 
	  ( seqStat->numBitsI + seqStat->numBitsP ) / nFrames, ( double ) clock( ) / CLOCKS_PER_SEC / nFrames );
/*
// add
	fprintf( fp, "%3ld %2d %2d %2.2f %2.2f %2.2f %5ld ""%2.2f %2.2f %2.2f %5ld ""%2.2f %2.2f %2.2f %5ld %.3f\n", 
	  nFrames, qpInter, qpIntra, 0.0, 0.0, 0.0, 
	  seqStat->numIframes != 0 ? seqStat->numBitsI / seqStat->numIframes : 0, 0.0, 0.0, 0.0, 
	  seqStat->numPframes != 0 ? seqStat->numBitsP / seqStat->numPframes : 0, 0.0, 0.0, 0.0, 
	  ( seqStat->numBitsI + seqStat->numBitsP ) / nFrames, ( int ) clock( ) / CLOCKS_PER_SEC / nFrames );
//end*/
}


/*
 *
 * openFiles:
 *
 * Parameters:
 *		param				  Parameters
 *		recoFile			  Decoded sequence file
 *		recoFlag			  If 1, dec. file opened
 *		strByte  			  Bitsream
 *
 * Function:
 *		Open raw video files
 *	    
 * Returns:
 *		-
 *
 */
static	void  openFiles( userParam_s * param, videoFile_s * recoFile, 
						 byteStream_s * strByte )
{
	char  tmpName[ MAX_FILENAME_LEN + 1 ];

  /*
   * Open reconstruction file if requested
   */

	if( param->recoFile != NULL
		&& strlen( param->recoFile ) + 2 > MAX_FILENAME_LEN )
	{
		fprintf( stderr, "Too long reconstruction file name\n" );
		exit( 1 );
	}

	recoFile->enabled = 0;

	if( param->recoFile != NULL )
	{
		switch( param->recoFormat )
		{

			case SEPARATE_YUV_FILES:
				sprintf( tmpName, "%s%s", param->recoFile, ".y" );
				if( ( recoFile->y = fopen( tmpName, "wb" ) )// bg
					== NULL )
				{
					fprintf( stderr, "Cannot open reconstruction file \"%s\"\n", tmpName );
					exit( 1 );
				}
				sprintf( tmpName, "%s%s", param->recoFile, ".u" );
				if( ( recoFile->u = fopen( tmpName, "wb" ) )//bg
					== NULL )
				{
					fprintf( stderr, "Cannot open reconstruction file \"%s\"\n", tmpName );
					exit( 1 );
				}
				sprintf( tmpName, "%s%s", param->recoFile, ".v" );
				if( ( recoFile->v = fopen( tmpName, "wb" ) )//bg
					== NULL )
				{
					fprintf( stderr, "Cannot open reconstruction file \"%s\"\n", tmpName );
					exit( 1 );
				}
				break;

			case COMBINED_YUV_FILE:
				if( ( recoFile->yuv
					  = fopen( param->recoFile, "wb" ) )
					== NULL )
				{
					fprintf( stderr, "Cannot open reconstruction file \"%s\"\n", 
							 param->recoFile );
					exit( 1 );
				}
				break;

			default :
				fprintf( stderr, "Unknown reconstruction file format\n" );
				exit( 1 );
		}

		recoFile->enabled = 1;
		recoFile->format  = param->recoFormat;
	}

  /*
   * open bitstream file
   */

	if( ( strByte->fn = fopen( param->inFile, "rb" ) )
		== NULL )
	{
		fprintf( stderr, "Cannot open input bitstream\n" );
		exit( 1 );
	}

	if( ( strByte->bitbuf = malloc( NALBUF_INITIAL_SIZE ) )
		== NULL )
	{
		fprintf( stderr, "Cannot allocate memory for bitstream\n" );
		exit( 1 );
	}

	strByte->bytesRead		  = 0;
	strByte->bitbufLen		  = NALBUF_INITIAL_SIZE;
	strByte->bitbufDataLen	  = 0;
	strByte->bitbufDataPos	  = 0;
	strByte->bitbufNalunitLen = 0;
}


/*
 *
 * closeFiles:
 *
 * Parameters:
 *		recoFile			  Reconstruction file
 *		recoFlag			  Rec. frames were written to file if true
 *		str  				  Bitsream
 *
 * Function:
 *		Close raw video files
 *	    
 * Returns:
 *		-
 *
 */
static	void  closeFiles( videoFile_s * recoFile, byteStream_s * str )
{
	if( recoFile->enabled )
	{
		switch( recoFile->format )
		{
			case SEPARATE_YUV_FILES:
				fclose( recoFile->y );
				fclose( recoFile->u );
				fclose( recoFile->v );
				break;
			case COMBINED_YUV_FILE:
				fclose( recoFile->yuv );
		}
		recoFile->enabled = 0;
	}

	fclose( str->fn );
	free( str->bitbuf );
}


/*
 *
 * writeFrame:
 *
 * Parameters:
 *		buf  				  Frame buffer
 *		outFile  			  Destination file
 *		cropFlag			  True if cropping enabled
 *
 * Function:
 *		Writes frame to the file
 *	    
 * Returns:
 *		-
 *
 */
static	void  writeFrame( avcdYUVbuffer_s * buf, videoFile_s * outFile, 
						  int cropFlag )
{
	FILE  * yFile, * uFile, * vFile;

	if( buf == NULL )
		return;

	switch( outFile->format )
	{
		case SEPARATE_YUV_FILES:
			yFile = outFile->y;
			uFile = outFile->u;
			vFile = outFile->v;
			break;
		case COMBINED_YUV_FILE:
			yFile = uFile = vFile = outFile->yuv;
			break;
		default :
			fprintf( stderr, "Unknown reconstruction file type\n" );
			exit( 1 );
	}

	if( !( cropFlag
		   && ( buf->cropLeftOff | buf->cropRightOff
				| buf->cropTopOff | buf->cropBottomOff )
			  != 0
		 )
	  )
	{
		fwrite( buf->y, sizeof( unsigned char ), buf->width * buf->height, yFile );
		fwrite( buf->u, sizeof( unsigned char ), buf->width * buf->height / 4, uFile );
		fwrite( buf->v, sizeof( unsigned char ), buf->width * buf->height / 4, vFile );
	}
	else
	{
				  int	  cropTop, cropBottom, cropLeft, cropRight;
				  int	  totalWidth;
				  int	  cropWidth, cropHeight;
		unsigned  char	* imgPtr;
				  int	  i;

		cropTop    = 2 * buf->cropTopOff;
		cropBottom = 2 * buf->cropBottomOff;
		cropLeft   = 2 * buf->cropLeftOff;
		cropRight  = 2 * buf->cropRightOff;

		totalWidth = buf->width;
		cropWidth  = totalWidth - cropLeft - cropRight;
		cropHeight = buf->height - cropTop - cropBottom;

		imgPtr	   = &( ( unsigned char * ) buf->y )[ cropTop * totalWidth + cropLeft ];
		for( i = 0;  i < cropHeight;  i++ )
			fwrite( &imgPtr[ i * totalWidth ], sizeof( unsigned char ), cropWidth, yFile );

		totalWidth = totalWidth / 2;
		cropWidth  = cropWidth / 2;
		cropHeight = cropHeight / 2;

		imgPtr	   = &( ( unsigned char * ) buf->u )[ cropTop / 2 * totalWidth + cropLeft / 2 ];
		for( i = 0;  i < cropHeight;  i++ )
			fwrite( &imgPtr[ i * totalWidth ], sizeof( unsigned char ), cropWidth, uFile );

		imgPtr = &( ( unsigned char * ) buf->v )[ cropTop / 2 * totalWidth + cropLeft / 2 ];
		for( i = 0;  i < cropHeight;  i++ )
			fwrite( &imgPtr[ i * totalWidth ], sizeof( unsigned char ), cropWidth, vFile );
	}
}


/*
 *
 * readBytesFromFile:
 *
 * Parameters:
 *		str  				  Bitbuffer object
 *
 * Function:
 *		Read bytes from the bistream file
 *
 * Returns:
 *		Number of bytes read
 *
 */
static	int  readBytesFromFile( byteStream_s * str )
{
	int  n;

	if( str->bitbufLen - str->bitbufDataLen
		< NALBUF_BLOCK_SIZE )
	{

		/* Buffer is too small -> allocate bigger buffer */
		str->bitbuf = realloc( str->bitbuf, str->bitbufLen + NALBUF_BLOCK_SIZE );

		if( str->bitbuf == NULL )
		{
			fprintf( stderr, "Cannot resize bitbuffer\n" );
			exit( 1 );
		}
		str->bitbufLen += NALBUF_BLOCK_SIZE;
	}

	/* Read block of data */
	n = ( int ) fread( str->bitbuf + str->bitbufDataLen, 1, NALBUF_BLOCK_SIZE, str->fn );

	str->bytesRead	   += n;
	str->bitbufDataLen += n;

	return n;
}


/*
 *
 * findStartCode:
 *
 * Parameters:
 *		str  				  Bitbuffer object
 *
 * Function:
 *		First next start code in AVC byte stream
 *
 * Returns:
 *		Length of start code
 *
 *		str->bitbufDataPos will point to first byte that follows start code*	  *  	 *		*	   *	  *     
 */
static	int  findStartCode( byteStream_s * str )
{
	int  numZeros;
	int  startCodeFound;
	int  i;
	int  currByte;

	numZeros	   = 0;
	startCodeFound = 0;

	i			   = str->bitbufDataPos;

	while( !startCodeFound )
	{

		if( i == str->bitbufDataLen )
		{														//	  We are at the end of data -> read more from   
																//		  the bitstream file					    

			int  n = readBytesFromFile( str );

			if( n == 0 )										//		End of bitstream -> stop search  		    
				break;
		}

		/* Find sequence of 0x00 ... 0x00 0x01 */

		while( i < str->bitbufDataLen )
		{

			currByte = str->bitbuf[ i ];
			i++;

			if( currByte > 1 )									//		If current byte is > 1, it cannot be part   
																//			of a start code  					    
				numZeros = 0;
			else
				if( currByte == 0 )  							//		  If current byte is 0, it could be part    
																//			  of a start code					    
					numZeros++;
				else
				{												//		  currByte == 1  						    
					if( numZeros > 1 )
					{											//			currByte == 1. If numZeros > 1, we	    
																//				found a start code				    
						startCodeFound = 1;
						break;
					}
					numZeros = 0;
				}
		}
	}

	str->bitbufDataPos = i;

	if( startCodeFound )
		return ( numZeros + 1 );
	else
		return 0;
}


/*
 *
 * getNalunitBits_ByteStream:
 *
 * Parameters:
 *		strIn				  Bytestream pointer
 *
 * Function:
 *		Read one NAL unit from bitstream file.
 *
 * Returns:
 *		1: No errors
 *		0: Could not read bytes (end of file)*		*	   *	  *  	 *		*	   *	  *  	 *		*	   *
 */
int  getNalunitBits_ByteStream( void * strIn )
{
	byteStream_s  * str;
	int  			numRemainingBytes;
	int  			startCodeLen;
	int  			nalUnitStartPos;

	str = ( byteStream_s * ) strIn;


  /*
   * Copy valid data to the beginning of the buffer
   */

	numRemainingBytes = str->bitbufDataLen - str->bitbufDataPos;

	if( numRemainingBytes > 0 )
	{
		memcpy( str->bitbuf, str->bitbuf + str->bitbufDataPos, numRemainingBytes );
	}

	/* Update bitbuffer variables */
	str->bitbufDataLen = numRemainingBytes;
	str->bitbufDataPos = 0;


  /*
   * Find NAL unit boundaries
   */

	/* Find first start code */
	startCodeLen	   = findStartCode( str );

	if( startCodeLen == 0 )
		return 0;

	/* Start address of the NAL unit */
	nalUnitStartPos = str->bitbufDataPos - startCodeLen;

	/* Find second start code */
	startCodeLen	= findStartCode( str );

	/* Set data pointer to the beginning of the second start code */
	/* (i.e. to the end of the NAL unit)						  */
	if( startCodeLen != 0 )
		str->bitbufDataPos -= startCodeLen;

	str->bitbufNalunit	  = str->bitbuf + nalUnitStartPos;
	str->bitbufNalunitLen = str->bitbufDataPos;


	return 1;
}


/*
 *
 * postProcessFrame:
 *
 * Parameters:
 *		recoBuf  			  Decoded picture
 *		recoFile			  Reconstruction file
 *		globalStat			  Statistics
 *		cropFlag			  True if cropping enabled
 *
 * Function:
 *		Note that it can be called only after a whole frame is decoded
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
static	void  postProcessFrame( avcdYUVbuffer_s * recoBuf, 
								videoFile_s * recoFile, 
								statOverall_s * globalStat, 
								userParam_s * param )
{
	/* Write reconstruction to file */
	if( recoFile->enabled )
		writeFrame( recoBuf, recoFile, param->cropFlag );

	/* update statistics */
	if( recoBuf->picType == 1 )
	{															//	An Intra picture							    
		globalStat->numBitsI   += recoBuf->numDecodedBits;
		globalStat->numIframes += 1;
	}
	else
	{
		globalStat->numBitsP   += recoBuf->numDecodedBits;
		globalStat->numPframes += 1;
	}

	/* Output statistics for the picture */
//  by 
	printf( "%d\tbits = %d, \tPSNR Y = %5.2f, \tU = %5.2f, \tV = %5.2f\n", 
	  globalStat->numIframes + globalStat->numPframes - 1, recoBuf->numDecodedBits, 0.0, 0.0, 
	  0.0 );

}


/*
 *
 * main:
 *
 * Parameters:
 *		argc				  Number of parameters
 *		argv				  Parameter strings
 *
 * Function:
 *		Decoder main function
 *
 * Returns:
 *		   0 ok
 *		<> 0 error
 *
 */
int  main( int argc, char ** argv )
{
	userParam_s  	   param;
	avcdDecoder_t	 * decoder;
	byteStream_s	   strByte;
	videoFile_s  	   recoFile;
	avcdYUVbuffer_s    recoBuf;
	FILE			 * cumuFp;
	statOverall_s	   globalStat;
	int  			   result, seqEndFlag;


	/* Parse command line arguments  */
	if( !parseArg( argc, argv, &param ) )
	{
		//usage( );//by 
		exit( 1 );
	}
//added by 
	printf("Decoder process started:\n");

	/* Open video & bitstream files */
	openFiles( &param, &recoFile, &strByte );

	/* Zero out statistics */
	memset( &globalStat, 0, sizeof( statOverall_s ) );


	/* Open sequence */
	decoder = avcdOpen( param.ecAlg );

	if( decoder == NULL )
	{
		fprintf( stderr, "Could not open sequence\n" );
		exit( 1 );
	}


  /*
   * Main decoder loop. Frames are decoded until there are no more frames.
   */

	seqEndFlag = 0;
	result	   = AVCD_OK;

	while( !seqEndFlag )
	{

		/* result == AVCD_OK_STREAM_NOT_DECODED -> don't update bitbuffer */
		if( result != AVCD_OK_STREAM_NOT_DECODED )
		{
			if( !getNalunitBits_ByteStream( &strByte ) )
			{
				strByte.bitbufNalunit	 = 0;
				strByte.bitbufNalunitLen = 0;
			}
		}

		/* Decode one NAL unit */
		result
		= avcdDecodeOneNal( decoder, strByte.bitbufNalunit, strByte.bitbufNalunitLen, 
							&recoBuf );

		switch( result )
		{

			case AVCD_OK:
			case AVCD_OK_STREAM_NOT_DECODED:
				postProcessFrame( &recoBuf, &recoFile, &globalStat, &param );
				break;

			case AVCD_OK_FRAME_NOT_AVAILABLE:
				if( strByte.bitbufNalunit == 0
					&& strByte.bitbufNalunitLen == 0 )
					seqEndFlag = 1;
				break;

			case AVCD_ERROR:
			default :
				fprintf( stderr, "Error occured in AVC decoder\n" );
				seqEndFlag = 1;
				break;
		}

	}


	/* Close sequence */
	avcdClose( decoder );

	/* Close video & bitstream files */
	closeFiles( &recoFile, &strByte );

	/* Print decoding time */
/*	//added by 
	printf( "\nThis is the end of the decoder process\n");
*/	//modified by 
	printf( "took %3.3f seconds\n", ( double ) clock( ) / CLOCKS_PER_SEC );

//added by 
//printf( "took %3.3f seconds\n", ( int ) clock( ) / CLOCKS_PER_SEC );
	/* Append short sequence statistics to -cumul file if file present */
	if( param.cumuFile != NULL )
	{
		if( ( cumuFp = fopen( param.cumuFile, "a" ) )//bg
			!= NULL )
		{
			printSeqStat( &globalStat, 0, 0, cumuFp );
			fclose( cumuFp );
		}
	}

	/* print a brief report */
	printf( "Total frames being decoded: %d\nI: %d, P: %d\n", 
	  globalStat.numIframes + globalStat.numPframes, globalStat.numIframes, 
	  globalStat.numPframes );
	printf( "Total bits: %d\nI: %d, P: %d\n", globalStat.numBitsI + globalStat.numBitsP, 
			globalStat.numBitsI, globalStat.numBitsP );

	return 0;
}