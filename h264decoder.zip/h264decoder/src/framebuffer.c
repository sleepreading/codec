/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/



#include	 <string.h>

#include	 "nccglob.h"
#include	 "globals.h"
#include	 "debug.h"
#include	 "framebuffer.h"


/*
 * Static functions
 */

static	void	  * allocMem( int blkSize, size_t unitSize ) ;

static	frmBuf_s  * initRefFrame( frmBuf_s * recoBuf, frmBuf_s * refBuf ) ;



/*
 *
 * allocMem:
 *
 * Parameters:
 *		blkSize  			  Block size
 *		unitSize			  unit size
 *
 * Function:
 *		Allocate blkSize*unitSize bytes of memory
 *
 * Returns:
 *		Pointer to allocated memory or NULL
 *
 */
static	void  * allocMem( int blkSize, size_t unitSize )
{
	void  * mem;

	if( ( mem = nccMalloc( blkSize * unitSize ) ) == NULL )
	{
		deb0f( stderr, "Cannot allocate memory for frame\n" );
	}

	return mem;
}


/*
 *
 * frmOpen:
 *
 * Parameters:
 *		mbData				  Macroblock state buffer
 *		width				  Width of the frame
 *		height				  Height of the frame
 *
 * Function:
 *		Allocate memory for frame buffer and macroblock state buffer.
 *
 * Returns:
 *		Pointer to allocated frame buffer or NULL
 *
 */
frmBuf_s  * frmOpen( mbAttributes_s ** mbData, int width, int height )
{
	int  			  numPels = width * height;
	int  			  numBlksPerLine = width / BLK_SIZE;
	int  			  numBlocks = numBlksPerLine * height
								  / BLK_SIZE;
	int  			  numMacroblocks = width / MBK_SIZE
									   * height / MBK_SIZE;
	frmBuf_s		* recoBuf;
	mbAttributes_s	* mbDataTmp;

	if( ( recoBuf
		  = ( frmBuf_s * ) nccMalloc( sizeof( frmBuf_s ) ) )
		== NULL )
		return NULL;

	memset( recoBuf, 0, sizeof( frmBuf_s ) );

	if( ( recoBuf->y
		  = ( u_int8 * ) allocMem( numPels, sizeof( u_int8 ) ) )
		== NULL )
		return NULL;
	if( ( recoBuf->u
		  = ( u_int8 * ) 
			  allocMem( numPels / 4, sizeof( u_int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( recoBuf->v
		  = ( u_int8 * ) 
			  allocMem( numPels / 4, sizeof( u_int8 ) )
		)
		== NULL
	  )
		return NULL;

	recoBuf->width	= width;
	recoBuf->height = height;

	if( ( mbDataTmp
		  = ( mbAttributes_s * ) 
			  nccMalloc( sizeof( mbAttributes_s ) )
		)
		== NULL
	  )
		return NULL;

	memset( mbDataTmp, 0, sizeof( mbAttributes_s ) );

	if( ( mbDataTmp->sliceMap
		  = ( int * ) allocMem( numMacroblocks, sizeof( int ) ) )
		== NULL )
		return NULL;
	if( ( mbDataTmp->mbTypeTable
		  = ( int8 * ) 
			  allocMem( numMacroblocks, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->qpTable
		  = ( int8 * ) 
			  allocMem( numMacroblocks, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->refIdxTable
		  = ( int8 * ) allocMem( numBlocks, sizeof( int8 ) ) )
		== NULL )
		return NULL;
	if( ( mbDataTmp->cbpTable
		  = ( int * ) allocMem( numMacroblocks, sizeof( int ) ) )
		== NULL )
		return NULL;
	if( ( mbDataTmp->motVecTable
		  = ( motVec_s * ) 
			  allocMem( numBlocks, sizeof( motVec_s ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->ipModesUpPred
		  = ( int8 * ) 
			  allocMem( numBlksPerLine, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;

	if( ( mbDataTmp->numCoefUpPred[ 0 ]
		  = ( int8 * ) 
			  allocMem( numBlksPerLine, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->numCoefUpPred[ 1 ]
		  = ( int8 * ) 
			  allocMem( numBlksPerLine / 2, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->numCoefUpPred[ 2 ]
		  = ( int8 * ) 
			  allocMem( numBlksPerLine / 2, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;

	if( ( mbDataTmp->filterModeTab
		  = ( int8 * ) 
			  allocMem( numMacroblocks, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->alphaOffset
		  = ( int8 * ) 
			  allocMem( numMacroblocks, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( mbDataTmp->betaOffset
		  = ( int8 * ) 
			  allocMem( numMacroblocks, sizeof( int8 ) )
		)
		== NULL
	  )
		return NULL;

	*mbData = mbDataTmp;

	return recoBuf;
}


/*
 *
 * frmOpenRef:
 *
 * Parameters:
 *		width				  Width of the frame
 *		height				  Height of the frame
 *
 * Function:
 *		Allocate memory for reference frame buffer
 *
 * Returns:
 *		Pointer to Reference frame or NULL
 *
 */
frmBuf_s  * frmOpenRef( int width, int height )
{
	int  		numPels = width * height;
	frmBuf_s  * ref;

	if( ( ref = ( frmBuf_s * ) nccMalloc( sizeof( frmBuf_s ) ) )
		== NULL )
		return NULL;

	memset( ref, 0, sizeof( frmBuf_s ) );

	if( ( ref->y
		  = ( u_int8 * ) allocMem( numPels, sizeof( u_int8 ) ) )
		== NULL )
		return NULL;
	if( ( ref->u
		  = ( u_int8 * ) 
			  allocMem( numPels / 4, sizeof( u_int8 ) )
		)
		== NULL
	  )
		return NULL;
	if( ( ref->v
		  = ( u_int8 * ) 
			  allocMem( numPels / 4, sizeof( u_int8 ) )
		)
		== NULL
	  )
		return NULL;

	ref->width	   = width;
	ref->height    = height;

	ref->forOutput = 0;
	ref->refType   = FRM_NON_REF_PIC;

	return ref;
}


/*
 *
 * frmClose:
 *
 * Parameters:
 *		frame				  Frame
 *		mbData				  MB state buffers
 *
 * Function:
 *		Deallocate frame buffer and state array memory.
 *
 * Returns:
 *		Nothing
 *
 */
void  frmClose( frmBuf_s * recoBuf, mbAttributes_s * mbData )
{
	if( !recoBuf )
		return;

	nccFree( recoBuf->y );
	nccFree( recoBuf->u );
	nccFree( recoBuf->v );

	nccFree( mbData->sliceMap );
	nccFree( mbData->mbTypeTable );
	nccFree( mbData->qpTable );
	nccFree( mbData->refIdxTable );
	nccFree( mbData->cbpTable );
	nccFree( mbData->motVecTable );
	nccFree( mbData->ipModesUpPred );
	nccFree( mbData->numCoefUpPred[ 0 ] );
	nccFree( mbData->numCoefUpPred[ 1 ] );
	nccFree( mbData->numCoefUpPred[ 2 ] );
	nccFree( mbData->filterModeTab );
	nccFree( mbData->alphaOffset );
	nccFree( mbData->betaOffset );

	nccFree( recoBuf );
	nccFree( mbData );
}


/*
 *
 * frmCloseRef:
 *
 * Parameters:
 *		ref  				  Reference frame
 *
 * Function:
 *		Deallocate reference frame buffer memory.
 *
 * Returns:
 *		Nothing
 *
 */
void  frmCloseRef( frmBuf_s * ref )
{
	if( !ref )
		return;

	nccFree( ref->y );
	nccFree( ref->u );
	nccFree( ref->v );

	nccFree( ref );
}


/*
 *
 * initRefFrame:
 *
 * Parameters:
 *		recoBuf  			   Reconstruction frame
 *		frameBuf			   Frame buffer to initialize
 *
 * Function:
 *		Initialize reference frame buffer refBuf using reconstructed buffer
 *		recoBuf. If width and height of the reference buffer do not those
 *		of the reconstructed buffer, reference buffer is reallocated.
 *
 * Returns:
 *		Pointer to reference frame
 *
 */
static	frmBuf_s  * initRefFrame( frmBuf_s * recoBuf, frmBuf_s * refBuf )
{
	/* If pic size is different, reopen with new size */
	if( !refBuf || refBuf->width != recoBuf->width
		|| refBuf->height != recoBuf->height )
	{
		frmCloseRef( refBuf );
		if( ( refBuf
			  = frmOpenRef( recoBuf->width, recoBuf->height ) )
			== NULL )
			return NULL;
	}

	/* Copy variables */
	refBuf->frameNum			= recoBuf->frameNum;
	refBuf->longTermFrmIdx		= recoBuf->longTermFrmIdx;
	refBuf->refType  			= recoBuf->refType;
	refBuf->forOutput			= recoBuf->forOutput;
	refBuf->nonExisting  		= recoBuf->nonExisting;
	refBuf->poc  				= recoBuf->poc;
	refBuf->isIDR				= recoBuf->isIDR;
	refBuf->idrPicID			= recoBuf->idrPicID;
	refBuf->hasMMCO5			= recoBuf->hasMMCO5;
	refBuf->picType  			= recoBuf->picType;
	refBuf->chromaQpIndexOffset = recoBuf->chromaQpIndexOffset;
	refBuf->cropLeftOff  		= recoBuf->cropLeftOff;
	refBuf->cropRightOff		= recoBuf->cropRightOff;
	refBuf->cropTopOff			= recoBuf->cropTopOff;
	refBuf->cropBottomOff		= recoBuf->cropBottomOff;
	refBuf->frameRate			= recoBuf->frameRate;

	return refBuf;
}


/*
 *
 * frmMakeRefFrame:
 *
 * Parameters:
 *		recoBuf  			  Reconstructed frame
 *		refBuf				  Reference frame
 *
 * Function:
 *		Generate reference frame refBuf using reconstructed frame recoBuf.
 *
 * Returns:
 *		Pointer to reference frame
 *
 */
frmBuf_s  * frmMakeRefFrame( frmBuf_s * recoBuf, frmBuf_s * refBuf )
{
	u_int8	* p;

	refBuf = initRefFrame( recoBuf, refBuf );
	if( refBuf == NULL )
		return NULL;

	/* Swap luma pointers */
	p		   = refBuf->y;
	refBuf->y  = recoBuf->y;
	recoBuf->y = p;

	/* Swap chroma U pointers */
	p		   = refBuf->u;
	refBuf->u  = recoBuf->u;
	recoBuf->u = p;

	/* Swap chroma V pointers */
	p		   = refBuf->v;
	refBuf->v  = recoBuf->v;
	recoBuf->v = p;

	return refBuf;
}
