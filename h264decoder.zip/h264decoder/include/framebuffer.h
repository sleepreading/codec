/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#ifndef _FRAMEBUFFER_H_
#define  	_FRAMEBUFFER_H_     


#include	 "globals.h"


#define  	FRM_NON_REF_PIC  	   0
#define  	FRM_SHORT_TERM_PIC	   1
#define  	FRM_LONG_TERM_PIC	   2


typedef struct _frmBuf_s
{
	u_int8			 * y;
	u_int8			 * u;
	u_int8			 * v;

			  int	   width;
			  int	   height;

	int32			   frameNum;
	int32			   picNum;
			  int	   longTermFrmIdx;
			  int	   longTermPicNum;
			  int	   refType;  								//	< non-ref, short term or long term >		    
			  int	   forOutput;								//	< If this frame is waiting for output >  	    
			  int	   nonExisting;
	int32			   poc;
			  int	   isIDR;
			  int	   idrPicID;
			  int	   hasMMCO5;
			  int	   picType;
			  int	   chromaQpIndexOffset;

			  int	   sceneCut;

	unsigned		   cropLeftOff;
	unsigned		   cropRightOff;
	unsigned		   cropTopOff;
	unsigned		   cropBottomOff;
/*modifyed by 
			  f loat    frameRate;
*/
	//add by 
	          int      frameRate;
}	 frmBuf_s;


typedef struct _mbAttributes_s
{
	int  	  * sliceMap;
	int8	  * mbTypeTable;
	int8	  * qpTable;
	int8	  * refIdxTable;
	int  	  * cbpTable;
	int8	  * ipModesUpPred;
	motVec_s  * motVecTable;
	int8	  * numCoefUpPred[ 3 ];
	int8	  * filterModeTab;
	int8	  * alphaOffset;
	int8	  * betaOffset;
}	 mbAttributes_s;


frmBuf_s  * frmOpen( mbAttributes_s ** mbData, int width, int height ) ;

frmBuf_s  * frmOpenRef( int width, int height ) ;

void		frmClose( frmBuf_s * recoBuf, mbAttributes_s * mbData ) ;

void		frmCloseRef( frmBuf_s * ref ) ;

frmBuf_s  * frmMakeRefFrame( frmBuf_s * recoBuf, frmBuf_s * refBuf ) ;


#endif
