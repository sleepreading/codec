/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _NCCGLOB_H_
#define  	_NCCGLOB_H_     


#include	 <stdlib.h>  										//for memory allocation functions and exit		    
#include	 "debug.h"


/*
 * Common error indication values
 */

#define  	NCC_OK		  1
#define  	NCC_ERROR	  -1


/*
 * Wrappers for memory allocation functions
 *
 * These wrappers are intended to replace standard C functions 
 * malloc, calloc, realloac and free. They differ from standard functions
 * in automatically including the check against NULL pointer. If a NULL
 * pointer is detected, nccExit is called. One may also
 * build some debugging features in these functions.
 *
 * Define NCC_ALLOC_NO_NULL_CHECK if the check against NULL pointer is not 
 * wanted. This define may be used e.g. in a Win32 codec backed up with
 * structured error handling 
 */

#ifdef NCC_ALLOC_NO_NULL_CHECK
   #define nccMalloc malloc
   #define nccCalloc calloc
   #define nccRealloc realloc
   #define nccFree free

#else
void  * nccMalloc( size_t size ) ;
void  * nccCalloc( size_t num, size_t size ) ;
void  * nccRealloc( void * memblock, size_t size ) ;
#define  	nccFree  	free
#endif


/*
 * Wrapper for exit
 *
 * This wrapper is intended to be used instead of standard C function like
 * exit and abort. In a normal command-line executable nccExit is an alias
 * to exit, but in a Win32 DLL nccExit just disables the usage of the codec
 * instance by causing an exception which is then handled by an upper-level
 * exception handler.
 */

#ifdef WIN32DLL
   void nccExitWin32DLL(int status);

   #define nccExit(status) \
   { \
	  deb2f(stderr, "nccExit in file %s, line %d.\n", __FILE__, __LINE__); \
	  nccExitWin32DLL(status); \
   }

#else
#define  	nccExit( status )									/*< >											  */  \
				{																									  \
					deb2f( stderr, "nccExit in file %s, line %d.\n", __FILE__, __LINE__ );                            \
					exit( status );  																				  \
				}
#endif


/*
 * nccAssert
 *
 * An assertion is a macro or function that complains loudly if an assumption
 * is not true. The macro is defined to 0 for the release version of the
 * software. For the debug version (_DEBUG defined), the macro causes an exit
 * (using nccExit).
 */

#ifdef _DEBUG
   #define nccAssert(booleanExpr) \
	  if (booleanExpr) \
		 0; \
	  else \
		 nccExit(2)

#else
#define  	nccAssert( booleanExpr )	  0
#endif


#endif
