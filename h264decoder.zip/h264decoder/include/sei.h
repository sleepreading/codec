/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _SEI_H_
#define  	_SEI_H_  						   

#define  	SCN_TRANS_TYPE_NO				   0
#define  	SCN_TRANS_TYPE_FADE_TO_BLACK	   1
#define  	SCN_TRANS_TYPE_FADE_FROM_BLACK	   2
#define  	SCN_TRANS_TYPE_UNSPECIFY_COLOR	   3
#define  	SCN_TRANS_TYPE_DISSOLVE  		   4
#define  	SCN_TRANS_TYPE_WIPE  			   5
#define  	SCN_TRANS_TYPE_UNSPECIFY_MIX	   6
#define  	SCN_TRANS_TYPE_MAX				   6

#define  	SEI_ERR_ILLEGAL_VALUE			   -2
#define  	SEI_ERROR						   -1
#define  	SEI_OK							   0


typedef struct
{
	unsigned  int  sceneId;
	unsigned  int  sceneTransitionType;
	unsigned  int  secondSceneId;
}	 sceneInfo_s;

sceneInfo_s  * seiSceneOpen( ) ;

void		   seiSceneClose( sceneInfo_s * scene ) ;

int  		   seiSceneInfo( ) ;

#endif
