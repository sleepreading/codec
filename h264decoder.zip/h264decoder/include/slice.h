/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _SLICE_H_
#define  	_SLICE_H_	  


#include	 "globals.h"
#include	 "bitbuffer.h"
#include	 "framebuffer.h"
#include	 "motcomp.h"
#include	 "parameterset.h"
#include	 "dpb.h"
#ifdef ERROR_CONCEALMENT
#include "errorconcealment.h"
#endif

/* Error codes */
#define  	SLICE_ERR_NON_EXISTING_PPS		  -5
#define  	SLICE_ERR_NON_EXISTING_SPS		  -4
#define  	SLICE_ERR_UNSUPPORTED_FEATURE	  -3
#define  	SLICE_ERR_ILLEGAL_VALUE  		  -2
#define  	SLICE_ERROR  					  -1
#define  	SLICE_OK						  0


#define  	MAX_SLICE_GROUP_NUM  			  8

#define  	MAX_NUM_OF_REORDER_CMDS  		  17
#define  	MAX_NUM_OF_MMCO_OPS  			  35


typedef struct _sliceMMCO_s
{
	unsigned  int  memory_management_control_operation;
	unsigned  int  difference_of_pic_nums_minus1;
	unsigned  int  long_term_pic_num;
	unsigned  int  long_term_frame_idx;
	unsigned  int  max_long_term_frame_idx_plus1;
}	 sliceMMCO_s;


typedef struct _sliceRefPicListReorderCmd_s
{
	unsigned  int  reordering_of_pic_nums_idc;
	unsigned  int  abs_diff_pic_num_minus1;
	unsigned  int  long_term_pic_num;
}	 sliceRefPicListReorderCmd_s;



typedef struct _slice_s
{

/* Copied from NAL deader */
			  int				 nalType;
			  int				 nalRefIdc;

	u_int32  					 maxFrameNum;

	unsigned  int				 isIDR;
	unsigned  int				 qp;
	unsigned  int				 picHasMMCO5;

  /*
   * These are slice header syntax elements
   */

	unsigned  int				 first_mb_in_slice;
	unsigned  int				 slice_type;
	unsigned  int				 pic_parameter_set_id;
	unsigned  int				 frame_num;

/* unsigned int  field_pic_flag; */
/* unsigned int  bottom_field_flag; */

	unsigned  int				 idr_pic_id;

	unsigned  int				 pic_order_cnt_lsb;
	int32						 delta_pic_order_cnt_bottom;

	int32						 delta_pic_order_cnt_0;
	int32						 delta_pic_order_cnt_1;

	unsigned  int				 redundant_pic_cnt;

/* unsigned int  direct_spatial_mv_pred_flag; */

	unsigned  int				 num_ref_idx_active_override_flag;
	unsigned  int				 num_ref_idx_l0_active_minus1;	//	< unsigned int num_ref_idx_l1_active_minus1;    
																//		>										    

	unsigned  int				 ref_pic_list_reordering_flag0;
	sliceRefPicListReorderCmd_s  reorderCmdList[ MAX_NUM_OF_REORDER_CMDS ];

/* pred_weight_table() */

/* if( nal_unit_type  = =  5 ) */
	unsigned  int				 no_output_of_prior_pics_flag;
	unsigned  int				 long_term_reference_flag;
/* else */
	unsigned  int				 adaptive_ref_pic_marking_mode_flag;
	sliceMMCO_s  				 mmcoCmdList[ MAX_NUM_OF_MMCO_OPS ];

			  int				 slice_qp_delta;

/* unsigned int  sp_for_switch_flag; */
/* int			 slice_qs_delta; */

	unsigned  int				 disable_deblocking_filter_idc;
			  int				 slice_alpha_c0_offset_div2;
			  int				 slice_beta_offset_div2;

	unsigned  int				 slice_group_change_cycle;

}	 slice_s;


slice_s  * sliceOpen( ) ;

void	   sliceClose( slice_s * slice ) ;

int  	   sliceGetHeader( slice_s * slice, seq_parameter_set_s * spsList[ ], pic_parameter_set_s * ppsList[ ], 
						   bitbuffer_s * bitbuf ) ;

int sliceDecodeMacroblocks(slice_s *slice, frmBuf_s *recoBuf, dpb_s *dpb,
#ifdef ERROR_CONCEALMENT
						   errorConcealment_s *pEc,
#endif
pic_parameter_set_s *pps,
						   mbAttributes_s
*mbData, int sliceID,
bitbuffer_s *bitbuf);

int  sliceInitRefPicList( dpb_s * dpb, frmBuf_s * refPicList[ ], int numRefPicActive ) ;


#endif
