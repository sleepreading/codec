/*!  \file
 *	   panovasic.h
 *	\brief
 *	   List of contributors and PANOVASIC copyright information.
 *
 *	\par Copyright statements
	\verbatim

  This source code has been made available to you by PANOVASIC on an AS-IS
  basis Anyone receiving this source is licensed under PANOVASIC
  copyrights to use it in any way he or she deems fit��including
  copying it��modifying it��compiling it��and redistributing it either with 
  or without modifications��

  Any person who transfers this source code or any derivative work
  must include the PANOVASIC copyright notice��this paragraph��and the
  preceding two paragraphs in the transferred software.

  COPYRIGHT  PANOVASIC	CORPORATION 2005
  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC

   \endverbatim
*******************************************************************************************************************/

