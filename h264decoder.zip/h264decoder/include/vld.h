/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _VLC_H_
#define  	_VLC_H_     


#include	 "bitbuffer.h"


#define  	VLD_OK							0
#define  	VLD_ERROR						-1
#define  	VLD_ERR_MAX_CW_LEN_EXCEEDED  	-2


typedef struct _vldMBtype_s
{
	int  type;
	int  intraType;
	int  intraMode;
	int  interMode;
	int  inter8x8modes[ 4 ];
	int  cbpY;
	int  cbpC;
	int  cbpChromaDC;
}	 vldMBtype_s;


		  void	vldInvZigZagScan4x4( int * src, int dest[ BLK_SIZE ][ BLK_SIZE ] ) ;


unsigned  int	vldGetUVLC( bitbuffer_s * bitbuf ) ;

		  int	vldGetSignedUVLC( bitbuffer_s * bitbuf ) ;

u_int32  		vldGetUVLClong( bitbuffer_s * bitbuf ) ;

int32			vldGetSignedUVLClong( bitbuffer_s * bitbuf ) ;

		  int	getLumaBlkCbp( int cbpY ) ;

		  void	setChromaCbp( int nc, int * cbpDC, int * cbp ) ;

unsigned  int	vldGetFLC( bitbuffer_s * bitbuf, int len ) ;

unsigned  int	vldGetRunIndicator( bitbuffer_s * bitbuf ) ;

		  int	vldGetMBtype( bitbuffer_s * bitbuf, vldMBtype_s * hdr, int picType ) ;

		  int	vldGetIntraPred( bitbuffer_s * bitbuf, int8 * ipTab ) ;

		  int	vldGetChromaIntraPred( bitbuffer_s * bitbuf ) ;

		  int	vldGetMotVecs( bitbuffer_s * bitbuf, int interMode, int numRefFrames, int * refNum, int predVecs[ ][ 2 ], 
							   int numVecs ) ;

		  int	vldGetCBP( bitbuffer_s * bitbuf, int type, int * cbpY, int * cbpChromaDC, int * cbpC ) ;

		  int	vldGetDeltaqp( bitbuffer_s * bitbuf, int * delta_qp ) ;

		  int	vldGetLumaDCcoeffs( bitbuffer_s * bitbuf, int coef[ 4 ][ 4 ], int8 * numCoefUpPred, int8 * numCoefLeftPred, 
									int mbAvailBits ) ;

		  int	vldGetLumaCoeffs( bitbuffer_s * bitbuf, int mbType, int intraType, int * cbpY, int coef[ 4 ][ 4 ][ 4 ][ 4 ], 
								  int8 * numCoefUpPred, int8 * numCoefLeftPred, int mbAvailBits ) ;

		  void	vldGetZeroLumaCoeffs( int8 * numCoefUpPred, int8 * numCoefLeftPred ) ;

		  int	vldGetChromaDCcoeffs( bitbuffer_s * bitbuf, int coef[ 2 ][ 2 ][ 2 ], int * cbpDC ) ;

		  int	vldGetChromaCoeffs( bitbuffer_s * bitbuf, int coef[ 2 ][ 2 ][ 2 ][ 4 ][ 4 ], int * cbp, int8 * numCoefUpPred, 
									int8 * numCoefUpPredV, int8 * numCoefLeftPred, int8 * numCoefLeftPredV, int mbAvailBits ) ;

		  void	vldGetZeroChromaCoeffs( int8 * numCoefUpPredU, int8 * numCoefUpPredV, int8 numCoefLeftPred[ 2 ][ 2 ] ) ;

		  void	vldGetAllCoeffs( int8 * numCoefUpPredY, int8 * numCoefUpPredU, int8 * numCoefUpPredV, int8 * numCoefLeftPredY, 
								 int8 numCoefLeftPredC[ 2 ][ 2 ] ) ;


#endif
