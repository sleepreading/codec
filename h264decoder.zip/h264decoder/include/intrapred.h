/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#ifndef _INTRAPRED_H_
#define  	_INTRAPRED_H_	  


#include	 "globals.h"
#include	 "framebuffer.h"


/*
 * Intra prediction modes
 */

/* Luma 4x4 prediction modes */
#define  	IPR_NUM_MODES1				 9
#define  	IPR_MODE_VERT				 0
#define  	IPR_MODE_HOR				 1
#define  	IPR_MODE_DC  				 2
#define  	IPR_MODE_DIAG_DOWN_LEFT  	 3
#define  	IPR_MODE_DIAG_DOWN_RIGHT	 4
#define  	IPR_MODE_VERT_RIGHT  		 5
#define  	IPR_MODE_HOR_DOWN			 6
#define  	IPR_MODE_VERT_LEFT			 7
#define  	IPR_MODE_HOR_UP  			 8
#define  	IPR_MODE_NA  				 9

/* Luma 16x16 prediction modes */
#define  	IPR_NUM_MODES2				 4
#define  	IPR_MODE2_VERT				 0
#define  	IPR_MODE2_HOR				 1
#define  	IPR_MODE2_DC				 2
#define  	IPR_MODE2_PLANE  			 3

/* Chroma 8x8 prediction modes */
#define  	IPR_CHROMA_NUM_MODES		 4
#define  	IPR_CHROMA_MODE_DC			 0
#define  	IPR_CHROMA_MODE_HOR  		 1
#define  	IPR_CHROMA_MODE_VERT		 2
#define  	IPR_CHROMA_MODE_PLANE		 3


void  iprPredLuma4x4blocks( int coef[ BLK_PER_MB ][ BLK_PER_MB ][ BLK_SIZE ][ BLK_SIZE ], u_int8 * reco, int picWidth, 
							int8 * ipModes, int mbAvailBits, int mbIdxX, int mbIdxY, int cbp, int qp ) ;

int   iprPredLuma16x16( u_int8 predBlk[ MBK_SIZE ][ MBK_SIZE ], int mode, u_int8 * reco, int picWidth, int mbAvailBits ) ;

int   iprPredChroma( u_int8 pred[ MBK_SIZE / 2 ][ MBK_SIZE ], u_int8 * recoU, u_int8 * recoV, int width, int mbAvailBits, 
					 int mode ) ;

void  iprClearMBintraPred( int8 * modesLeftPred, int8 * modesUpPred ) ;

void  iprPutIntraModes( int mbAvailBits, int8 * ipModes, int8 * modesLeftPred, int8 * modesUpPred ) ;


#endif
