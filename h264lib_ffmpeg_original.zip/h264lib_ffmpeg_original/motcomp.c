/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifdef CHECK_MV_RANGE
#include <stdio.h>
#endif

#include	 "globals.h"
#include	 "motcomp.h"
#include	 "framebuffer.h"


#define  	ONEFOURTH1	   20
#define  	ONEFOURTH2	   -5
#define  	ONEFOURTH3	   1


static	const  int	numModeMotVecs[ MOT_NUM_MODES + 1 ] =		//< >											    
					{ 0,  1,  2,  2,  4,  8,  8,  16 };

static	const  int	numModeMotVecs8x8[ 4 ] =					//< >											    
					{ 1,  2,  2,  4 };

static	const  int	blockShapes[ MOT_NUM_MODES ][ 2 ] =  		//< >											    
					{ { 4,	4 },  { 4,	2 },  { 2,	4 },  { 2,	2 },  { 2,	1 },  { 1,	2 },  { 1,	1 } };

static	const  int	blockShapes8x8[ ][ 2 ] =					//< >											    
					{ { 2,	2 },  { 2,	1 },  { 1,	2 },  { 1,	1 } };


#ifdef CHECK_MV_RANGE
extern int maxVerticalMvRange;
#endif


/*
 * findPredMotVec
 *
 * Parameters:
 *		refTab				  Table containing reference frame number
 *							  for the whole frame
 *		motVecs  			  Motion vectors for the whole frame
 *		blksPerLine  		  The number of blocks per line
 *		mbAvailBits  		  Availability of neighboring macroblocks
 *		blkX				  Horizontal block index
 *		blkY				  Vertical block index
 *		blkIdxX  			  Horizontal block index within macroblock
 *		blkIdxY  			  Vertical block index within macroblock
 *		shapeX				  Width of the motion block in blocks
 *		shapeY				  Height of the motion block in blocks
 *
 * Function:
 *		Find the prediction vector for the current motion block.
 *
 * Returns:
 *		Prediction vector
 *
 */
static	motVec_s  findPredMotVec( int8 * refTab, motVec_s * vecs, 
								  int blksPerLine, int mbAvailBits, 
								  int blkIdxX, int blkIdxY, int shapeX, 
								  int shapeY )
{
	static	const  motVec_s  zeroVec = { 0 , 0 } ;
	motVec_s const *vecA;
	motVec_s const *vecB;
	motVec_s const *vecC;
	motVec_s  vecX;
	int  	  refNum, refLeft, refUp, refUpRight;
	int  	  blkIdxXright;

  /*
   *	   |	   |
   *	 D | B	   | C
   *   ----+-------+----
   *	 A |	   |
   *	   |   X   |
   *	   |	   |
   *
   *   X is current block. Motion vectors from named
   *   positions are used for prediction
   */

  /*
   * Fetch vectors and reference frame numbers of blocks A, B and C
   */

	if( blkIdxX > 0 || ( mbAvailBits & 1 ) )
	{
		vecA	= &vecs[ -1 ];
		refLeft = refTab[ -1 ];
	}
	else
	{															//	A is outside the picture => A is zero and ref   
																//		is -1									    
		vecA	= &zeroVec;
		refLeft = -1;
	}

	if( blkIdxY > 0 || ( mbAvailBits & 2 ) )
	{
		vecB  = &vecs[ -blksPerLine ];
		refUp = refTab[ -blksPerLine ];
	}
	else
	{															//	B is outside the picture => B is zero and ref   
																//		is -2									    
		vecB  = &zeroVec;
		refUp = -2;
	}

	blkIdxXright = blkIdxX + shapeX - 1;
	if( ( blkIdxXright != BLK_PER_MB / 2
		  && ( blkIdxXright & blkIdxY ) != 0 )
		|| ( blkIdxY == 0
			 && ( blkIdxXright < BLK_PER_MB - 1
					 ? !( mbAvailBits & 2 )
					: !( mbAvailBits & 4 )
				)
		   )
	  )
	{															//	C is outside the picture or is not available    
																//		=> C = D								    
		if( ( blkIdxY > 0
			  && ( blkIdxX > 0 || ( mbAvailBits & 1 ) ) )
			|| ( blkIdxY == 0
				 && ( blkIdxX > 0
						 ? ( mbAvailBits & 2 )
						: ( mbAvailBits & 8 )
					)
			   )
		  )
		{
			vecC	   = &vecs[ -blksPerLine - 1 ];
			refUpRight = refTab[ -blksPerLine - 1 ];
		}
		else
		{														//	  D is too outside the picture => C is not	    
																//		  available If both B abd C are not  	    
																//		  available then C = B = A				    
			if( refUp == -2 )
			{
				vecC	   = vecB = vecA;
				refUpRight = refUp = refLeft;
			}													//		if only C is not available then C is zero   
			else
			{
				vecC	   = &zeroVec;
				refUpRight = -1;
			}
		}
	}
	else
	{															//	C is inside the picture and is available	    
		vecC	   = &vecs[ -blksPerLine + shapeX ];
		refUpRight = refTab[ -blksPerLine + shapeX ];
	}

	refNum = refTab[ 0 ];

  /*
   * If only one of the neighboring block has the same reference
   * frame number as the  current block, predict from that block.
   */

	if( refLeft == refNum )
	{
		if( refUp != refNum && refUpRight != refNum )
			return *vecA;
	}
	else
	{
		if( refUp == refNum )
		{
			if( refUpRight != refNum )
				return *vecB;
		}
		else
			if( refUpRight == refNum )
				return *vecC;
	}

  /*
   * Directional prediction for block sizes 8x16, 16x8
   */

	if( shapeX + shapeY == 6 )
	{
		if( shapeX == 2 )
		{														//	  Is it 8x16?								    
			if( blkIdxX == 0 && refLeft == refNum )
				return *vecA;
			else
				if( blkIdxX != 0 && refUpRight == refNum )
					return *vecC;
		}
		else
		{														//	  It is 16x8								    
			if( blkIdxY == 0 && refUp == refNum )
				return *vecB;
			else
				if( blkIdxY != 0 && refLeft == refNum )
					return *vecA;
		}
	}

  /*
   * If everything else fails, do median prediction.
   */

	/* Median of x co-ordinates */
	if( vecB->x < vecA->x )
	{
		if( vecA->x < vecC->x )
			vecX.x = vecA->x;									//		vecB->x < vecA->x < vecC->x  			    
		else
			if( vecC->x < vecB->x )
				vecX.x = vecB->x;								//		  vecC->x < vecB->x < vecA->x			    
			else
				vecX.x = vecC->x;								//		  vecB->x < vecC->x < vecA->x			    
	}
	else
	{															//	vecA->x < vecB->x							    
		if( vecC->x < vecA->x )
			vecX.x = vecA->x;									//		vecC->x < vecA->x < vecB->x  			    
		else
			if( vecB->x < vecC->x )
				vecX.x = vecB->x;								//		  vecA->x < vecB->x < vecC->x			    
			else
				vecX.x = vecC->x;								//		  vecA->x < vecC->x < vecB->x			    
	}

	/* Median of y co-ordinates */
	if( vecB->y < vecA->y )
	{
		if( vecA->y < vecC->y )
			vecX.y = vecA->y;									//		vecB->y < vecA->y < vecC->y  			    
		else
			if( vecC->y < vecB->y )
				vecX.y = vecB->y;								//		  vecC->y < vecB->y < vecA->y			    
			else
				vecX.y = vecC->y;								//		  vecB->y < vecC->y < vecA->y			    
	}
	else
	{															//	vecA->y < vecB->y							    
		if( vecC->y < vecA->y )
			vecX.y = vecA->y;									//		vecC->y < vecA->y < vecB->y  			    
		else
			if( vecB->y < vecC->y )
				vecX.y = vecB->y;								//		  vecA->y < vecB->y < vecC->y			    
			else
				vecX.y = vecC->y;								//		  vecA->y < vecC->y < vecB->y			    
	}

	return vecX;
}


/*
 *
 * mcpGetNumMotVecs:
 *
 * Parameters:
 *		mode				  Motion mode (16x16, 8x16, 16x8, 8x8)
 *		inter8x8modes		  Subblocks modes (8x8, 4x8, 8x4, 4x4)
 *
 * Function:
 *		Get the number of motion vectors that need to be decoded for given
 *		MB mode and subblock modes.
 *	    
 * Returns:
 *		Number of motion vectors.
 *
 */
int  mcpGetNumMotVecs( int interMode, int inter8x8modes[ 4 ] )
{
	int  numVecs;

	if( interMode < MOT_8x8 )
		numVecs = numModeMotVecs[ interMode ];
	else
	{
		numVecs  = numModeMotVecs8x8[ inter8x8modes[ 0 ] ];
		numVecs += numModeMotVecs8x8[ inter8x8modes[ 1 ] ];
		numVecs += numModeMotVecs8x8[ inter8x8modes[ 2 ] ];
		numVecs += numModeMotVecs8x8[ inter8x8modes[ 3 ] ];
	}

	return numVecs;
}


/*
 *
 * mcpClearMBmotion:
 *
 * Parameters:
 *		mbIdxX				  MB horizontal location
 *		mbIdxY				  MB vertical location
 *		picWidth			  Frame buffer width in pixels
 *		refTab				  Reference index buffer
 *		refNum				  Reference frame index
 *		motVecs  			  Motion vector buffer
 *
 * Function:
 *		Set MB reference frame indices to refNum.
 *	    
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  mcpClearMBmotion( int mbIdxX, int mbIdxY, int picWidth, 
						int8 * refTab, int refNum, motVec_s * motVecs )
{
	int  		blksPerLine = picWidth / BLK_SIZE;
	int  		blkIdxX, blkIdxY;
	motVec_s  * vecPtr;
	int8	  * refPtr;

	vecPtr = &motVecs[ mbIdxY * BLK_PER_MB * blksPerLine + mbIdxX * BLK_PER_MB ];
	refPtr = &refTab[ mbIdxY * BLK_PER_MB * blksPerLine + mbIdxX * BLK_PER_MB ];

	for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
	{
		for( blkIdxX = 0;  blkIdxX < BLK_PER_MB;  blkIdxX++ )
		{
			vecPtr[ blkIdxX ].x = 0;
			vecPtr[ blkIdxX ].y = 0;
			refPtr[ blkIdxX ]	= ( int8 ) refNum;
		}
		vecPtr += blksPerLine;
		refPtr += blksPerLine;
	}
}


/*
 *
 * mcpPutVectors:
 *
 * Parameters:
 *		mbIdxX				  MB horizontal location
 *		mbIdxY				  MB vertical location
 *		ref  				  Reference frame buffer list
 *		mode				  Motion mode (16x16, 8x16, 16x8, 8x8)
 *		subblockModes		  Subblocks modes (8x8, 4x8, 8x4, 4x4)
 *		subblockRef  		  Subblocks reference indices
 *		picWidth			  Frame buffer width in pixels
 *		refTab				  Reference index buffer
 *		hasRef				  Indicates whether MB has ref. other than 0
 *		motVecs  			  Motion vector buffer
 *		mbAvailBIts  		  Availability of neighboring macroblocks
 *		diffVecs			  Decoded delta vectors
 *
 * Function:
 *		Put decoded motion vectors to the motion vector buffer
 *	    
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  mcpPutVectors( int mbIdxX, int mbIdxY, int mode, int * subblockModes, 
					 int * subblockRef, int picWidth, int8 * refTab, 
					 int numRefFrames, motVec_s * motVecs, int mbAvailBits, 
					 int diffVecs[ BLK_PER_MB * BLK_PER_MB ][ 2 ] )
{
	int  		blksPerLine;
	int  		shapeX, shapeY;
	int  		blkIdxX, blkIdxY;
	motVec_s	predVec;
	int  		y;
	int  	  * inter8x8modes;
	int  		blk8X, blk8Y;
	int  		blkAddr;
	int8	  * refIdxPtr;
	motVec_s  * vecPtr;
	int  	  * diffVecPtr;
	int  		refIdx, refIdx2;
	int  		mvX, mvY;

	blksPerLine = picWidth / BLK_SIZE;
	blkAddr  	= mbIdxY * BLK_PER_MB * blksPerLine + mbIdxX * BLK_PER_MB;
	refTab	  = &refTab[ blkAddr ];
	motVecs   = &motVecs[ blkAddr ];

  /*
   * Put ref. indices to the ref. index buffer.
   */

	refIdxPtr = refTab;

	if( numRefFrames > 1 && mode <= MOT_8x8 )
	{

	/*
	 * Put reference indices for 16x16, 16x8, 8x16 or 8x8 blocks
	 */

		shapeX = blockShapes[ mode - 1 ][ 0 ];
		shapeY = blockShapes[ mode - 1 ][ 1 ];

		for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  
			 blkIdxY += shapeY )
		{

			refIdx = *subblockRef++;
			refIdx2 = ( shapeX == 2 ) ? *subblockRef++ : refIdx;

			for( y = 0;  y < shapeY;  y++ )
			{
				refIdxPtr[ 0 ]	= ( int8 ) refIdx;
				refIdxPtr[ 1 ]	= ( int8 ) refIdx;
				refIdxPtr[ 2 ]	= ( int8 ) refIdx2;
				refIdxPtr[ 3 ]	= ( int8 ) refIdx2;
				refIdxPtr	   += blksPerLine;
			}
		}
	}
	else
	{

	/*
	 * All reference indices are zero
	 */

		for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
		{
			refIdxPtr[ 0 ]	= 0;
			refIdxPtr[ 1 ]	= 0;
			refIdxPtr[ 2 ]	= 0;
			refIdxPtr[ 3 ]	= 0;
			refIdxPtr	   += blksPerLine;
		}
	}


  /*
   * Put motion vectors to the motion vector buffer.
   */

	diffVecPtr = diffVecs[ 0 ];

	if( mode < MOT_8x8 )
	{

	/*
	 * Put motion vectors for 16x16, 16x8 and 8x16 blocks
	 */

		shapeX = blockShapes[ mode - 1 ][ 0 ];					//	  Width of mot. block in blocks  			    
		shapeY = blockShapes[ mode - 1 ][ 1 ];					//	  Height of mot. block in blocks			    

		for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  
			 blkIdxY += shapeY )
		{
			for( blkIdxX = 0;  blkIdxX < BLK_PER_MB;  
				 blkIdxX += shapeX )
			{

				blkAddr = blkIdxY * blksPerLine + blkIdxX;
				vecPtr	= &motVecs[ blkAddr ];

				/* Get predicted vector */
				predVec
				= findPredMotVec( refTab + blkAddr, vecPtr, blksPerLine, mbAvailBits, blkIdxX, 
								  blkIdxY, shapeX, shapeY );

				mvX = predVec.x + ( *diffVecPtr++ );
				mvY = predVec.y + ( *diffVecPtr++ );

#ifdef CHECK_MV_RANGE
		if (mvX < -2048*4 || mvX > (2048*4-1)) {
		  printf("Horizontal MV component range violation %f\n", 0.25*mvX);
		}
		if (mvY < -maxVerticalMvRange*4 || mvY > (maxVerticalMvRange*4-1)) {
		  printf("Vertical MV component range violation %f\n", 0.25*mvY);
		}
#endif

				for( y = 0;  y < shapeY;  y++ )
				{												//		  �8x8 block							    
					vecPtr[ 0 ].x = ( int16 ) mvX;
					vecPtr[ 0 ].y = ( int16 ) mvY;
					vecPtr[ 1 ].x = ( int16 ) mvX;
					vecPtr[ 1 ].y = ( int16 ) mvY;
					if( shapeX == 4 )
					{											//			�16x8 and 16x16 blocks				    
						vecPtr[ 2 ].x = ( int16 ) mvX;
						vecPtr[ 2 ].y = ( int16 ) mvY;
						vecPtr[ 3 ].x = ( int16 ) mvX;
						vecPtr[ 3 ].y = ( int16 ) mvY;
					}
					vecPtr += blksPerLine;
				}

			}
		}
	}
	else
	{

	/*
	 * Put motion vectors for 8x8 subblocks and smaller. Each 8x8 block can
	 * have either 8x8, 8x4, 4x8 or 4x4 mode. So, each 8x8 subblock may have
	 * different number of motion vectors.
	 */

		inter8x8modes = subblockModes;

		/* Scan all 8x8 subblocks */
		for( blk8Y = 0;  blk8Y < BLK_PER_MB;  
			 blk8Y += BLK_PER_MB / 2 )
		{
			for( blk8X = 0;  blk8X < BLK_PER_MB;  
				 blk8X += BLK_PER_MB / 2 )
			{

				/* Get shape of the current 8x8 subblock */
				shapeX = blockShapes8x8[ inter8x8modes[ 0 ] ][ 0 ];
				shapeY = blockShapes8x8[ inter8x8modes[ 0 ] ][ 1 ];

				/* Scan all motion blocks (8x8, 8x4, 4x8 or 4x4) in a 8x8 subblock */
				for( blkIdxY = blk8Y;  
					 blkIdxY < blk8Y + BLK_PER_MB / 2;  
					 blkIdxY += shapeY )
				{
					for( blkIdxX = blk8X;  
						 blkIdxX < blk8X + BLK_PER_MB / 2;  
						 blkIdxX += shapeX )
					{

						blkAddr = blkIdxY * blksPerLine + blkIdxX;
						vecPtr = &motVecs[ blkAddr ];

						/* Get predicted vector */
						predVec
						= findPredMotVec( refTab + blkAddr, vecPtr, blksPerLine, mbAvailBits, 
										  blkIdxX, blkIdxY, shapeX, shapeY );

						mvX = predVec.x + ( *diffVecPtr++ );
						mvY = predVec.y + ( *diffVecPtr++ );

#ifdef CHECK_MV_RANGE
			if (mvX < -2048*4 || mvX > (2048*4-1)) {
			  printf("Horizontal MV component range violation %f\n", 0.25*mvX);
			}
			if (mvY < -maxVerticalMvRange*4 || mvY > (maxVerticalMvRange*4-1)) {
			  printf("Vertical MV component range violation %f\n", 0.25*mvY);
			}
#endif

						/* Put vectors for current motion block */

						/* 4x4 block */
						vecPtr[ 0 ].x = ( int16 ) mvX;
						vecPtr[ 0 ].y = ( int16 ) mvY;
						if( shapeY == 1 )
						{
							if( shapeX == 2 )
							{									//				8x4 block						    
								vecPtr[ 1 ].x = ( int16 ) mvX;
								vecPtr[ 1 ].y = ( int16 ) mvY;
							}
						}
						else
						{										//			  4x8 block  						    
							vecPtr[ blksPerLine ].x = ( int16 ) mvX;
							vecPtr[ blksPerLine ].y = ( int16 ) mvY;
							if( shapeX == 2 )
							{									//				8x8 block						    
								vecPtr[ 1 ].x = ( int16 ) mvX;
								vecPtr[ 1 ].y = ( int16 ) mvY;
								vecPtr[ blksPerLine + 1 ].x = ( int16 ) mvX;
								vecPtr[ blksPerLine + 1 ].y = ( int16 ) mvY;
							}
						}

					}
				}

				inter8x8modes++;
			}
		}

	}

}


/*
 *
 * mcpPutSkipModeVectors:
 *
 * Parameters:
 *		mbIdxX				  MB horizontal location
 *		mbIdxY				  MB vertical location
 *		picWidth			  Frame buffer width in pixels
 *		refTab				  Reference index buffer
 *		motVecs  			  Motion vector buffer
 *		mbAvailBits  		  Availability of neighboring macroblocks
 *
 * Function:
 *		Put skip mode motion vectors to the motion vector buffer
 *	    
 * Returns:
 *		1 if macroblock MV is zero, 0 otherwise*	  *  	 *		*	   *	  *  	 *		*	   *	  *     
 */
int  mcpPutSkipModeVectors( int mbIdxX, int mbIdxY, int picWidth, 
							int8 * refTab, motVec_s * motVecs, 
							int mbAvailBits )
{
	int  		blks = picWidth / BLK_SIZE;
	int  		blkX = mbIdxX * BLK_PER_MB;
	int  		blkY = mbIdxY * BLK_PER_MB;
	motVec_s	vec;
	int  		blkIdxY;
	motVec_s  * vecPtr;
	int8	  * refPtr;
	int  		zeroMvFlag;
	int  		blkAddr;

	blkAddr = blkY * blks + blkX;

	vecPtr	= &motVecs[ blkAddr ];
	refPtr	= &refTab[ blkAddr ];

	/* If upper or left MB is not available or has zero motion, skip mode vec is zero */
	if( !( mbAvailBits & 1 ) || !( mbAvailBits & 2 )
		|| ( refPtr[ -1 ] == 0 && vecPtr[ -1 ].x == 0
			 && vecPtr[ -1 ].y == 0 )
		|| ( refPtr[ -blks ] == 0 && vecPtr[ -blks ].x == 0
			 && vecPtr[ -blks ].y == 0 )
	  )
	{
		vec.x	   = 0;
		vec.y	   = 0;
		zeroMvFlag = 1;
	}
	/* Otherwise, skip mode vec is predicted */
	else
	{
		refPtr[ 0 ] = 0;
		vec  		= findPredMotVec( refPtr, vecPtr, blks, mbAvailBits, 0, 0, 4, 4 );
		zeroMvFlag = 0;

#ifdef CHECK_MV_RANGE
	if (vec.x < -2048*4 || vec.x > (2048*4-1)) {
	  printf("Horizontal MV component range violation %f\n", 0.25*vec.x);
	}
	if (vec.y < -maxVerticalMvRange*4 || vec.y > (maxVerticalMvRange*4-1)) {
	  printf("Vertical MV component range violation %f\n", 0.25*vec.y);
	}
#endif
	}

	for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
	{
		vecPtr[ 0 ]  = vec;
		vecPtr[ 1 ]  = vec;
		vecPtr[ 2 ]  = vec;
		vecPtr[ 3 ]  = vec;
		refPtr[ 0 ]  = 0;
		refPtr[ 1 ]  = 0;
		refPtr[ 2 ]  = 0;
		refPtr[ 3 ]  = 0;

		vecPtr		+= blks;
		refPtr		+= blks;
	}

	return zeroMvFlag;
}


/*
 * mcpCopyMacroblock:
 *
 * Parameters:
 *		reco				  Reconstruction frame
 *		ref  				  Reference frame
 *		pixX				  Horizontal pixel position
 *		pixY				  Vertical pixel position
 *		picWidth			  Frame width in pixels
 *
 * Function:
 *		Copy macroblock data to reconstruction frame from
 *		co-located macroblock �n reference frame.
 *	    
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  mcpCopyMacroblock( frmBuf_s * reco, frmBuf_s * ref, int pixX, 
						 int pixY, int picWidth )
{
	u_int8	* recoPtr;
	u_int8	* refPtr;
	int  	  c, i, j;
	int  	  refWidth = picWidth;

	recoPtr = &reco->y[ pixY * picWidth + pixX ];
	refPtr	= &ref->y[ pixY * refWidth + pixX ];

	for( j = 0;  j < MBK_SIZE;  
		 j++, recoPtr += picWidth, refPtr += refWidth )
	{
		for( i = 0;  i < MBK_SIZE;	i += 4 )
		{
			recoPtr[ i + 0 ] = refPtr[ i + 0 ];
			recoPtr[ i + 1 ] = refPtr[ i + 1 ];
			recoPtr[ i + 2 ] = refPtr[ i + 2 ];
			recoPtr[ i + 3 ] = refPtr[ i + 3 ];
		}
	}

	picWidth >>= 1;
	refWidth >>= 1;
	pixX	 >>= 1;
	pixY	 >>= 1;

	recoPtr    = &reco->u[ pixY * picWidth + pixX ];
	refPtr	   = &ref->u[ pixY * refWidth + pixX ];

	for( c = 0;  c < 2;  c++ )
	{
		for( j = 0;  j < MBK_SIZE / 2;  
			 j++, recoPtr += picWidth, refPtr += refWidth )
		{
			for( i = 0;  i < MBK_SIZE / 2;	i += 4 )
			{
				recoPtr[ i + 0 ] = refPtr[ i + 0 ];
				recoPtr[ i + 1 ] = refPtr[ i + 1 ];
				recoPtr[ i + 2 ] = refPtr[ i + 2 ];
				recoPtr[ i + 3 ] = refPtr[ i + 3 ];
			}
		}
		recoPtr = &reco->v[ pixY * picWidth + pixX ];
		refPtr	= &ref->v[ pixY * refWidth + pixX ];
	}

}


/* Fetch luma reference pixels. If pixel lies outside the picture, */
/* nearest boundary pixel is fetched */
static	void  getRefArea( u_int8 * frm, u_int8 * buf, int picWidth, 
						  int picHeight, int x, int y, int w, 
						  int h )
{
	int  	  i, y2;
	u_int8	* linePtr;

	y2 = y + h;

	if( x < 0 )
	{
		x = max( 1 - w, x );
		do
		{
			linePtr = frm + clip( 0, picHeight - 1, y ) * picWidth;
			i = x;
			do
			{
				*buf++ = *linePtr;
				i++;
			}	 while( i < 0 );
			do
			{
				*buf++ = *linePtr++;
				i++;
			}	 while( i < x + w );
			y++;
		}	 while( y < y2 );
	}
	else
		if( x + w <= picWidth )
		{
			do
			{
				linePtr = frm + clip( 0, picHeight - 1, y ) * picWidth + x;
				i = 0;
				do
				{
					*buf++ = *linePtr++;
					i++;
				}	 while( i < w );
				y++;
			}	 while( y < y2 );
		}
		else
		{
			x = min( picWidth - 1, x );
			do
			{
				linePtr = frm + clip( 0, picHeight - 1, y ) * picWidth + x;
				i = x;
				do
				{
					*buf++ = *linePtr++;
					i++;
				}	 while( i < picWidth );
				linePtr--;
				do
				{
					*buf++ = *linePtr;
					i++;
				}	 while( i < x + w );
				y++;
			}	 while( y < y2 );
		}

}


/* Fetch chroma reference pixels. If pixel lies outside the picture, */
/* nearest boundary pixel is fetched */
static	void  getRefAreaC( u_int8 * frm, u_int8 * buf, int picWidth, 
						   int picHeight, int x, int y )
{
	int  	  y2, inc;
	u_int8	* linePtr;

	y2 = y + 3;

	if( x < 0 )
	{
		inc = x < -1 ? 0 : 1;
		do
		{
			linePtr = frm + clip( 0, picHeight - 1, y ) * picWidth;
			*buf++	 = *linePtr;
			*buf++	 = *linePtr;
			linePtr += inc;
			*buf++	 = *linePtr;
			y++;
		}	 while( y < y2 );
	}
	else
		if( x + 2 < picWidth )
		{
			do
			{
				linePtr = frm + clip( 0, picHeight - 1, y ) * picWidth + x;
				*buf++ = *linePtr++;
				*buf++ = *linePtr++;
				*buf++ = *linePtr++;
				y++;
			}	 while( y < y2 );
		}
		else
		{
			inc = x + 2 <= picWidth ? 1 : 0;
			frm = frm + picWidth - 1 - inc;
			do
			{
				linePtr = frm + clip( 0, picHeight - 1, y ) * picWidth;
				*buf++	 = *linePtr;
				linePtr += inc;
				*buf++	 = *linePtr;
				*buf++	 = *linePtr;
				y++;
			}	 while( y < y2 );
		}

}


/*
 *
 * mcpGetPred:
 *
 * Parameters:
 *		predY				  Return pointer for predicted luma pixels
 *		predC				  Return pointer for predicted chroma pixels
 *		mbIdxX				  MB horizontal location
 *		mbIdxY				  MB vertical location
 *		ref  				  Reference frame buffer list
 *		picWidth			  Frame buffer width in pixels
 *		picHeight			  Frame buffer height in pixels
 *		motVecs  			  Motion vector buffer
 *		refTab				  Reference index buffer
 *
 * Function:
 *		Get motion compensated prediction for both luma and chroma MBs
 *	    
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  mcpGetPred( u_int8 predY[ MBK_SIZE ][ MBK_SIZE ], u_int8 predC[ MBK_SIZE / 2 ][ MBK_SIZE ], 
				  int mbIdxX, int mbIdxY, frmBuf_s ** ref, int picWidth, 
				  int picHeight, motVec_s * motVecs, int8 * refTab )
{
	int  	  blksPerLine;
	int  	  blkX, blkY;
	int  	  blkIdxX, blkIdxY;
	int  	  blkAddr;
	int  	  refWidth;
	int  	  i, j;
	u_int8	* refPtr;
	int  	  xPos, yPos, xInt, yInt, xFrac, yFrac;
	int  	  coef0, coef1, coef2, coef3;
	int  	  c;
	int  	  tmp;
	int32	  tmp2;
	int  	  picWidthC;
	int  	  picHeightC;
	u_int8	  refArea[ 9 * 9 ];
	int  	  block[ BLK_SIZE + 2 + 3 ][ BLK_SIZE ];
	int  	  lineIdx, colIdx;
	u_int8	* refC[ 2 ];
	int  	  refNum;
	u_int8	  ( * predPtr )[ MBK_SIZE ];


	picWidthC	= picWidth / 2;
	picHeightC	= picHeight / 2;
	blksPerLine = picWidth / BLK_SIZE;

	for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
	{
		for( blkIdxX = 0;  blkIdxX < BLK_PER_MB;  blkIdxX++ )
		{

			blkX	= ( mbIdxX * BLK_PER_MB + blkIdxX );
			blkY	= ( mbIdxY * BLK_PER_MB + blkIdxY );
			blkAddr = blkY * blksPerLine + blkX;

			/* Absolute coordinates of the prediction block */
			xPos	= blkX * BLK_SIZE * 4 + motVecs[ blkAddr ].x;
			yPos   = blkY * BLK_SIZE * 4 + motVecs[ blkAddr ].y;
			if(xPos>352)
			{
			xPos=xPos;
			
			}

	  /*
	   * Get luma prediction
	   */

			xInt   = xPos >> 2;
			yInt   = yPos >> 2;
			xFrac  = xPos & 3;
			yFrac  = yPos & 3;

			refNum = refTab[ blkAddr ];
			refPtr = ref[ refNum ]->y;
			predPtr
			= ( u_int8 ( * ) [ MBK_SIZE ] ) &predY[ blkIdxY * BLK_SIZE ][ blkIdxX * BLK_SIZE ];

			/* Full-pel precision */
			if( xFrac == 0 && yFrac == 0 )
			{
				if( xInt >= 0 && xInt <= picWidth - BLK_SIZE
					&& yInt >= 0
					&& yInt <= picHeight - BLK_SIZE )
				{
					refPtr	 += yInt * picWidth + xInt;
					refWidth  = picWidth;
				}
				else
				{
					getRefArea( refPtr, refArea, picWidth, picHeight, xInt, yInt, 4, 4 );
					refPtr	 = refArea;
					refWidth = 4;
				}
				for( j = 0;  j < BLK_SIZE;	j++ )
				{
					predPtr[ j ][ 0 ] = refPtr[ j * refWidth + 0 ];
					predPtr[ j ][ 1 ] = refPtr[ j * refWidth + 1 ];
					predPtr[ j ][ 2 ] = refPtr[ j * refWidth + 2 ];
					predPtr[ j ][ 3 ] = refPtr[ j * refWidth + 3 ];
				}
			}													//		Horizontal fullpel precision, vertical	    
																//			subpel precision					    
			else
				if( xFrac == 0 )
				{
					if( xInt >= 0
						&& xInt <= picWidth - BLK_SIZE
						&& yInt > 1
						&& yInt < picHeight - BLK_SIZE - 2
					  )
					{
						refPtr	 += yInt * picWidth + xInt;
						refWidth  = picWidth;
					}
					else
					{
						getRefArea( refPtr, refArea, picWidth, picHeight, xInt, yInt - 2, 4, 
									9 );
						refPtr	 = refArea + 2 * 4;
						refWidth = 4;
					}											//			Vertical interpolation				    
					for( j = 0;  j < BLK_SIZE;	j++ )
					{
						for( i = 0;  i < BLK_SIZE;	i++ )
						{
							tmp = ( ONEFOURTH1
									* ( refPtr[ j * refWidth + i ]
										+ refPtr[ ( j + 1 ) * refWidth + i ] )
									+ ONEFOURTH2
									  * ( refPtr[ ( j - 1 ) * refWidth + i ]
										  + refPtr[ ( j + 2 ) * refWidth + i ] )
									+ ONEFOURTH3
									  * ( refPtr[ ( j - 2 ) * refWidth + i ]
										  + refPtr[ ( j + 3 ) * refWidth + i ] ) + 16
								  )
								  >> 5;
							predPtr[ j ][ i ] = ( u_int8 ) clip( 0, 255, tmp );
						}
					}											//			Linear interp.						    
					if( ( yFrac & 1 ) != 0 )
					{
						lineIdx = yFrac >> 1;
						for( j = 0;  j < BLK_SIZE;	j++ )
						{
							for( i = 0;  i < BLK_SIZE;	i++ )
							{
								predPtr[ j ][ i ]
								= ( u_int8 ) 
									( ( predPtr[ j ][ i ]
										+ refPtr[ ( j + lineIdx ) * refWidth + i ] + 1 )
									  >> 1
									);
							}
						}
					}
				}												//		  Horizontal subpel precision, vertical     
																//			  fullpel precision  				    
				else
					if( yFrac == 0 )
					{
						if( xInt > 1
							&& xInt < picWidth - BLK_SIZE - 2
							&& yInt >= 0
							&& yInt <= picHeight - BLK_SIZE
						  )
						{
							refPtr	 += yInt * picWidth + xInt;
							refWidth  = picWidth;
						}
						else
						{
							getRefArea( refPtr, refArea, picWidth, picHeight, xInt - 2, yInt, 
										9, 4 );
							refPtr	 = refArea + 2;
							refWidth = 9;
						}										//			  Horizontal interpolation			    
						for( j = 0;  j < BLK_SIZE;	j++ )
						{
							for( i = 0;  i < BLK_SIZE;	i++ )
							{
								tmp = ( ONEFOURTH1
										* ( refPtr[ j * refWidth + i ]
											+ refPtr[ j * refWidth + i + 1 ] )
										+ ONEFOURTH2
										  * ( refPtr[ j * refWidth + i - 1 ]
											  + refPtr[ j * refWidth + i + 2 ] )
										+ ONEFOURTH3
										  * ( refPtr[ j * refWidth + i - 2 ]
											  + refPtr[ j * refWidth + i + 3 ] ) + 16
									  )
									  >> 5;
								predPtr[ j ][ i ] = ( u_int8 ) clip( 0, 255, tmp );
							}
						}										//			  Linear interp.					    
						if( ( xFrac & 1 ) != 0 )
						{
							colIdx = xFrac >> 1;
							for( j = 0;  j < BLK_SIZE;	j++ )
							{
								for( i = 0;  i < BLK_SIZE;	i++ )
								{
									predPtr[ j ][ i ]
									= ( u_int8 ) 
										( ( predPtr[ j ][ i ]
											+ refPtr[ j * refWidth + i + colIdx ] + 1 )
										  >> 1
										);
								}
							}
						}
					}											//			The rest of the sub-pel positions	    
																//				require 9x9 reference pixel are     
					else
					{
						if( xInt > 1
							&& xInt < picWidth - BLK_SIZE - 2
							&& yInt > 1
							&& yInt < picHeight - BLK_SIZE - 2
						  )
						{
							refPtr	 += yInt * picWidth + xInt;
							refWidth  = picWidth;
						}
						else
						{
							getRefArea( refPtr, refArea, picWidth, picHeight, xInt - 2, 
										yInt - 2, 9, 9 );
							refPtr	 = refArea + 2 * 9 + 2;
							refWidth = 9;
						}

						/* Horizontal 1/2-pel precision, vertical sub-pel precision */
						if( xFrac == 2 )
						{										//			  horizontal interpolation			    
							for( j = -2;  j < BLK_SIZE + 3;  
								 j++ )
							{
								for( i = 0;  i < BLK_SIZE;	i++ )
								{
									tmp = ( ONEFOURTH1
											* ( refPtr[ j * refWidth + i ]
												+ refPtr[ j * refWidth + i + 1 ] )
											+ ONEFOURTH2
											  * ( refPtr[ j * refWidth + i - 1 ]
												  + refPtr[ j * refWidth + i + 2 ] )
											+ ONEFOURTH3
											  * ( refPtr[ j * refWidth + i - 2 ]
												  + refPtr[ j * refWidth + i + 3 ] )
										  );
									block[ 2 + j ][ i ] = tmp;
								}
							}									//				Vertical interpolation			    
							for( j = 0;  j < BLK_SIZE;	j++ )
							{
								for( i = 0;  i < BLK_SIZE;	i++ )
								{
									tmp2 = ( ONEFOURTH1
											 * ( ( int32 ) 
												   ( block[ 2 + j ][ i ]
													 + block[ 2 + j + 1 ][ i ] )
											   )
											 + ONEFOURTH2
											   * ( ( int32 ) 
													 ( block[ 2 + j - 1 ][ i ]
													   + block[ 2 + j + 2 ][ i ] )
												 )
											 + ONEFOURTH3
											   * ( ( int32 ) 
													 ( block[ 2 + j - 2 ][ i ]
													   + block[ 2 + j + 3 ][ i ] )
												 ) + 512
										   )
										   >> 10;
									predPtr[ j ][ i ] = ( u_int8 ) clip( 0, 255, tmp2 );
								}
							}									//				Linear interp.					    
							if( ( yFrac & 1 ) != 0 )
							{
								lineIdx = 2 + ( yFrac >> 1 );
								for( j = 0;  j < BLK_SIZE;	j++ )
								{
									for( i = 0;  i < BLK_SIZE;	i++ )
									{
										tmp = ( block[ lineIdx + j ][ i ] + 16 ) >> 5;
										predPtr[ j ][ i ]
										= ( u_int8 ) 
											( ( predPtr[ j ][ i ] + clip( 0, 255, tmp ) + 1 )
											  >> 1 );
									}
								}
							}

						}										//			  Vertical 1/2-pel precision,		    
																//				  horizontal 1/4-pel precision	    
						else
							if( yFrac == 2 )
							{									//				Vertical interpolation			    
								for( i = -2;  i < BLK_SIZE + 3;  i++ )
								{
									for( j = 0;  j < BLK_SIZE;	j++ )
									{
										tmp = ( ONEFOURTH1
												* ( refPtr[ j * refWidth + i ]
													+ refPtr[ ( j + 1 ) * refWidth + i ] )
												+ ONEFOURTH2
												  * ( refPtr[ ( j - 1 ) * refWidth + i ]
													  + refPtr[ ( j + 2 ) * refWidth + i ] )
												+ ONEFOURTH3
												  * ( refPtr[ ( j - 2 ) * refWidth + i ]
													  + refPtr[ ( j + 3 ) * refWidth + i ] )
											  );
										block[ 2 + i ][ j ] = tmp;
									}
								}								//				  Horizontal interpolation		    
								for( i = 0;  i < BLK_SIZE;	i++ )
								{
									for( j = 0;  j < BLK_SIZE;	j++ )
									{
										tmp2 = ( ONEFOURTH1
												 * ( ( int32 ) 
													   ( block[ 2 + i ][ j ]
														 + block[ 2 + i + 1 ][ j ] )
												   )
												 + ONEFOURTH2
												   * ( ( int32 ) 
														 ( block[ 2 + i - 1 ][ j ]
														   + block[ 2 + i + 2 ][ j ] )
													 )
												 + ONEFOURTH3
												   * ( ( int32 ) 
														 ( block[ 2 + i - 2 ][ j ]
														   + block[ 2 + i + 3 ][ j ] )
													 ) + 512
											   )
											   >> 10;
										predPtr[ j ][ i ] = ( u_int8 ) clip( 0, 255, tmp2 );
									}
								}								//				  Linear interp.				    
								colIdx = 2 + ( xFrac >> 1 );
								for( i = 0;  i < BLK_SIZE;	i++ )
								{
									for( j = 0;  j < BLK_SIZE;	j++ )
									{
										tmp = ( block[ colIdx + i ][ j ] + 16 ) >> 5;
										predPtr[ j ][ i ]
										= ( u_int8 ) 
											( ( predPtr[ j ][ i ] + clip( 0, 255, tmp ) + 1 )
											  >> 1 );
									}
								}

							}									//				Horizontal&vertical 1/4-pel  	    
																//					precision -> diagonal		    
																//					interpolation				    
							else
							{									//				Vertical interpolation			    
								colIdx = xFrac >> 1;
								for( j = 0;  j < BLK_SIZE;	j++ )
								{
									for( i = 0;  i < BLK_SIZE;	i++ )
									{
										tmp = ( ONEFOURTH1
												* ( refPtr[ j * refWidth + i + colIdx ]
													+ refPtr
														[ ( j + 1 ) * refWidth + i + colIdx ]
												  )
												+ ONEFOURTH2
												  * ( refPtr
														[ ( j - 1 ) * refWidth + i + colIdx ]
													  + refPtr
														  [ ( j + 2 ) * refWidth + i + colIdx ]
													)
												+ ONEFOURTH3
												  * ( refPtr
														[ ( j - 2 ) * refWidth + i + colIdx ]
													  + refPtr
														  [ ( j + 3 ) * refWidth + i + colIdx ]
													) + 16
											  )
											  >> 5;
										predPtr[ j ][ i ] = ( u_int8 ) clip( 0, 255, tmp );
									}
								}								//				  Horizontal interpolation		    
								lineIdx = yFrac >> 1;
								for( j = 0;  j < BLK_SIZE;	j++ )
								{
									for( i = 0;  i < BLK_SIZE;	i++ )
									{
										tmp = ( ONEFOURTH1
												* ( refPtr[ ( j + lineIdx ) * refWidth + i ]
													+ refPtr
														[ ( j + lineIdx ) * refWidth + i + 1 ]
												  )
												+ ONEFOURTH2
												  * ( refPtr
														[ ( j + lineIdx ) * refWidth + i - 1 ]
													  + refPtr
														  [ ( j + lineIdx ) * refWidth + i
															+ 2 ]
													)
												+ ONEFOURTH3
												  * ( refPtr
														[ ( j + lineIdx ) * refWidth + i - 2 ]
													  + refPtr
														  [ ( j + lineIdx ) * refWidth + i
															+ 3 ]
													) + 16
											  )
											  >> 5;
										predPtr[ j ][ i ]
										= ( u_int8 ) 
											( ( predPtr[ j ][ i ] + clip( 0, 255, tmp ) + 1 )
											  >> 1 );
									}
								}

							}
					}


	  /*
	   * Get chroma prediction
	   */

			/* Bilinear interpolation coefficients */
			coef0 = ( 8 - ( xPos & 7 ) ) * ( 8 - ( yPos & 7 ) );
			coef1 = ( xPos & 7 ) * ( 8 - ( yPos & 7 ) );
			coef2 = ( 8 - ( xPos & 7 ) ) * ( yPos & 7 );
			coef3 = ( xPos & 7 ) * ( yPos & 7 );

			/* Chroma vectors have 1/8 chroma pel precision */
			xInt  = xPos >> 3;
			yInt  = yPos >> 3;

			if( xInt >= 0 && xInt < picWidthC - BLK_SIZE / 2
				&& yInt >= 0
				&& yInt < picHeightC - BLK_SIZE / 2 )
			{
				refC[ 0 ] = &ref[ refNum ]->u[ yInt * picWidthC + xInt ];
				refC[ 1 ] = &ref[ refNum ]->v[ yInt * picWidthC + xInt ];
				refWidth = picWidthC;
			}
			else
			{
				getRefAreaC( ref[ refNum ]->u, refArea, picWidthC, picHeightC, xInt, yInt );
				getRefAreaC( ref[ refNum ]->v, refArea + 3 * 3, picWidthC, picHeightC, xInt, 
							 yInt );
				refC[ 0 ] = refArea;
				refC[ 1 ] = refArea + 3 * 3;
				refWidth  = 3;
			}
			for( c = 0;  c < 2;  c++ )
			{													//		2 chroma components  					    
				for( j = 0;  j < BLK_SIZE / 2;	j++ )
				{
					for( i = 0;  i < BLK_SIZE / 2;	i++ )
					{
						tmp = ( coef0 * refC[ c ][ ( j ) * refWidth + i ]
								+ coef1 * refC[ c ][ ( j ) * refWidth + i + 1 ]
								+ coef2 * refC[ c ][ ( j + 1 ) * refWidth + i ]
								+ coef3 * refC[ c ][ ( j + 1 ) * refWidth + i + 1 ] + 32
							  )
							  >> 6;
						predC[ blkIdxY * ( BLK_SIZE / 2 ) + j ]
						  [ c * ( MBK_SIZE / 2 ) + blkIdxX * ( BLK_SIZE / 2 ) + i ]
						= ( u_int8 ) tmp;
					}
				}
			}

		}
	}

}
