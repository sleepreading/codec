/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _DEBUG_H_
#define  	_DEBUG_H_	   

// If this is defined, debug messages go to stdout
#define  	DEB_STDOUT	   

#if defined ( DEB_FILE ) || defined ( DEB_STDOUT ) || defined ( DEB_DEBUGGER )
																//Debug output wanted							    

#include	 <stdio.h>

#ifdef __cplusplus
extern "C"
{
#endif

/*
	* Function prototypes
	*/

#ifdef DEB_PERF
	  #define deb(dummy) 0
	  #define debp(dummy) 0
	  #define debPrintf(dummy) 0
	  #define deb0p(format) 0
	  #define deb1p(format, p1) 0
	  #define deb2p(format, p1, p2) 0
	  #define deb3p(format, p1, p2, p3) 0
	  #define deb4p(format, p1, p2, p3, p4) 0
	  #define deb5p(format, p1, p2, p3, p4, p5) 0
	  #define deb0f(stream, format) 0
	  #define deb1f(stream, format, p1) 0
	  #define deb2f(stream, format, p1, p2) 0
	  #define deb3f(stream, format, p1, p2, p3) 0
	  #define deb4f(stream, format, p1, p2, p3, p4) 0
	  #define deb5f(stream, format, p1, p2, p3, p4, p5) 0

	  #ifdef DEB_STDOUT
		 #define debPerf printf
	  #else
		 int debPerf(const char *format, ...);
	  #endif

#else
#ifdef DEB_STDOUT
#define  	deb  	printf
#else
	  #ifdef DEBUG_OUTPUT
		 int deb_core(const char *format, ...);
		 #define deb deb_core("%08lu: ", bibNumberOfFlushedBits(buffer_global)), deb_core
	  #else
		 int deb(const char *format, ...);
	  #endif
#endif

#define  	debp	 deb

#ifdef DEB_FILELINE
		 #define debPrintf deb("%s, line %d. ", __FILE__, __LINE__), deb
#else
#define  	debPrintf	  deb
#endif

#define  	deb0p	  debPrintf
#define  	deb1p	  debPrintf
#define  	deb2p	  debPrintf
#define  	deb3p	  debPrintf
#define  	deb4p	  debPrintf
#define  	deb5p	  debPrintf

/* Internal defines to enable DEB_FILELINE */
#ifdef DEB_STDOUT
#define  	deb0ff( stream, format )						  fprintf( stream, format )
#define  	deb1ff( stream, format, p1 )					  fprintf( stream, format, p1 )
#define  	deb2ff( stream, format, p1, p2 )				  fprintf( stream, format, p1, p2 )
#define  	deb3ff( stream, format, p1, p2, p3 )			  fprintf( stream, format, p1, p2, p3 )
#define  	deb4ff( stream, format, p1, p2, p3, p4 )		  fprintf( stream, format, p1, p2, p3, p4 )
#define  	deb5ff( stream, format, p1, p2, p3, p4, p5 )	  fprintf( stream, format, p1, p2, p3, p4, p5 )
#else
		 #define deb0ff(stream, format) deb(format)
		 #define deb1ff(stream, format, p1) deb(format, p1)
		 #define deb2ff(stream, format, p1, p2) deb(format, p1, p2)
		 #define deb3ff(stream, format, p1, p2, p3) deb(format, p1, p2, p3)
		 #define deb4ff(stream, format, p1, p2, p3, p4) deb(format, p1, p2, p3, p4)
		 #define deb5ff(stream, format, p1, p2, p3, p4, p5) deb(format, p1, p2, p3, p4, p5)
#endif

#ifdef DEB_FILELINE
		 #define deb0f(stream, format) \
			deb2ff(stream, "%s, line %d. ", __FILE__, __LINE__), \
			deb0ff(stream, format)

		 #define deb1f(stream, format, p1) \
			deb2ff(stream, "%s, line %d. ", __FILE__, __LINE__), \
			deb1ff(stream, format, p1)

		 #define deb2f(stream, format, p1, p2) \
			deb2ff(stream, "%s, line %d. ", __FILE__, __LINE__), \
			deb2ff(stream, format, p1, p2)

		 #define deb3f(stream, format, p1, p2, p3) \
			deb2ff(stream, "%s, line %d. ", __FILE__, __LINE__), \
			deb3ff(stream, format, p1, p2, p3)

		 #define deb4f(stream, format, p1, p2, p3, p4) \
			deb2ff(stream, "%s, line %d. ", __FILE__, __LINE__), \
			deb4ff(stream, format, p1, p2, p3, p4)

		 #define deb5f(stream, format, p1, p2, p3, p4, p5) \
			deb2ff(stream, "%s, line %d. ", __FILE__, __LINE__), \
			deb4ff(stream, format, p1, p2, p3, p4, p5)

#else
#define  	deb0f( stream, format )  						 deb0ff( stream, format )
#define  	deb1f( stream, format, p1 )  					 deb1ff( stream, format, p1 )
#define  	deb2f( stream, format, p1, p2 )  				 deb2ff( stream, format, p1, p2 )
#define  	deb3f( stream, format, p1, p2, p3 )  			 deb3ff( stream, format, p1, p2, p3 )
#define  	deb4f( stream, format, p1, p2, p3, p4 )  		 deb4ff( stream, format, p1, p2, p3, p4 )
#define  	deb5f( stream, format, p1, p2, p3, p4, p5 )  	 deb5ff( stream, format, p1, p2, p3, p4, p5 )
#endif

#define  	debPerf  	deb
#endif

#ifdef __cplusplus
}
;
#endif

#else															//no debug output wanted						    

   #define deb(dummy) 0
   #define debp(dummy) 0
   #define debPrintf(dummy) 0
   #define deb0p(format) 0
   #define deb1p(format, p1) 0
   #define deb2p(format, p1, p2) 0
   #define deb3p(format, p1, p2, p3) 0
   #define deb4p(format, p1, p2, p3, p4) 0
   #define deb5p(format, p1, p2, p3, p4, p5) 0
   #define deb0f(stream, format) 0
   #define deb1f(stream, format, p1) 0
   #define deb2f(stream, format, p1, p2) 0
   #define deb3f(stream, format, p1, p2, p3) 0
   #define deb4f(stream, format, p1, p2, p3, p4) 0
   #define deb5f(stream, format, p1, p2, p3, p4, p5) 0
   #define debPerf(dummy) 0
   #define debFree() 0
   #define debLoad(dummy) 0

#endif

#define  	debLogOutput( a, b, c )  	 0

#endif															//!defined(_DEBUG_H_)							    

// End of file
