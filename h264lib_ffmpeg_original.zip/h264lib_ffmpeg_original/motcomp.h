/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#ifndef _MOTION_H_
#define  	_MOTION_H_	   


#include	 "globals.h"
#include	 "framebuffer.h"


#define  	MOT_NUM_MODES	  7
#define  	MOT_COPY		  0
#define  	MOT_16x16		  1
#define  	MOT_16x8		  2
#define  	MOT_8x16		  3
#define  	MOT_8x8  		  4
#define  	MOT_8x4  		  5
#define  	MOT_4x8  		  6
#define  	MOT_4x4  		  7


int   mcpGetNumMotVecs( int interMode, int inter8x8modes[ 4 ] ) ;

void  mcpClearMBmotion( int mbIdxX, int mbIdxY, int picWidth, int8 * refTab, int refNum, motVec_s * motVecs ) ;

void  mcpPutVectors( int mbIdxX, int mbIdxY, int mode, int * subblockModes, int * subblockRef, int picWidth, int8 * refTab, 
					 int numRefFrames, motVec_s * motVecs, int mbAvailBits, int diffVecs[ BLK_PER_MB
																						  * BLK_PER_MB ][ 2 ] ) ;

int   mcpPutSkipModeVectors( int mbIdxX, int mbIdxY, int picWidth, int8 * refTab, motVec_s * motVecs, int mbAvailBits ) ;

void  mcpCopyMacroblock( frmBuf_s * reco, frmBuf_s * ref, int pixX, int pixY, int picWidth ) ;

void  mcpGetPred( u_int8 predY[ MBK_SIZE ][ MBK_SIZE ], u_int8 predC[ MBK_SIZE / 2 ][ MBK_SIZE ], int mbIdxX, int mbIdxY, 
				  frmBuf_s ** ref, int picWidth, int picHeight, motVec_s * motVecs, int8 * refTab ) ;


#endif
