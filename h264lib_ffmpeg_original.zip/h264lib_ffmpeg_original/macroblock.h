/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _MACROBLOCK_H_
#define  	_MACROBLOCK_H_	   


#include	 "globals.h"
#include	 "framebuffer.h"
#include	 "bitbuffer.h"


#define  	MBK_ERROR	  -1
#define  	MBK_OK		  0


typedef struct _macroblock_s
{
	int  	type;
	int  	numSkipped;

	int  	intraType;
	int  	intraMode;
	int  	intraModeChroma;

	int  	interMode;
	int  	inter8x8modes[ 4 ];
	int  	refNum[ 4 ];

	int  	qp, qpC;
	int  	idxX, idxY;
	int  	blkX, blkY;
	int  	pixX, pixY;

	int  	cbpY, cbpC, cbpChromaDC;

	u_int8	predY[ MBK_SIZE ][ MBK_SIZE ];
	u_int8	predC[ MBK_SIZE / 2 ][ MBK_SIZE ];					//	< contains both chroma components >  		    

	int  	dcCoefY[ BLK_PER_MB ][ BLK_PER_MB ];
	int  	dcCoefC[ 2 ][ BLK_PER_MB / 2 ][ BLK_PER_MB / 2 ];

	int  	coefY[ BLK_PER_MB ][ BLK_PER_MB ][ BLK_SIZE ][ BLK_SIZE ];
	int  	coefC[ 2 ][ BLK_PER_MB / 2 ][ BLK_PER_MB / 2 ][ BLK_SIZE ][ BLK_SIZE ];

	int  	mbAvailBits;

	int8	numCoefLeftPred[ BLK_PER_MB ];
	int8	numCoefLeftPredC[ 2 ][ BLK_PER_MB / 2 ];

	int8	ipModesLeftPred[ BLK_PER_MB ];

}	 macroblock_s;


void  mbkSetInitialQP( macroblock_s * mb, int qp, int chromaQpIdx ) ;

int   mbkDecode( macroblock_s * mb, frmBuf_s * reco, frmBuf_s ** ref, int numRefFrames, mbAttributes_s * mbData, 
				 int picWidth, int picHeight, int picType, int constIpred, int chromaQpIdx, int mbIdxX, int mbIdxY, 
				 void * streamBuf ) ;

#endif
