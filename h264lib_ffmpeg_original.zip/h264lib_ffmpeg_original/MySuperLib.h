
#ifndef __MY_SUPERLIB_H__ 
#define __MY_SUPERLIB_H__ 

typedef void (*DECODER_CALLBACK)(char *,char *,char *,int nIndex,int nLineSize,int nXSize,int nYSize);

// nIndex: 0 -- 127
int		StartupVideoDecoder_o(int nIndex,DECODER_CALLBACK lpCBFunc) ;
int		CleanupVideoDecoder_o();
int		RunVideoDecode_o(char *pszH264Buf,int nBufSize,int nIndex) ;

int		GetDecoderVersion_o() ;
char*	GetDecoderBuildTime_o() ;


#endif