/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#include	 "globals.h"
#include	 "invtransform.h"
#include	 "prederrordec.h"


static	const  int	  dequantCoef[ 6 ][ 8 ] =					//< >											    
					  { { 10,  13,	13,  16,  10,  13,	13,  16 },  
						{ 11,  14,	14,  18,  11,  14,	14,  18 },  
						{ 13,  16,	16,  20,  13,  16,	16,  20 },  
						{ 14,  18,	18,  23,  14,  18,	18,  23 },  
						{ 16,  20,	20,  25,  16,  20,	20,  25 },  
						{ 18,  23,	23,  29,  18,  23,	23,  29 }
					  };


static	const  int16  dequantCoefDC[ 52 ] =  					//< >											    
					  { 10 << 0,  11 << 0,	13 << 0,  14 << 0,	16 << 0,  18 << 0,	10 << 1,  11 << 1,	13 << 1,  
						14 << 1,  16 << 1,	18 << 1,  10 << 2,	11 << 2,  13 << 2,	14 << 2,  16 << 2,	18 << 2,  
						10 << 3,  11 << 3,	13 << 3,  14 << 3,	16 << 3,  18 << 3,	10 << 4,  11 << 4,	13 << 4,  
						14 << 4,  16 << 4,	18 << 4,  10 << 5,	11 << 5,  13 << 5,	14 << 5,  16 << 5,	18 << 5,  
						10 << 6,  11 << 6,	13 << 6,  14 << 6,	16 << 6,  18 << 6,	10 << 7,  11 << 7,	13 << 7,  
						14 << 7,  16 << 7,	18 << 7,  10 << 8,	11 << 8,  13 << 8,	14 << 8
					  };


static	const  int	  zeroValues[ 16 ] =						//< >											    
					  { 0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0,	0 };


/*
 *
 * pedRecoBlock:
 *
 * Parameters:
 *		pred				  Predicted pixels for a block
 *		coef				  Transformed&quantized coefficients for a block
 *		reco				  Reconstructed pixels
 *		recoWidth			  Width of reco. buffer in pixels
 *		isDc				  Does block have separate DC coefficient
 *		dcValue  			  DC coefficient
 *		qp					  Quantization parameter
 *
 * Function:
 *		Dequantize and inverse transform coefficients and add result
 *		with prediction.
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  pedRecoBlock( u_int8 pred[ BLK_SIZE ][ MBK_SIZE ], int coef[ BLK_SIZE ][ BLK_SIZE ], 
					u_int8 * reco, int recoWidth, int isDc, int dcValue, 
					int qp )
{
	int  tmpBlk[ BLK_SIZE ][ BLK_SIZE ];
	int  i, j;
	int  tmp;

	/* Compute qp/6 */
	int  qp_per = ( 43 * qp ) >> 8;

	/* Compute qp%6 */
	int  qp_rem = qp - 6 * qp_per;

	itrIDCTdequant4x4( coef, tmpBlk, dequantCoef[ qp_rem ], qp_per, isDc, dcValue );

	for( j = 0;  j < BLK_SIZE;	j++, reco += recoWidth )
	{
		for( i = 0;  i < BLK_SIZE;	i++ )
		{														//	  Add prediction error to prediction and	    
																//		  round to nearest						    
			tmp = pred[ j ][ i ]
				  + ( ( tmpBlk[ j ][ i ] + ITR_DEQUANT_ROUND ) >> ITR_DEQUANT_BITS );
																//		Clipping								    
			reco[ i ] = ( u_int8 ) ( clip( 0, 255, tmp ) );
		}
	}

}


/*
 *
 * pedRecoBlockNoAC:
 *
 * Parameters:
 *		pred				  Predicted pixels
 *		reco				  Reconstructed pixels
 *		recoWidth			  Width of reco. buffer in pixels
 *		dcValue  			  DC coefficient
 *
 * Function:
 *		All AC coefficients are zero - reconstruct using DC only.
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  pedRecoBlockNoAC( u_int8 pred[ BLK_SIZE ][ MBK_SIZE ], 
						u_int8 * reco, int recoWidth, int dcValue )
{
	int  i, j;
	int  recoDCint;
	int  tmp;

	recoDCint = ( dcValue + ITR_DEQUANT_ROUND ) >> ITR_DEQUANT_BITS;

	for( j = 0;  j < BLK_SIZE;	j++, reco += recoWidth )
	{
		for( i = 0;  i < BLK_SIZE;	i++ )
		{														//	  Add prediction error to prediction		    
			tmp  	  = pred[ j ][ i ] + recoDCint;  			//		Clipping								    
			reco[ i ] = ( u_int8 ) ( clip( 0, 255, tmp ) );
		}
	}

}


/*
 *
 * pedRecoBlockNoCoef:
 *
 * Parameters:
 *		pred				  Predicted pixels
 *		reco				  Reconstructed pixels
 *		recoWidth			  Width of reco. buffer in pixels
 *
 * Function:
 *		All coefficients are zero - just copy prediction.
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  pedRecoBlockNoCoef( 
			  u_int8 pred[ BLK_SIZE ][ MBK_SIZE ], u_int8 * reco, 
			  int recoWidth )
{
	int  j;

	for( j = 0;  j < BLK_SIZE;	j++ )
	{
		reco[ 0 ]  = pred[ j ][ 0 ];
		reco[ 1 ]  = pred[ j ][ 1 ];
		reco[ 2 ]  = pred[ j ][ 2 ];
		reco[ 3 ]  = pred[ j ][ 3 ];
		reco	  += recoWidth;
	}
}


/*
 *
 * pedRecoLumaMB:
 *
 * Parameters:
 *		pred				  Predicted pixels for an MB
 *		dcCoef				  Transformed&quantized DC coefficients for an MB
 *		hasDc				  Do blocks have separate DC coefficients
 *		coef				  Transformed&quantized coefficients for an MB
 *		reco				  Reconstructed pixels
 *		recoWidth			  Width of reco. buffer in pixels
 *		qp					  Quantization parameter
 *		cbp  				  Coded Block Pattern
 *
 * Function:
 *		Reconstruct macroblock from prediction and transformed coefficients
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  pedRecoLumaMB( u_int8 pred[ MBK_SIZE ][ MBK_SIZE ], int dcCoef[ BLK_PER_MB ][ BLK_PER_MB ], 
					 int hasDC, int coef[ BLK_PER_MB ][ BLK_PER_MB ][ BLK_SIZE ][ BLK_SIZE ], 
					 u_int8 * reco, int recoWidth, int qp, int cbp )
{
		   int		 dcCoefTmp[ BLK_PER_MB ][ BLK_PER_MB ];
	const  int	   * dcCoefPtr;
		   int		 blkIdxX, blkIdxY;
		   int		 dcValue;
		   u_int8  * predPtr;


  /*
   * Inverse transform and quantize luma DC (if 16x16 intra mode)
   */

	if( hasDC )
	{															//	4x4 DC Inv. Hadamard						    
		itrIHadaDequant4x4( dcCoef, dcCoefTmp, dequantCoefDC[ qp ] );
		dcCoefPtr = &dcCoefTmp[ 0 ][ 0 ];
	}
	else
		dcCoefPtr = zeroValues;


  /*
   * Luma block reconstruction
   */

	dcValue = 0;
	predPtr = pred[ 0 ];

	for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
	{
		for( blkIdxX = 0;  blkIdxX < BLK_PER_MB;  blkIdxX++ )
		{

			dcValue = *dcCoefPtr++;

			if( ( cbp & 1 ) == 0 )
			{
				if( dcValue == 0 )
				{
					pedRecoBlockNoCoef( 
						( u_int8 ( * ) [ MBK_SIZE ] ) &predPtr[ blkIdxX * BLK_SIZE ], 
						&reco[ blkIdxX * BLK_SIZE ], recoWidth );
				}
				else
				{
					pedRecoBlockNoAC( 
						( u_int8 ( * ) [ MBK_SIZE ] ) &predPtr[ blkIdxX * BLK_SIZE ], 
						&reco[ blkIdxX * BLK_SIZE ], recoWidth, dcValue );
				}
			}
			else
			{
				pedRecoBlock( ( u_int8 ( * ) [ MBK_SIZE ] ) &predPtr[ blkIdxX * BLK_SIZE ], 
				  coef[ blkIdxY ][ blkIdxX ], &reco[ blkIdxX * BLK_SIZE ], recoWidth, hasDC, 
				  dcValue, qp );
			}

			cbp >>= 1;
		}

		reco	+= BLK_SIZE * recoWidth;
		predPtr += BLK_SIZE * MBK_SIZE;
	}

}


/*
 *
 * pedRecoChromaMB:
 *
 * Parameters:
 *		pred				  Predicted pixels for an MB
 *		dcCoef				  Transformed&quantized DC coefficients for an MB
 *		coef				  Transformed&quantized coefficients for an MB
 *		recoU				  Reconstructed U pixels
 *		recoV				  Reconstructed V pixels
 *		recoWidth			  Width of reco. buffer in pixels
 *		qp					  Quantization parameter
 *		cbpDC				  Coded Block Pattern for DC coefficient blocks
 *		cbp  				  Coded Block Pattern for AC coefficient blocks
 *
 * Function:
 *		Reconstruct chroma blocks from prediction and coefficients.
 *
 * Returns:
 *		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*		-*  
 */
void  pedRecoChromaMB( 
			  u_int8 pred[ MBK_SIZE / 2 ][ MBK_SIZE ], int dcCoef[ 2 ][ BLK_PER_MB / 2 ][ BLK_PER_MB / 2 ], 
			  int coef[ 2 ][ BLK_PER_MB / 2 ][ BLK_PER_MB
											   / 2 ][ BLK_SIZE ][ BLK_SIZE ], 
			  u_int8 * recoU, u_int8 * recoV, int recoWidth, 
			  int qp, int cbpDC, int cbp )
{
		   int		 dcCoefTmp[ BLK_PER_MB / 2 ][ BLK_PER_MB
												  / 2 ];
	const  int	   * dcCoefPtr;
		   int		 comp;
		   int		 blkIdxX, blkIdxY;
		   int		 dcValue;
		   u_int8  * reco;
		   u_int8  * predPtr;

  /* 
   * Chroma MB reconstruction
   */

	for( comp = 0;	comp < 2;  comp++ )
	{

		if( cbpDC & ( 1 << comp ) )
		{														//	  2x2 DC inverse transform and dequant		    
			itrIDCTdequant2x2( dcCoef[ comp ], dcCoefTmp, dequantCoefDC[ qp ] );
			dcCoefPtr = &dcCoefTmp[ 0 ][ 0 ];
		}
		else													//	  DC coefficients are zero					    
			dcCoefPtr = zeroValues;

		reco	= comp == 0 ? recoU : recoV;
		predPtr = &pred[ 0 ][ comp * ( MBK_SIZE / 2 ) ];

	/*
	 * AC reconstruction
	 */

		for( blkIdxY = 0;  blkIdxY < BLK_PER_MB / 2;  
			 blkIdxY++ )
		{
			for( blkIdxX = 0;  blkIdxX < BLK_PER_MB / 2;  
				 blkIdxX++ )
			{

				dcValue = *dcCoefPtr++;

				if( ( cbp & 1 ) == 0 )
				{
					if( dcValue == 0 )
					{
						pedRecoBlockNoCoef( 
							( u_int8 ( * ) [ MBK_SIZE ] ) &predPtr[ blkIdxX * BLK_SIZE ], 
							&reco[ blkIdxX * BLK_SIZE ], recoWidth );
					}
					else
					{
						pedRecoBlockNoAC( 
							( u_int8 ( * ) [ MBK_SIZE ] ) &predPtr[ blkIdxX * BLK_SIZE ], 
							&reco[ blkIdxX * BLK_SIZE ], recoWidth, dcValue );
					}
				}
				else
				{
					pedRecoBlock( ( u_int8 ( * ) [ MBK_SIZE ] ) &predPtr[ blkIdxX * BLK_SIZE ], 
					  coef[ comp ][ blkIdxY ][ blkIdxX ], &reco[ blkIdxX * BLK_SIZE ], 
					  recoWidth, 1, dcValue, qp );
				}

				cbp >>= 1;
			}

			reco	+= BLK_SIZE * recoWidth;
			predPtr += BLK_SIZE * MBK_SIZE;
		}

	}

}
