/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _PRED_ERROR_DEC_H_
#define  	_PRED_ERROR_DEC_H_	   


#include	 "globals.h"


void  pedRecoBlock( u_int8 pred[ BLK_SIZE ][ MBK_SIZE ], int coef[ BLK_SIZE ][ BLK_SIZE ], u_int8 * reco, int recoWidth, 
					int isDc, int dcValue, int qp ) ;

void  pedRecoBlockNoAC( u_int8 pred[ BLK_SIZE ][ MBK_SIZE ], u_int8 * reco, int recoWidth, int dcValue ) ;

void  pedRecoBlockNoCoef( u_int8 pred[ BLK_SIZE ][ MBK_SIZE ], u_int8 * reco, int recoWidth ) ;

void  pedRecoLumaMB( u_int8 pred[ MBK_SIZE ][ MBK_SIZE ], int dcCoef[ BLK_PER_MB ][ BLK_PER_MB ], int hasDc, int coef[ BLK_PER_MB ][ BLK_PER_MB ][ BLK_SIZE ][ BLK_SIZE ], 
					 u_int8 * reco, int recoWidth, int qp, int cbpY ) ;

void pedRecoChromaMB(u_int8 pred[MBK_SIZE/2][MBK_SIZE],
					 int dcCoef[2][BLK_PER_MB/2][BLK_PER_MB/2],
					 int coef[2][BLK_PER_MB/2][BLK_PER_MB/2][BLK_SIZE][BLK_SIZE],
					 u_int8 *recoU, u_int8 *recoV, int recoWidth, int qp,
					 int cbpDC, int cbp);


#endif
