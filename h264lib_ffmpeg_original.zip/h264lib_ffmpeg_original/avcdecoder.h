/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#ifndef _AVCDECODER_H_
#define  	_AVCDECODER_H_				    


#define  	AVCD_ERROR						-1
#define  	AVCD_OK  						0
#define  	AVCD_OK_STREAM_NOT_DECODED		1
#define  	AVCD_OK_FRAME_NOT_AVAILABLE  	2


typedef  void  avcdDecoder_t;


typedef struct _avcdYUVbuffer_s
{
					void   * y;
					void   * u;
					void   * v;

					int  	 picType;
/*//modified by 
			  l ong	int  	 poc;
*/
//add
					int  	 poc;
//end
	unsigned		int  	 idrCnt;
					int  	 isIDR;

					int  	 width;
					int  	 height;

	unsigned				 cropLeftOff;
	unsigned				 cropRightOff;
	unsigned				 cropTopOff;
	unsigned				 cropBottomOff;
/*modifyed by 
					f loat	 frameRate;
*/
	// add
                    int	 frameRate;
/*modifyed by 
			  l ong	int  	 numDecodedBits;
*/
// add
					int  	 numDecodedBits;
}	 avcdYUVbuffer_s;


// ֻ���ڶ����� ERROR_CONCEALMENT ��ʱ,���� ecAlg ������˼
avcdDecoder_t  * avcdOpen_o( int ecAlg ) ;

#define DECODE_ACCESS_UNITS 
#ifdef DECODE_ACCESS_UNITS
int avcdDecodeOneFrame_o(avcdDecoder_t *dec, void *nalBitsPtr,
					   int nalBitsLen, avcdYUVbuffer_s *outBuf);
#endif

int   avcdDecodeOneNal_o( avcdDecoder_t * dec, void * nalUnitBits, int nalUnitLen, avcdYUVbuffer_s * outBuf ) ;

void  avcdClose_o( avcdDecoder_t * dec ) ;


#endif
