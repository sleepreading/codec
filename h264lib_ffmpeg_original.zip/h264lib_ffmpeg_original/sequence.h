/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _SEQUENCE_H_
#define  	_SEQUENCE_H_	 


#include	 "framebuffer.h"
#include	 "slice.h"
#include	 "bitbuffer.h"
#ifdef ERROR_CONCEALMENT
#include "sei.h"
#include "errorconcealment.h"
#endif


typedef struct _sequence_s
{

	dpb_s				 * dpb;

	frmBuf_s			 * outputQueue[ DPB_MAX_SIZE ];
	int  				   outputQueuePos;
	int  				   numQueuedOutputPics;

	bitbuffer_s  		 * bitbuf;

	int  				   sliceNums[ PS_MAX_NUM_SLICE_GROUPS ];

	seq_parameter_set_s  * spsList[ PS_MAX_NUM_OF_SPS ];
	pic_parameter_set_s  * ppsList[ PS_MAX_NUM_OF_PPS ];

	slice_s  			 * currSlice;
	slice_s  			 * nextSlice;

	int  				   isFirstSliceOfSeq;
	int  				   isPicBoundary;
	int  				   isDpbStorePending;
	int  				   isSliceDataDecodePending;
	int  				   isSeqFinished;

	int32				   unusedShortTermFrameNum;
	int32				   prevFrameNum;
	int32				   prevRefFrameNum;

/* for POC type 0 : */
	int32				   pocMsb;
	int32				   prevPocMsb;
	int32				   prevPocLsb;
/* for POC type 1 : */
	int32				   frameNumOffset;
	int32				   prevFrameNumOffset;

	int  				   prevPicHasMMCO5;  					//	< the previous decoded picture in decoding	    
																//		order including a						    
																//		memory_management_control_operation equal   
																//		to 5 >									    

	mbAttributes_s		 * mbData;
	frmBuf_s			 * recoBuf;

#ifdef DECODE_ACCESS_UNITS
  int streamPos;
  int decResult;
#endif

#ifdef ERROR_CONCEALMENT

  errorConcealment_s *errConcealment;

  /* Indicates whether to conceal frames (1) or generate non-existing frames (0) */
  int conceal;

  sceneInfo_s *prevSceneInfo;
  sceneInfo_s *currSceneInfo;
  int hasSceneInfo;
  int sceneInfoDecoded;
  
  int ecAlg;
#endif

}	 sequence_s;


#endif
