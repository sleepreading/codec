/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/



#include	 "globals.h"
#include	 "prederrordec.h"
#include	 "intrapred.h"



/*
 * Prototypes for static functions
 */

static	void  intraPred4x4( u_int8 predBlk[ BLK_SIZE ][ MBK_SIZE ], int mode, u_int8 * reco, int picWidth, int blkAvailBits ) ;


/*
 *
 * intraPred4x4
 *
 * Parameters:
 *		predBlk  			  Return pointer for predicted pixels
 *		mode				  Prediction for the block
 *		reco				  Reconstruction pixels
 *		picWidth			  Horizontal size of the frame
 *		blkAvailBits		  Availability of neighboring blocks
 *
 * Function:
 *		Compute prediction for one 4x4 block using given mode
 *
 * Returns:
 *		-
 *
 */
static	void  intraPred4x4( u_int8 predBlk[ BLK_SIZE ][ MBK_SIZE ], 
							int mode, u_int8 * reco, int picWidth, 
							int blkAvailBits )
{
	int  i, j;
	int  X, A, B, C, D, E, F, G, H, I, J, K, L;
	int  dc;


  /*
   * Copy reconstruction pixels used for prediction
   */

	if( blkAvailBits & 0x1000 )  								//	up-left  									    
		X = reco[ 0 ];
	else
		X = 128;

	if( blkAvailBits & 0x0010 )
	{															//	up											    
		A = reco[ 1 ];
		B = reco[ 2 ];
		C = reco[ 3 ];
		D = reco[ 4 ];
		if( blkAvailBits & 0x0100 )
		{														//	  up-right									    
			E = reco[ 5 ];
			F = reco[ 6 ];
			G = reco[ 7 ];
			H = reco[ 8 ];
		}
		else
			E = F = G = H = D;
	}
	else
		A = B = C = D = E = F = G = H = 128;

	if( blkAvailBits & 0x0001 )
	{															//	left										    
		I = reco[ 1 * picWidth ];
		J = reco[ 2 * picWidth ];
		K = reco[ 3 * picWidth ];
		L = reco[ 4 * picWidth ];
	}
	else
		I = J = K = L = 128;


	switch( mode )
	{

		case IPR_MODE_DC:

			/* DC PREDICTION */

			if( ( blkAvailBits & 0x0010 )						//		up & left								    
				&& ( blkAvailBits & 0x0001 ) )
				dc = ( A + B + C + D + I + J + K + L + 4 ) >> 3;
			else
				if( blkAvailBits & 0x0010 )  					//		  up									    
					dc = ( A + B + C + D + 2 ) >> 2;
				else
					if( blkAvailBits & 0x0001 )  				//			left								    
						dc = ( I + J + K + L + 2 ) >> 2;
					else
						dc = 128;

			for( j = 0;  j < BLK_SIZE;	j++ )
			{
				predBlk[ j ][ 0 ] = ( u_int8 ) dc;
				predBlk[ j ][ 1 ] = ( u_int8 ) dc;
				predBlk[ j ][ 2 ] = ( u_int8 ) dc;
				predBlk[ j ][ 3 ] = ( u_int8 ) dc;
			}

			break;

		case IPR_MODE_VERT:

			/* VERTICAL PREDICTION */

			for( j = 0;  j < BLK_SIZE;	j++ )
			{
				predBlk[ j ][ 0 ] = ( u_int8 ) A;
				predBlk[ j ][ 1 ] = ( u_int8 ) B;
				predBlk[ j ][ 2 ] = ( u_int8 ) C;
				predBlk[ j ][ 3 ] = ( u_int8 ) D;
			}

			break;

		case IPR_MODE_HOR:

			/* HORIZONTAL PREDICTION */

			for( i = 0;  i < BLK_SIZE;	i++ )
			{
				predBlk[ 0 ][ i ] = ( u_int8 ) I;
				predBlk[ 1 ][ i ] = ( u_int8 ) J;
				predBlk[ 2 ][ i ] = ( u_int8 ) K;
				predBlk[ 3 ][ i ] = ( u_int8 ) L;
			}

			break;

		case IPR_MODE_DIAG_DOWN_RIGHT:

			/* DIAGONAL PREDICTION */

			predBlk[ 3 ][ 0 ] = ( u_int8 ) ( ( L + 2 * K + J + 2 ) >> 2 );
			predBlk[ 2 ][ 0 ] = predBlk[ 3 ][ 1 ] = ( u_int8 ) ( ( K + 2 * J + I + 2 ) >> 2 );
			predBlk[ 1 ][ 0 ]
			= predBlk[ 2 ][ 1 ] = predBlk[ 3 ][ 2 ] = ( u_int8 ) ( ( J + 2 * I + X + 2 ) >> 2 );
			predBlk[ 0 ][ 0 ]
			= predBlk[ 1 ][ 1 ]
			  = predBlk[ 2 ][ 2 ]
				= predBlk[ 3 ][ 3 ] = ( u_int8 ) ( ( I + 2 * X + A + 2 ) >> 2 );
			predBlk[ 0 ][ 1 ]
			= predBlk[ 1 ][ 2 ] = predBlk[ 2 ][ 3 ] = ( u_int8 ) ( ( X + 2 * A + B + 2 ) >> 2 );
			predBlk[ 0 ][ 2 ] = predBlk[ 1 ][ 3 ] = ( u_int8 ) ( ( A + 2 * B + C + 2 ) >> 2 );
			predBlk[ 0 ][ 3 ] = ( u_int8 ) ( ( B + 2 * C + D + 2 ) >> 2 );

			break;

		case IPR_MODE_DIAG_DOWN_LEFT:
			predBlk[ 0 ][ 0 ] = ( u_int8 ) ( ( A + 2 * B + C + 2 ) >> 2 );
			predBlk[ 0 ][ 1 ] = predBlk[ 1 ][ 0 ] = ( u_int8 ) ( ( B + 2 * C + D + 2 ) >> 2 );
			predBlk[ 0 ][ 2 ]
			= predBlk[ 1 ][ 1 ] = predBlk[ 2 ][ 0 ] = ( u_int8 ) ( ( C + 2 * D + E + 2 ) >> 2 );
			predBlk[ 0 ][ 3 ]
			= predBlk[ 1 ][ 2 ]
			  = predBlk[ 2 ][ 1 ]
				= predBlk[ 3 ][ 0 ] = ( u_int8 ) ( ( D + 2 * E + F + 2 ) >> 2 );
			predBlk[ 1 ][ 3 ]
			= predBlk[ 2 ][ 2 ] = predBlk[ 3 ][ 1 ] = ( u_int8 ) ( ( E + 2 * F + G + 2 ) >> 2 );
			predBlk[ 2 ][ 3 ] = predBlk[ 3 ][ 2 ] = ( u_int8 ) ( ( F + 2 * G + H + 2 ) >> 2 );
			predBlk[ 3 ][ 3 ] = ( u_int8 ) ( ( G + 3 * H + 2 ) >> 2 );

			break;

		case IPR_MODE_VERT_RIGHT:								//	  diagonal prediction -22.5 deg to horizontal   
																//		  plane  								    
			predBlk[ 0 ][ 0 ] = predBlk[ 2 ][ 1 ] = ( u_int8 ) ( ( X + A + 1 ) >> 1 );
			predBlk[ 0 ][ 1 ] = predBlk[ 2 ][ 2 ] = ( u_int8 ) ( ( A + B + 1 ) >> 1 );
			predBlk[ 0 ][ 2 ] = predBlk[ 2 ][ 3 ] = ( u_int8 ) ( ( B + C + 1 ) >> 1 );
			predBlk[ 0 ][ 3 ] = ( u_int8 ) ( ( C + D + 1 ) >> 1 );
			predBlk[ 1 ][ 0 ] = predBlk[ 3 ][ 1 ] = ( u_int8 ) ( ( I + 2 * X + A + 2 ) >> 2 );
			predBlk[ 1 ][ 1 ] = predBlk[ 3 ][ 2 ] = ( u_int8 ) ( ( X + 2 * A + B + 2 ) >> 2 );
			predBlk[ 1 ][ 2 ] = predBlk[ 3 ][ 3 ] = ( u_int8 ) ( ( A + 2 * B + C + 2 ) >> 2 );
			predBlk[ 1 ][ 3 ] = ( u_int8 ) ( ( B + 2 * C + D + 2 ) >> 2 );
			predBlk[ 2 ][ 0 ] = ( u_int8 ) ( ( X + 2 * I + J + 2 ) >> 2 );
			predBlk[ 3 ][ 0 ] = ( u_int8 ) ( ( I + 2 * J + K + 2 ) >> 2 );

			break;

		case IPR_MODE_VERT_LEFT:								//	  diagonal prediction -22.5 deg to horizontal   
																//		  plane  								    
			predBlk[ 0 ][ 0 ] = ( u_int8 ) ( ( A + B + 1 ) >> 1 );
			predBlk[ 0 ][ 1 ] = predBlk[ 2 ][ 0 ] = ( u_int8 ) ( ( B + C + 1 ) >> 1 );
			predBlk[ 0 ][ 2 ] = predBlk[ 2 ][ 1 ] = ( u_int8 ) ( ( C + D + 1 ) >> 1 );
			predBlk[ 0 ][ 3 ] = predBlk[ 2 ][ 2 ] = ( u_int8 ) ( ( D + E + 1 ) >> 1 );
			predBlk[ 2 ][ 3 ] = ( u_int8 ) ( ( E + F + 1 ) >> 1 );
			predBlk[ 1 ][ 0 ] = ( u_int8 ) ( ( A + 2 * B + C + 2 ) >> 2 );
			predBlk[ 1 ][ 1 ] = predBlk[ 3 ][ 0 ] = ( u_int8 ) ( ( B + 2 * C + D + 2 ) >> 2 );
			predBlk[ 1 ][ 2 ] = predBlk[ 3 ][ 1 ] = ( u_int8 ) ( ( C + 2 * D + E + 2 ) >> 2 );
			predBlk[ 1 ][ 3 ] = predBlk[ 3 ][ 2 ] = ( u_int8 ) ( ( D + 2 * E + F + 2 ) >> 2 );
			predBlk[ 3 ][ 3 ] = ( u_int8 ) ( ( E + 2 * F + G + 2 ) >> 2 );

			break;

		case IPR_MODE_HOR_UP:									//	  diagonal prediction -22.5 deg to horizontal   
																//		  plane  								    
			predBlk[ 0 ][ 0 ] = ( u_int8 ) ( ( I + J + 1 ) >> 1 );
			predBlk[ 0 ][ 1 ] = ( u_int8 ) ( ( I + 2 * J + K + 2 ) >> 2 );
			predBlk[ 0 ][ 2 ] = predBlk[ 1 ][ 0 ] = ( u_int8 ) ( ( J + K + 1 ) >> 1 );
			predBlk[ 0 ][ 3 ] = predBlk[ 1 ][ 1 ] = ( u_int8 ) ( ( J + 2 * K + L + 2 ) >> 2 );
			predBlk[ 1 ][ 2 ] = predBlk[ 2 ][ 0 ] = ( u_int8 ) ( ( K + L + 1 ) >> 1 );
			predBlk[ 1 ][ 3 ] = predBlk[ 2 ][ 1 ] = ( u_int8 ) ( ( K + 2 * L + L + 2 ) >> 2 );
			predBlk[ 2 ][ 3 ]
			= predBlk[ 3 ][ 1 ]
			  = predBlk[ 2 ][ 2 ]
				= predBlk[ 3 ][ 0 ] = predBlk[ 3 ][ 2 ] = predBlk[ 3 ][ 3 ] = ( u_int8 ) L;

			break;

		case IPR_MODE_HOR_DOWN:  								//	  diagonal prediction -22.5 deg to horizontal   
																//		  plane  								    
			predBlk[ 0 ][ 0 ] = predBlk[ 1 ][ 2 ] = ( u_int8 ) ( ( X + I + 1 ) >> 1 );
			predBlk[ 0 ][ 1 ] = predBlk[ 1 ][ 3 ] = ( u_int8 ) ( ( I + 2 * X + A + 2 ) >> 2 );
			predBlk[ 0 ][ 2 ] = ( u_int8 ) ( ( X + 2 * A + B + 2 ) >> 2 );
			predBlk[ 0 ][ 3 ] = ( u_int8 ) ( ( A + 2 * B + C + 2 ) >> 2 );
			predBlk[ 1 ][ 0 ] = predBlk[ 2 ][ 2 ] = ( u_int8 ) ( ( I + J + 1 ) >> 1 );
			predBlk[ 1 ][ 1 ] = predBlk[ 2 ][ 3 ] = ( u_int8 ) ( ( X + 2 * I + J + 2 ) >> 2 );
			predBlk[ 2 ][ 0 ] = predBlk[ 3 ][ 2 ] = ( u_int8 ) ( ( J + K + 1 ) >> 1 );
			predBlk[ 2 ][ 1 ] = predBlk[ 3 ][ 3 ] = ( u_int8 ) ( ( I + 2 * J + K + 2 ) >> 2 );
			predBlk[ 3 ][ 0 ] = ( u_int8 ) ( ( K + L + 1 ) >> 1 );
			predBlk[ 3 ][ 1 ] = ( u_int8 ) ( ( J + 2 * K + L + 2 ) >> 2 );
			break;

		default :
//			deb0f( stderr, "Illegal 4x4 intra mode\n" );
			break;
	}

}


/*
 *
 * iprPredLuma4x4blocks
 *
 * Parameters:
 *		coef				  Transform coefficints for 4x4 blocks
 *		reco				  Reconstruction pixels
 *		picWidth			  Horizontal size of the frame
 *		picHeight			  Vertical size of the frame
 *		ipModes  			  Intra prediction modes for the frame
 *		mbAvailBits  		  Macroblock availability flags
 *		mbIdxX				  Horz. location of the MB in the frame
 *		mbIdxY				  Vert. location of the MB in the frame
 *		cbp  				  Coded Block Pattern
 *		qp					  Quantization parameter
 *
 * Function:
 *		Make 4x4 luma intra prediction for all blocks in the macroblock.
 *
 * Returns:
 *		-
 *
 */
void  iprPredLuma4x4blocks( int coef[ BLK_PER_MB ][ BLK_PER_MB ][ BLK_SIZE ][ BLK_SIZE ], 
							u_int8 * reco, int picWidth, int8 * ipModes, 
							int mbAvailBits, int mbIdxX, int mbIdxY, 
							int cbp, int qp )
{
	u_int8	  predY[ BLK_SIZE ][ MBK_SIZE ];
	int  	  blkIdxX, blkIdxY;
	int  	  blkAvailUp, blkAvailLeft, blkAvailUpRight, blkAvailUpLeft;
	u_int8	* recoPtr;
	int  	  blkAvailBits;
	int  	  blkNum;

	recoPtr = &reco[ mbIdxY * MBK_SIZE * picWidth + mbIdxX * MBK_SIZE ];

  /*
   * Check block availability (1 bit per block, 4 directions)
   */

	blkAvailUp		= ( mbAvailBits & 2 ) ? 0xFFFF : 0xFFF0;

	blkAvailLeft	= ( mbAvailBits & 1 ) ? 0xFFFF : 0xEEEE;

	blkAvailUpRight = 0x5750;
	if( mbAvailBits & 2 )
		blkAvailUpRight |= 0x0007;
	if( mbAvailBits & 4 )
		blkAvailUpRight |= 0x0008;

	blkAvailUpLeft = 0xEEE0;
	if( mbAvailBits & 2 )
		blkAvailUpLeft |= 0x000E;
	if( mbAvailBits & 1 )
		blkAvailUpLeft |= 0x1110;
	if( mbAvailBits & 8 )
		blkAvailUpLeft |= 0x0001;

  /*
   * Build 4x4 intra prediction
   */

	for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
	{

		/* Gather availability bits for 4 blocks in raster scan order */
		blkAvailBits
		= ( blkAvailLeft & 0x000f ) | ( ( blkAvailUp & 0x000f ) << 4 )
		  | ( ( blkAvailUpRight & 0x000f ) << 8 ) | ( ( blkAvailUpLeft & 0x000f ) << 12 );

		/* Next 4 blocks */
		blkAvailLeft	>>= 4;
		blkAvailUp		>>= 4;
		blkAvailUpRight >>= 4;
		blkAvailUpLeft	>>= 4;

		for( blkIdxX = 0;  blkIdxX < BLK_PER_MB;  blkIdxX++ )
		{

			blkNum = blkIdxY * BLK_PER_MB + blkIdxX;

			/* Make all possible 4x4 predictions for current block */
			intraPred4x4( predY, ipModes[ blkIdxX ], 
			  &recoPtr[ blkIdxX * BLK_SIZE - picWidth - 1 ], picWidth, blkAvailBits );

			if( ( cbp >> blkNum ) & 1 )
			{
				pedRecoBlock( predY, coef[ blkIdxY ][ blkIdxX ], 
							  &recoPtr[ blkIdxX * BLK_SIZE ], picWidth, 0, 0, qp );
			}
			else
			{
				pedRecoBlockNoCoef( predY, &recoPtr[ blkIdxX * BLK_SIZE ], picWidth );
			}

			blkAvailBits >>= 1;
		}

		recoPtr += BLK_SIZE * picWidth;
		ipModes += BLK_PER_MB;
	}

}


/*
 *
 * iprPredLuma16x16
 *
 * Parameters:
 *		predBlk  			  Return pointer for predicted pixels
 *		mode				  16x16 mode to be computed
 *		reco				  Reconstruction pixels
 *		picWidth			  Horizontal size of the frame
 *		mbAvailBits  		  Contains availability flags for neighboring MBs
 *
 * Function:
 *		Predict luma pixels using one of 16x16 intra modes.
 *
 * Returns:
 *		-
 *
 */
int  iprPredLuma16x16( 
			 u_int8 predBlk[ MBK_SIZE ][ MBK_SIZE ], int mode, 
			 u_int8 * reco, int picWidth, int mbAvailBits )
{
	int  	  dc;
	int  	  H, V;
	int  	  a, b, c;
	int  	  i, j;
	int  	  tmp, tmp2;
	u_int8	* recoPtr, * recoPtr2;


	switch( mode )
	{

		case IPR_MODE2_DC:

			/* DC PREDICTION */

			if( ( mbAvailBits & 1 ) && ( mbAvailBits & 2 ) )
			{
				recoPtr = &reco[ picWidth ];
				for( dc = 0, i = 0;  i < MBK_SIZE;	i++ )
				{
					dc		+= reco[ 1 + i ] + ( *recoPtr );
					recoPtr += picWidth;
				}
				dc = ( dc + 16 ) >> 5;
			}
			else
				if( mbAvailBits & 1 )
				{
					recoPtr = &reco[ picWidth ];
					for( dc = 0, i = 0;  i < MBK_SIZE;	i++ )
					{
						dc		+= ( *recoPtr );
						recoPtr += picWidth;
					}
					dc = ( dc + 8 ) >> 4;
				}
				else
					if( mbAvailBits & 2 )
					{
						for( dc = 0, i = 0;  i < MBK_SIZE;  
							 i++ )
							dc += reco[ 1 + i ];
						dc = ( dc + 8 ) >> 4;
					}
					else
						dc = 128;

			for( j = 0;  j < MBK_SIZE;	j++ )
			{
				for( i = 0;  i < MBK_SIZE;	i += 4 )
				{
					predBlk[ j ][ i + 0 ] = ( u_int8 ) dc;
					predBlk[ j ][ i + 1 ] = ( u_int8 ) dc;
					predBlk[ j ][ i + 2 ] = ( u_int8 ) dc;
					predBlk[ j ][ i + 3 ] = ( u_int8 ) dc;
				}
			}

			break;

		case IPR_MODE2_VERT:

			/* VERTICAL PREDICTION */

			if( !( mbAvailBits & 2 ) )
				return -1;

			for( i = 0;  i < MBK_SIZE;	i++ )
			{
				tmp = reco[ 1 + i ];
				for( j = 0;  j < MBK_SIZE;	j += 4 )
				{
					predBlk[ j + 0 ][ i ] = ( u_int8 ) tmp;
					predBlk[ j + 1 ][ i ] = ( u_int8 ) tmp;
					predBlk[ j + 2 ][ i ] = ( u_int8 ) tmp;
					predBlk[ j + 3 ][ i ] = ( u_int8 ) tmp;
				}
			}

			break;

		case IPR_MODE2_HOR:

			/* HORIZONTAL PREDICTION */

			if( !( mbAvailBits & 1 ) )
				return -1;

			recoPtr = &reco[ picWidth ];
			for( j = 0;  j < MBK_SIZE;	j++ )
			{
				tmp  	 = *recoPtr;
				recoPtr += picWidth;
				for( i = 0;  i < MBK_SIZE;	i += 4 )
				{
					predBlk[ j ][ i + 0 ] = ( u_int8 ) tmp;
					predBlk[ j ][ i + 1 ] = ( u_int8 ) tmp;
					predBlk[ j ][ i + 2 ] = ( u_int8 ) tmp;
					predBlk[ j ][ i + 3 ] = ( u_int8 ) tmp;
				}
			}

			break;

		case IPR_MODE2_PLANE:

			/* PLANE PREDICTION */

			if( !( mbAvailBits & 1 ) || !( mbAvailBits & 2 )
				|| !( mbAvailBits & 8 ) )
				return -1;

			recoPtr  = &reco[ 9 * picWidth ];
			recoPtr2 = &reco[ 7 * picWidth ];
			for( H = 0, V = 0, i = 1;  i <= 8;	i++ )
			{
				H		 += ( i * ( reco[ 8 + i ] - reco[ 8 - i ] ) );
				V		 += ( i * ( ( *recoPtr ) - ( *recoPtr2 ) ) );
				recoPtr  += picWidth;
				recoPtr2 -= picWidth;
			}
			a	= 16 * ( reco[ 16 * picWidth ] + reco[ 16 ] );
			b	= ( int ) ( ( 5 * ( ( int32 ) H ) + 32 ) >> 6 );
			c	= ( int ) ( ( 5 * ( ( int32 ) V ) + 32 ) >> 6 );

			tmp = a + c * ( 0 - 7 ) + 16;
			for( j = 0;  j < MBK_SIZE;	j++, tmp += c )
			{
				tmp2 = tmp + b * ( 0 - 7 );
				for( i = 0;  i < MBK_SIZE;	i++, tmp2 += b )
				{
					predBlk[ j ][ i ] = ( u_int8 ) clip( 0, 255, tmp2 >> 5 );
				}
			}

			break;
	}

	return 1;
}


/*
 *
 * iprPredChroma
 *
 * Parameters:
 *		pred				  Storage for predicted pixels
 *		recoU				  Reconstruction pixels for U frame
 *		recoV				  Reconstruction pixels for V frame
 *		width				  Horizontal size of the frame
 *		mbAvailBits  		  Macroblock availability flags
 *		mode				  Chrominance intra mode
 *
 * Function:
 *		Make 8x8 chroma intra prediction for given macroblock.
 *
 * Returns:
 *		-
 *
 */
int  iprPredChroma( u_int8 pred[ MBK_SIZE / 2 ][ MBK_SIZE ], 
					u_int8 * recoU, u_int8 * recoV, int width, 
					int mbAvailBits, int mode )
{
	int  	  comp;
	u_int8	* recoPic;
	int  	  S0, S1, S2, S3;
	int  	  A, B, C, D;
	int  	  H, V, a, b, c;
	int  	  i, j;
	int  	  tmp, tmp2;


	switch( mode )
	{

		case IPR_CHROMA_MODE_DC:

	/*
	 * DC prediction
	 */

			for( comp = 0;	comp < MBK_SIZE;  
				 comp += MBK_SIZE / 2 )
			{

				recoPic = comp == 0 ? recoU : recoV;

				S0		= S1 = S2 = S3 = 0;

				if( mbAvailBits & 1 )
				{
					for( i = 0;  i < 4;  i++ )
					{
						S2 += recoPic[ ( 1 + i ) * width ];
						S3 += recoPic[ ( 5 + i ) * width ];
					}
				}
				if( mbAvailBits & 2 )
				{
					for( i = 0;  i < 4;  i++ )
					{
						S0 += recoPic[ 1 + i ];
						S1 += recoPic[ 5 + i ];
					}
				}

				if( ( mbAvailBits & 1 )
					&& ( mbAvailBits & 2 ) )
				{
					A = ( S0 + S2 + 4 ) >> 3;
					B = ( S1 + 2 ) >> 2;
					C = ( S3 + 2 ) >> 2;
					D = ( S1 + S3 + 4 ) >> 3;
				}
				else
					if( mbAvailBits & 1 )
					{
						A = B = ( S2 + 2 ) >> 2;
						C = D = ( S3 + 2 ) >> 2;
					}
					else
						if( mbAvailBits & 2 )
						{
							A = C = ( S0 + 2 ) >> 2;
							B = D = ( S1 + 2 ) >> 2;
						}
						else
							A = B = C = D = 128;

				for( j = 0;  j < BLK_SIZE;	j++ )
				{
					for( i = 0;  i < BLK_SIZE;	i++ )
					{
						pred[ j ][ comp + i ] = ( u_int8 ) A;
						pred[ j ][ comp + 4 + i ] = ( u_int8 ) B;
						pred[ 4 + j ][ comp + i ] = ( u_int8 ) C;
						pred[ 4 + j ][ comp + 4 + i ] = ( u_int8 ) D;
					}
				}
			}

			break;

		case IPR_CHROMA_MODE_VERT:

	/*
	 * Vertical prediction
	 */

			if( !( mbAvailBits & 2 ) )
				return -1;

			for( comp = 0;	comp < MBK_SIZE;  
				 comp += MBK_SIZE / 2 )
			{

				recoPic = comp == 0 ? recoU : recoV;

				for( i = 0;  i < MBK_SIZE / 2;	i++ )
				{
					tmp = recoPic[ 1 + i ];
					for( j = 0;  j < MBK_SIZE / 2;	j += 4 )
					{
						pred[ j + 0 ][ comp + i ] = ( u_int8 ) tmp;
						pred[ j + 1 ][ comp + i ] = ( u_int8 ) tmp;
						pred[ j + 2 ][ comp + i ] = ( u_int8 ) tmp;
						pred[ j + 3 ][ comp + i ] = ( u_int8 ) tmp;
					}
				}
			}

			break;

		case IPR_CHROMA_MODE_HOR:

	/*
	 * Horizontal prediction
	 */

			if( !( mbAvailBits & 1 ) )
				return -1;

			for( comp = 0;	comp < MBK_SIZE;  
				 comp += MBK_SIZE / 2 )
			{

				recoPic = comp == 0 ? recoU : recoV;

				for( j = 0;  j < MBK_SIZE / 2;	j++ )
				{
					tmp = recoPic[ ( 1 + j ) * width ];
					for( i = 0;  i < MBK_SIZE / 2;	i += 4 )
					{
						pred[ j ][ comp + i + 0 ] = ( u_int8 ) tmp;
						pred[ j ][ comp + i + 1 ] = ( u_int8 ) tmp;
						pred[ j ][ comp + i + 2 ] = ( u_int8 ) tmp;
						pred[ j ][ comp + i + 3 ] = ( u_int8 ) tmp;
					}
				}
			}

			break;

		case IPR_CHROMA_MODE_PLANE:

	/*
	 * Plane Prediction
	 */

			if( !( mbAvailBits & 1 ) || !( mbAvailBits & 2 )
				|| !( mbAvailBits & 8 ) )
				return -1;

			for( comp = 0;	comp < MBK_SIZE;  
				 comp += MBK_SIZE / 2 )
			{

				recoPic = comp == 0 ? recoU : recoV;

				for( H = V = 0, i = 1;	i <= 4;  i++ )
				{
					H += i * ( recoPic[ 4 + i ] - recoPic[ 4 - i ] );
					V += i * ( recoPic[ ( 4 + i ) * width ] - recoPic[ ( 4 - i ) * width ] );
				}

				a = 16 * ( recoPic[ 8 * width ] + recoPic[ 8 ] );
				b = ( int ) ( ( 17 * ( ( int32 ) H ) + 16 ) >> 5 );
				c = ( int ) ( ( 17 * ( ( int32 ) V ) + 16 ) >> 5 );

				tmp = a + c * ( 0 - 3 ) + 16;
				for( j = 0;  j < MBK_SIZE / 2;	j++, tmp += c )
				{
					tmp2 = tmp + b * ( 0 - 3 );
					for( i = 0;  i < MBK_SIZE / 2;  
						 i++, tmp2 += b )
					{
						pred[ j ][ comp + i ] = ( u_int8 ) clip( 0, 255, tmp2 >> 5 );
					}
				}

			}

			break;
	}

	return 1;
}


/*
 *
 * iprClearMBintraPred
 *
 * Parameters:
 *		modesLeftPred		  Modes to the left
 *		modesUpPred  		  Upper modes
 *
 * Function:
 *		Set intra modes of all blocks within MB to DC prediction
 *
 * Returns:
 *		-
 *
 */
void  iprClearMBintraPred( int8 * modesLeftPred, int8 * modesUpPred )
{
	int  i;

	for( i = 0;  i < BLK_PER_MB;  i++ )
	{
		*modesLeftPred++ = IPR_MODE_DC;
		*modesUpPred++	 = IPR_MODE_DC;
	}
}


/*
 *
 * iprPutIntraModes
 *
 * Parameters:
 *		mbAvailBits  		  Macroblock availability flags
 *		ipModes  			  Encode intra modes/decoded intra modes
 *		modesLeftPred		  Modes to the left
 *		modesUpPred  		  Upper modes
 *
 * Function:
 *		Set intra modes for current MB. Modes are predicted from
 *		the blocks up and left of the current block.
 *
 * Returns:
 *		-
 *
 */
void  iprPutIntraModes( int mbAvailBits, int8 * ipModes, int8 * modesLeftPred, 
						int8 * modesUpPred )
{
	int  	blkIdxX, blkIdxY;
	int  	mostProbableMode;
	int  	mode, codedMode;
	int  	blkAvailBits;
	int8  * upPred;

	/* availability of the blocks to the left */
	blkAvailBits = ( mbAvailBits & 1 ) ? 0xffff : 0xeeee;

	/* availability of the upper blocks */
	if( !( mbAvailBits & 2 ) )
		blkAvailBits &= 0xfff0;

	upPred = modesUpPred;

	for( blkIdxY = 0;  blkIdxY < BLK_PER_MB;  blkIdxY++ )
	{

		/* Get mode of the block to the left */
		mode = *modesLeftPred;

		for( blkIdxX = 0;  blkIdxX < BLK_PER_MB;  blkIdxX++ )
		{

			if( blkAvailBits & 1 )								//		If left and upper blocks are available,     
																//			the most probable mode is minimum of    
																//			the two modes						    
				mostProbableMode = min( mode, upPred[ blkIdxX ] );
			else												//		If either left or upper block is not	    
																//			available, DC mode is the most		    
																//			probable mode						    
				mostProbableMode = IPR_MODE_DC;

			/* Get coded mode of current block */
			codedMode = *ipModes;

			if( codedMode < 0 )
				mode = mostProbableMode;
			else
				mode = ( codedMode < mostProbableMode ? codedMode : codedMode + 1 );

			/* Overwrite coded mode with decoded mode. mode is used for prediction */
			/* of the block to the right. */
			*ipModes++	   = ( int8 ) mode;

			blkAvailBits >>= 1;
		}

		/* This mode is used for prediction of the macroblock to the right */
		*modesLeftPred++ = ( int8 ) mode;

		upPred			 = ipModes - BLK_PER_MB;
	}

	/* These mode are used for prediction of the below macroblock */
	*modesUpPred++ = *upPred++;
	*modesUpPred++ = *upPred++;
	*modesUpPred++ = *upPred++;
	*modesUpPred++ = *upPred++;
}
