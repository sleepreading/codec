/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/





#ifndef _ERROR_CONCEALMENT_H_
#define  	_ERROR_CONCEALMENT_H_	  

#include	 "framebuffer.h"
#include	 "dpb.h"
#include	 "parameterset.h"


typedef struct _errorConcealment_s
{
	int  ** decodedMbs;  										//	< [height][width] >  						    
	int  ** prevDecodedMbs;  									//	< [height][width] >  						    
	int  	widthMbs, heightMbs;
	int  	inverseOfWidthMbs;
	int  	numFractBits;

	int  	dirDown, posDown;
	int  	dirUp, posUp;
	int  	dir;

	int  	isFirstPicOfSeq;
	int  	hasSceneInfo;
	int  	alg;												//	< indicate which EC algorithm to be used.	    
																//		0-PFC, 1-TCON-like >					    

	int  	qp;

}	 errorConcealment_s;


errorConcealment_s	* ercOpen( int wMbs, int hMbs ) ;

void				  ercClose( errorConcealment_s * pEc ) ;

void				  ercClear( errorConcealment_s * pEc ) ;

void				  ercDecodeMb( errorConcealment_s * pEc, int mbX, int mbY ) ;

int  				  ercCheck( errorConcealment_s * pEc ) ;

void				  ercConcealMbs( errorConcealment_s * pEc, frmBuf_s * currPic, mbAttributes_s * mbData, dpb_s * dpb, 
									 pic_parameter_set_s * pps ) ;

void				  ercConcealWholePic( errorConcealment_s * pEc, frmBuf_s * currPic, mbAttributes_s * mbData, 
										  dpb_s * dpb ) ;

void				  ercCheckAndConceal( errorConcealment_s * pEc, frmBuf_s * currPic, mbAttributes_s * mbData, 
										  dpb_s * dpb, pic_parameter_set_s * pps ) ;

#endif

