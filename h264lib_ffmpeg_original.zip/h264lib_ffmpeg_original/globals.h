/*******************************************************************************************************************
*  This source code has been made available to you by PANOVASIC on an AS-IS
*  basis Anyone receiving this source is licensed under PANOVASIC
*  copyrights to use it in any way he or she deems fit��including
*  copying it��modifying it��compiling it��and redistributing it either with 
*  or without modifications��
*
*  Any person who transfers this source code or any derivative work
*  must include the PANOVASIC copyright notice��this paragraph��and the
*  preceding two paragraphs in the transferred software.
*  COPYRIGHT  PANOVASIC  CORPORATION 2005
*  LICENSED MATERIAL - PROGRAM PROPERTY OF PANOVASIC
*******************************************************************************************************************/




#ifndef _GLOBALS_H_
#define  	_GLOBALS_H_     


#include	 "debug.h"


/*
 * General defines
 */

typedef  unsigned		  char	  Byte;
typedef  unsigned		  char	  u_char;
typedef  signed  		  char	  int8;
typedef  unsigned		  char	  u_int8;
typedef  		   short		  int16;
typedef  unsigned  short		  u_int16;
typedef  		   long  		  int32;
typedef  unsigned  long  		  u_int32;
// modified by 
//typedef  				  f loat   f loat32;
//typedef  				  d ouble  f loat64;
//  end
/* If this is defined, int is 16 bits */
//#define INT_IS_16_BITS

/* Minimum and maximum QP value */
#define  	MIN_QP	   0
#define  	MAX_QP	   51

#ifndef min
#define  	min( a, b )  	 ( ( a ) < ( b ) ? ( a ) : ( b ) )
#endif
#ifndef max
#define  	max( a, b )  	 ( ( a ) > ( b ) ? ( a ) : ( b ) )
#endif

/* This macro clips value val to the range of [min, max] */
#define  	clip( min, max, val )	   ( ( ( val ) < ( min ) ) ? ( min ) : ( ( ( val ) > ( max ) ) ? ( max ) : ( val	\
										  ) ) )


/*
 * Defines for slice
 */

/* All possible slice types */
#define  	SLICE_MIN				   0
#define  	SLICE_P  				   0						//< P (P slice) >								    
#define  	SLICE_B  				   1						//< B (B slice) >								    
#define  	SLICE_I  				   2						//< I (I slice) >								    
#define  	SLICE_SP				   3						//< SP (SP slice) >  							    
#define  	SLICE_SI				   4						//< SI (SI slice) >  							    
#define  	SLICE_P1				   5						//< P (P slice) >								    
#define  	SLICE_B1				   6						//< B (B slice) >								    
#define  	SLICE_I1				   7						//< I (I slice) >								    
#define  	SLICE_SP1				   8						//< SP (SP slice) >  							    
#define  	SLICE_SI1				   9						//< SI (SI slice) >  							    
#define  	SLICE_MAX				   9

/* Macros for testing whether slice is I slice, P slice or B slice */
#define  	IS_SLICE_I( x )  		   ( ( x ) == SLICE_I || ( x ) == SLICE_I1 || ( x ) == SLICE_SI || ( x ) == SLICE_SI1	 \
										  )
#define  	IS_SLICE_P( x )  		   ( ( x ) == SLICE_P || ( x ) == SLICE_P1 || ( x ) == SLICE_SP || ( x ) == SLICE_SP1	 \
										  )
#define  	IS_SLICE_B( x )  		   ( ( x ) == SLICE_B || ( x ) == SLICE_B1 )


/*
 * Defines for macroblock
 */

#define  	MBK_SIZE				   16
#define  	BLK_SIZE				   4
#define  	BLK_PER_MB				   ( MBK_SIZE / BLK_SIZE )
#define  	MBK_SIZE_LOG2			   4
#define  	BLK_SIZE_LOG2			   2

/* Macroblock type */
#define  	MBK_INTRA				   0
#define  	MBK_INTER				   1

/* Intra macroblock sub-type */
#define  	MBK_INTRA_TYPE1  		   0
#define  	MBK_INTRA_TYPE2  		   1
#define  	MBK_INTRA_TYPE_PCM		   2


/*
 * Global structures
 */

typedef struct _motVec_s
{
	int16  x;
	int16  y;
}	 motVec_s;


/* Chrominance QP mapping table. Has to be static on Symbian. */
/* Chroma QP = qpChroma[Luma QP]							  */
#ifndef __SYMBIAN32__
extern	const  u_int8  qpChroma[ 52 ];
#else
static const u_int8 qpChroma[52] = {
	0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,
   12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,
   28,29,29,30,31,32,32,33,34,34,35,35,36,36,37,37,
   37,38,38,38,39,39,39,39
}; 
#endif


#endif
